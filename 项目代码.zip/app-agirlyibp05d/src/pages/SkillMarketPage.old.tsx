import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { MainLayout } from '@/components/layouts/MainLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { SkillCard } from '@/components/skill/SkillCard';
import { PublishSkillDialog } from '@/components/skill/PublishSkillDialog';
import { useRequireAuth } from '@/hooks/useRequireAuth';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { getSkills } from '@/db/api';
import type { Skill, SkillType } from '@/types';
import { SKILL_TYPE_LABELS } from '@/types';
import { Search, Coins, Repeat } from 'lucide-react';
import { toast } from 'sonner';

export default function SkillMarketPage() {
  const { requireAuth } = useRequireAuth();
  const [searchParams] = useSearchParams();
  const [skills, setSkills] = useState<Skill[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterType, setFilterType] = useState<SkillType | 'all'>('all');
  const [filterExchange, setFilterExchange] = useState<'all' | 'direct' | 'point' | 'group'>('all');
  const [sortBy, setSortBy] = useState<'price_asc' | 'price_desc' | 'hot'>('hot');
  const [searchQuery, setSearchQuery] = useState('');
  const [searchInput, setSearchInput] = useState('');

  // 从URL参数读取筛选条件
  useEffect(() => {
    const method = searchParams.get('method');
    if (method === 'direct' || method === 'point' || method === 'group') {
      setFilterExchange(method);
    }
  }, [searchParams]);

  useEffect(() => {
    loadSkills();
  }, [filterType, sortBy, searchQuery, filterExchange]);

  const loadSkills = async () => {
    try {
      setLoading(true);
      let data = await getSkills({
        type: filterType === 'all' ? undefined : filterType,
        sortBy,
        search: searchQuery || undefined,
      });

      // 前端筛选交换方式
      if (filterExchange === 'direct') {
        data = data.filter((skill) => skill.required_skills);
      } else if (filterExchange === 'point') {
        data = data.filter((skill) => !skill.required_skills);
      } else if (filterExchange === 'group') {
        // 团购暂时显示所有技能(后续可以添加团购标记)
        data = data;
      }

      setSkills(data);
    } catch (error) {
      toast.error('加载技能失败');
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setSearchQuery(searchInput);
  };

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">技能广场</h1>
            <p className="text-muted-foreground mt-1">发现并交换各种技能</p>
          </div>
          <PublishSkillDialog />
        </div>

        {/* Search */}
        <form onSubmit={handleSearch}>
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="搜索技能名称..."
                value={searchInput}
                onChange={(e) => setSearchInput(e.target.value)}
                className="pl-9"
              />
            </div>
            <Button type="submit">搜索</Button>
          </div>
        </form>

        {/* Exchange Type Filter */}
        <div className="flex gap-2 flex-wrap">
          <Badge
            variant={filterExchange === 'all' ? 'default' : 'outline'}
            className="cursor-pointer"
            onClick={() => setFilterExchange('all')}
          >
            全部
          </Badge>
          <Badge
            variant={filterExchange === 'direct' ? 'default' : 'outline'}
            className="cursor-pointer gap-1"
            onClick={() => setFilterExchange('direct')}
          >
            <Repeat className="h-3 w-3" />
            直接交换
          </Badge>
          <Badge
            variant={filterExchange === 'point' ? 'default' : 'outline'}
            className="cursor-pointer gap-1"
            onClick={() => setFilterExchange('point')}
          >
            <Coins className="h-3 w-3" />
            技易点交换
          </Badge>
          <Badge
            variant={filterExchange === 'group' ? 'default' : 'outline'}
            className="cursor-pointer gap-1"
            onClick={() => setFilterExchange('group')}
          >
            团购
          </Badge>
        </div>

        {/* Filters */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <Label className="text-sm text-muted-foreground mb-2 block">技能类型</Label>
                <Tabs value={filterType} onValueChange={(v) => setFilterType(v as SkillType | 'all')}>
                  <TabsList className="w-full justify-start flex-wrap h-auto">
                    <TabsTrigger value="all">全部</TabsTrigger>
                    {Object.entries(SKILL_TYPE_LABELS).map(([key, label]) => (
                      <TabsTrigger key={key} value={key}>
                        {label}
                      </TabsTrigger>
                    ))}
                  </TabsList>
                </Tabs>
              </div>

              <div className="w-full md:w-48">
                <Label className="text-sm text-muted-foreground mb-2 block">排序方式</Label>
                <Select
                  value={sortBy}
                  onValueChange={(v) => setSortBy(v as 'price_asc' | 'price_desc' | 'hot')}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="hot">最热门</SelectItem>
                    <SelectItem value="price_asc">价格从低到高</SelectItem>
                    <SelectItem value="price_desc">价格从高到低</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Skills Grid */}
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array.from({ length: 9 }).map((_, i) => (
              <Card key={i}>
                <CardContent className="p-6">
                  <Skeleton className="h-6 w-3/4 mb-2 bg-muted" />
                  <Skeleton className="h-4 w-full mb-4 bg-muted" />
                  <Skeleton className="h-4 w-1/2 bg-muted" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : skills.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {skills.map((skill) => (
              <SkillCard key={skill.id} skill={skill} />
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="py-12 text-center text-muted-foreground">
              {searchQuery ? '未找到相关技能' : '暂无技能'}
            </CardContent>
          </Card>
        )}
      </div>
    </MainLayout>
  );
}
