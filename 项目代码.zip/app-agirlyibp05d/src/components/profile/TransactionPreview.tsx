import { Link } from 'react-router-dom';
import { Card } from '@/components/ui/card';
import { TrendingUp, TrendingDown, ChevronRight } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { zhCN } from 'date-fns/locale';

interface Transaction {
  id: string;
  amount: number;
  type: 'income' | 'expense';
  reason: string;
  created_at: string;
}

interface TransactionPreviewProps {
  transactions: Transaction[];
}

export function TransactionPreview({ transactions }: TransactionPreviewProps) {
  if (transactions.length === 0) {
    return (
      <Card className="rounded-2xl">
        <div className="p-6 text-center text-sm text-muted-foreground">
          暂无交易记录
        </div>
      </Card>
    );
  }

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between px-1">
        <h3 className="text-sm font-medium text-muted-foreground">最近交易</h3>
        <Link
          to="/profile/integral"
          className="text-sm text-primary hover:underline flex items-center gap-1"
        >
          查看更多
          <ChevronRight className="h-3 w-3" />
        </Link>
      </div>
      <Card className="rounded-2xl overflow-hidden">
        <div className="divide-y divide-border">
          {transactions.slice(0, 3).map((transaction) => (
            <div key={transaction.id} className="flex items-center justify-between p-4 hover:bg-muted/30 transition-colors">
              <div className="flex items-center gap-3 flex-1 min-w-0">
                <div
                  className={`flex items-center justify-center w-9 h-9 rounded-full ${
                    transaction.type === 'income'
                      ? 'bg-green-100 dark:bg-green-950'
                      : 'bg-red-100 dark:bg-red-950'
                  }`}
                >
                  {transaction.type === 'income' ? (
                    <TrendingUp className="h-4 w-4 text-green-600 dark:text-green-400" />
                  ) : (
                    <TrendingDown className="h-4 w-4 text-red-600 dark:text-red-400" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium truncate">{transaction.reason}</div>
                  <div className="text-xs text-muted-foreground">
                    {formatDistanceToNow(new Date(transaction.created_at), {
                      addSuffix: true,
                      locale: zhCN,
                    })}
                  </div>
                </div>
              </div>
              <div
                className={`text-base font-bold ${
                  transaction.type === 'income'
                    ? 'text-green-600 dark:text-green-400'
                    : 'text-red-600 dark:text-red-400'
                }`}
              >
                {transaction.type === 'income' ? '+' : '-'}
                {Math.abs(transaction.amount)}
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
