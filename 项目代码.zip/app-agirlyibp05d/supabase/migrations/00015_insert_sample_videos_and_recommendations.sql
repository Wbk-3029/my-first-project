-- 插入示例热门视频数据
INSERT INTO hot_videos (title, cover_image, video_url, publisher_id, view_count, like_count)
SELECT 
  '技能分享：' || skill_name,
  'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=400',
  'https://example.com/video/' || gen_random_uuid(),
  id,
  floor(random() * 1000 + 100)::int,
  floor(random() * 200 + 20)::int
FROM (
  SELECT 
    p.id,
    CASE 
      WHEN random() < 0.2 THEN 'PS修图技巧'
      WHEN random() < 0.4 THEN '吉他弹唱教学'
      WHEN random() < 0.6 THEN '英语口语练习'
      WHEN random() < 0.8 THEN '编程入门指南'
      ELSE '摄影构图技巧'
    END as skill_name
  FROM profiles p
  LIMIT 8
) sub
ON CONFLICT DO NOTHING;

-- 插入示例推荐内容
INSERT INTO recommendations (title, cover_image, description, link, is_paid, sort_weight)
VALUES
  (
    '新手福利：免费领取50技易点',
    'https://images.unsplash.com/photo-1607827448387-a67db1383b59?w=400',
    '完成新手引导任务，立即获得50技易点奖励，开启你的技能交换之旅！',
    '/onboarding',
    true,
    100
  ),
  (
    '热门技能推荐：PS修图速成',
    'https://images.unsplash.com/photo-1626785774573-4b799315345d?w=400',
    '从零开始学习PS修图，掌握基础工具和实用技巧，让你的照片更出彩。',
    '/skills',
    true,
    90
  ),
  (
    '技能交换指南',
    'https://images.unsplash.com/photo-1552664730-d307ca884978?w=400',
    '了解如何在技遇平台高效交换技能，快速找到合适的交换伙伴。',
    '/forum',
    false,
    80
  )
ON CONFLICT DO NOTHING;