import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { MainLayout } from '@/components/layouts/MainLayout';
import { PageHeader } from '@/components/layouts/PageHeader';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { getNotifications, markNotificationAsRead, markAllNotificationsAsRead } from '@/db/api';
import type { Notification } from '@/types';
import { 
  Bell, 
  CheckCheck, 
  UserPlus, 
  Repeat, 
  Clock, 
  Star, 
  TrendingUp, 
  TrendingDown,
  Coins,
  AlertCircle
} from 'lucide-react';
import { toast } from 'sonner';
import { formatDistanceToNow } from 'date-fns';
import { zhCN } from 'date-fns/locale';

export default function NotificationsPage() {
  const navigate = useNavigate();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('all');

  useEffect(() => {
    loadNotifications();
  }, []);

  const loadNotifications = async () => {
    try {
      setLoading(true);
      const data = await getNotifications();
      setNotifications(data);
    } catch (error) {
      console.error('加载通知失败:', error);
      toast.error('加载通知失败');
    } finally {
      setLoading(false);
    }
  };

  const handleMarkAsRead = async (notificationId: string) => {
    try {
      await markNotificationAsRead(notificationId);
      setNotifications((prev) =>
        prev.map((n) => (n.id === notificationId ? { ...n, is_read: true } : n))
      );
    } catch (error) {
      console.error('标记已读失败:', error);
    }
  };

  const handleMarkAllAsRead = async () => {
    try {
      const result = await markAllNotificationsAsRead();
      setNotifications((prev) => prev.map((n) => ({ ...n, is_read: true })));
      toast.success(result.message);
    } catch (error) {
      console.error('标记全部已读失败:', error);
      toast.error('操作失败');
    }
  };

  const handleNotificationClick = (notification: Notification) => {
    if (!notification.is_read) {
      handleMarkAsRead(notification.id);
    }

    // 根据action_url跳转
    if (notification.action_url) {
      navigate(notification.action_url);
      return;
    }

    // 兼容旧数据
    if (notification.type === 'friend_request') {
      navigate('/friend-requests');
    } else if (
      (notification.type === 'exchange_request' || 
       notification.type === 'exchange_accepted' || 
       notification.type === 'exchange_rejected') && 
      notification.related_id
    ) {
      navigate(`/exchanges/${notification.related_id}`);
    }
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'friend_request':
        return <UserPlus className="h-5 w-5 text-blue-500" />;
      case 'exchange_request':
        return <Repeat className="h-5 w-5 text-purple-500" />;
      case 'exchange_accepted':
        return <CheckCheck className="h-5 w-5 text-green-500" />;
      case 'exchange_rejected':
        return <AlertCircle className="h-5 w-5 text-red-500" />;
      case 'exchange_reminder':
        return <Clock className="h-5 w-5 text-orange-500" />;
      case 'rating_reminder':
        return <Star className="h-5 w-5 text-yellow-500" />;
      case 'credit_change':
        return <TrendingUp className="h-5 w-5 text-green-500" />;
      case 'points_change':
        return <Coins className="h-5 w-5 text-amber-500" />;
      case 'system':
        return <Bell className="h-5 w-5 text-primary" />;
      default:
        return <Bell className="h-5 w-5 text-muted-foreground" />;
    }
  };

  const getNotificationTypeName = (type: string) => {
    switch (type) {
      case 'friend_request':
        return '好友申请';
      case 'exchange_request':
        return '交换申请';
      case 'exchange_accepted':
        return '申请同意';
      case 'exchange_rejected':
        return '申请拒绝';
      case 'exchange_reminder':
        return '交换提醒';
      case 'rating_reminder':
        return '评价提醒';
      case 'credit_change':
        return '信用分变化';
      case 'points_change':
        return '技易点变动';
      case 'system':
        return '系统通知';
      default:
        return '通知';
    }
  };

  const filteredNotifications = notifications.filter((n) => {
    if (activeTab === 'all') return true;
    if (activeTab === 'unread') return !n.is_read;
    if (activeTab === 'exchange') {
      return ['exchange_request', 'exchange_accepted', 'exchange_rejected', 'exchange_reminder'].includes(n.type);
    }
    if (activeTab === 'system') {
      return ['credit_change', 'points_change', 'system', 'rating_reminder'].includes(n.type);
    }
    return n.type === activeTab;
  });

  const unreadCount = notifications.filter((n) => !n.is_read).length;

  return (
    <MainLayout>
      <PageHeader title="消息通知" />

      <div className="space-y-4">
        {/* 操作栏 */}
        <div className="flex items-center justify-between">
          <div className="text-sm text-muted-foreground">
            {unreadCount > 0 ? `${unreadCount} 条未读` : '暂无未读消息'}
          </div>
          {unreadCount > 0 && (
            <Button size="sm" variant="outline" className="gap-2" onClick={handleMarkAllAsRead}>
              <CheckCheck className="h-4 w-4" />
              全部已读
            </Button>
          )}
        </div>

        {/* 分类标签 */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="all">全部</TabsTrigger>
            <TabsTrigger value="unread">
              未读
              {unreadCount > 0 && (
                <Badge variant="destructive" className="ml-1 h-5 min-w-5 px-1 text-xs">
                  {unreadCount}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="exchange">交换</TabsTrigger>
            <TabsTrigger value="system">系统</TabsTrigger>
          </TabsList>

          <TabsContent value={activeTab} className="mt-4 space-y-3">
            {loading ? (
              // 骨架屏
              Array.from({ length: 5 }).map((_, i) => (
                <Card key={i}>
                  <CardContent className="p-4">
                    <div className="flex gap-3">
                      <Skeleton className="h-10 w-10 rounded-full shrink-0 bg-muted" />
                      <div className="flex-1 space-y-2">
                        <Skeleton className="h-4 w-3/4 bg-muted" />
                        <Skeleton className="h-3 w-full bg-muted" />
                        <Skeleton className="h-3 w-1/2 bg-muted" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : filteredNotifications.length === 0 ? (
              // 空状态
              <Card>
                <CardContent className="p-12 text-center">
                  <Bell className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <p className="text-muted-foreground">暂无通知</p>
                </CardContent>
              </Card>
            ) : (
              // 通知列表
              filteredNotifications.map((notification) => (
                <Card
                  key={notification.id}
                  className={`cursor-pointer transition-all hover:shadow-md ${
                    !notification.is_read ? 'border-primary/50 bg-primary/5' : ''
                  }`}
                  onClick={() => handleNotificationClick(notification)}
                >
                  <CardContent className="p-4">
                    <div className="flex gap-3">
                      {/* 图标 */}
                      <div className="shrink-0">
                        <div className="h-10 w-10 rounded-full bg-muted flex items-center justify-center">
                          {getNotificationIcon(notification.type)}
                        </div>
                      </div>

                      {/* 内容 */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2 mb-1">
                          <h3
                            className={`text-sm font-medium ${
                              !notification.is_read ? 'font-semibold' : ''
                            }`}
                          >
                            {notification.title}
                          </h3>
                          {!notification.is_read && (
                            <div className="h-2 w-2 rounded-full bg-destructive shrink-0 mt-1" />
                          )}
                        </div>

                        {notification.content && (
                          <p className="text-sm text-muted-foreground line-clamp-2 mb-2">
                            {notification.content}
                          </p>
                        )}

                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <Badge variant="outline" className="text-xs">
                            {getNotificationTypeName(notification.type)}
                          </Badge>
                          <span>•</span>
                          <span>
                            {formatDistanceToNow(new Date(notification.created_at), {
                              addSuffix: true,
                              locale: zhCN,
                            })}
                          </span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  );
}
