// 信用分等级定义
export const CREDIT_LEVELS = [
  { min: 0, max: 60, label: '新手', color: 'text-muted-foreground', bgColor: 'bg-muted' },
  { min: 60, max: 80, label: '可信', color: 'text-blue-600', bgColor: 'bg-blue-100' },
  { min: 80, max: 95, label: '优秀', color: 'text-purple-600', bgColor: 'bg-purple-100' },
  { min: 95, max: 100, label: '大神', color: 'text-amber-600', bgColor: 'bg-amber-100' },
];

// 根据信用分获取等级
export function getCreditLevel(score: number) {
  return CREDIT_LEVELS.find((level) => score >= level.min && score <= level.max) || CREDIT_LEVELS[0];
}

// 技易点类型标签
export const POINT_TYPE_LABELS: Record<string, string> = {
  publish_skill: '发布技能',
  complete_exchange: '完成交换',
  good_rating: '获得好评',
  point_exchange: '技易点交换',
  group_buy: '团购交换',
  onboarding_reward: '新手引导奖励',
  system_reward: '系统奖励',
  system_deduct: '系统扣除',
};

// 信用分类型标签
export const CREDIT_TYPE_LABELS: Record<string, string> = {
  good_rating: '获得好评',
  bad_rating: '获得差评',
  complete_exchange: '完成交换',
  breach_contract: '违约',
  system_adjust: '系统调整',
};
