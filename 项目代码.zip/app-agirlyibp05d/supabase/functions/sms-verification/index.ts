// 短信验证码服务
// 支持发送和验证短信验证码

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface SendCodeRequest {
  mobile: string;
  sessionId?: string;
}

interface VerifyCodeRequest {
  mobile: string;
  sessionId: string;
  code: string;
}

Deno.serve(async (req) => {
  // 处理CORS预检请求
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const path = url.pathname;
    const apiKey = Deno.env.get('INTEGRATIONS_API_KEY');

    if (!apiKey) {
      throw new Error('INTEGRATIONS_API_KEY未配置');
    }

    // 发送验证码
    if (path.endsWith('/send') && req.method === 'POST') {
      const body: SendCodeRequest = await req.json();
      const { mobile, sessionId } = body;

      if (!mobile) {
        return new Response(
          JSON.stringify({ error: '手机号不能为空' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // 调用发送短信验证码API
      const response = await fetch(
        'https://app-agirlyibp05d-api-W9z3M74x6ZNL-gateway.appmiaoda.com/v1/code/send_message',
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Gateway-Authorization': `Bearer ${apiKey}`,
          },
          body: JSON.stringify({
            mobile,
            sessionId: sessionId || undefined,
          }),
        }
      );

      const result = await response.json();

      // 检查配额和余额错误
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: '发送频率过高,请稍后再试' }),
          { status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: '服务余额不足,请联系管理员' }),
          { status: 402, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      if (result.status !== 0) {
        return new Response(
          JSON.stringify({ error: result.msg || '发送失败' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      return new Response(
        JSON.stringify({
          success: true,
          sessionId: result.data.sessionId,
          message: '验证码已发送',
        }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // 验证验证码
    if (path.endsWith('/verify') && req.method === 'POST') {
      const body: VerifyCodeRequest = await req.json();
      const { mobile, sessionId, code } = body;

      if (!mobile || !sessionId || !code) {
        return new Response(
          JSON.stringify({ error: '手机号、sessionId和验证码不能为空' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // 调用验证短信验证码API
      const response = await fetch(
        'https://app-agirlyibp05d-api-Xa6JZxjyqK0a-gateway.appmiaoda.com/v1/code/verify_message_code',
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Gateway-Authorization': `Bearer ${apiKey}`,
          },
          body: JSON.stringify({
            mobile,
            sessionId,
            code,
          }),
        }
      );

      const result = await response.json();

      if (result.status !== 0) {
        return new Response(
          JSON.stringify({ error: result.msg || '验证失败' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      return new Response(
        JSON.stringify({
          success: true,
          message: '验证成功',
        }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    return new Response(
      JSON.stringify({ error: '不支持的请求路径' }),
      { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('短信验证码服务错误:', error);
    return new Response(
      JSON.stringify({ error: error.message || '服务器错误' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
