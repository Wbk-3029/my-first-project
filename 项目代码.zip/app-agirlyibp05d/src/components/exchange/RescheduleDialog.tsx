import { useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Calendar } from '@/components/ui/calendar';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { createRescheduleRequest } from '@/db/api';
import { CalendarIcon, Clock } from 'lucide-react';
import { format, addDays } from 'date-fns';
import { zhCN } from 'date-fns/locale';
import { toast } from 'sonner';

interface RescheduleDialogProps {
  exchangeId: string;
  currentStartTime: string;
  trigger?: React.ReactNode;
  onSuccess?: () => void;
}

export function RescheduleDialog({
  exchangeId,
  currentStartTime,
  trigger,
  onSuccess,
}: RescheduleDialogProps) {
  const [open, setOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    date: undefined as Date | undefined,
    timeSlot: '',
    reason: '',
  });

  const timeSlots = [
    '08:00-09:00',
    '09:00-10:00',
    '10:00-11:00',
    '11:00-12:00',
    '13:00-14:00',
    '14:00-15:00',
    '15:00-16:00',
    '16:00-17:00',
    '17:00-18:00',
    '18:00-19:00',
    '19:00-20:00',
    '20:00-21:00',
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.date || !formData.timeSlot || !formData.reason.trim()) {
      toast.error('请填写完整信息');
      return;
    }

    try {
      setSubmitting(true);

      // 组合日期和时间
      const [startHour] = formData.timeSlot.split('-')[0].split(':');
      const newStartTime = new Date(formData.date);
      newStartTime.setHours(parseInt(startHour), 0, 0, 0);

      const result = await createRescheduleRequest({
        exchangeId,
        newStartTime: newStartTime.toISOString(),
        reason: formData.reason,
      });

      toast.success(result.message);
      setOpen(false);
      setFormData({ date: undefined, timeSlot: '', reason: '' });
      onSuccess?.();
    } catch (error: any) {
      toast.error(error.message || '提交失败');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger || (
          <Button variant="outline" className="gap-2">
            <Clock className="h-4 w-4" />
            申请改期
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>申请改期</DialogTitle>
          <DialogDescription>
            当前约定时间：
            {format(new Date(currentStartTime), 'yyyy-MM-dd HH:mm', { locale: zhCN })}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* 选择日期 */}
          <div className="space-y-2">
            <Label>新的日期</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className="w-full justify-start text-left font-normal"
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {formData.date ? (
                    format(formData.date, 'yyyy-MM-dd', { locale: zhCN })
                  ) : (
                    <span>选择日期</span>
                  )}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={formData.date}
                  onSelect={(date) => setFormData((prev) => ({ ...prev, date }))}
                  disabled={(date) => {
                    const today = new Date();
                    today.setHours(0, 0, 0, 0);
                    const maxDate = addDays(today, 7);
                    return date < today || date > maxDate;
                  }}
                  locale={zhCN}
                />
              </PopoverContent>
            </Popover>
            <p className="text-xs text-muted-foreground">
              支持预约未来7天内的时段
            </p>
          </div>

          {/* 选择时间段 */}
          <div className="space-y-2">
            <Label>时间段</Label>
            <Select
              value={formData.timeSlot}
              onValueChange={(value) =>
                setFormData((prev) => ({ ...prev, timeSlot: value }))
              }
            >
              <SelectTrigger>
                <SelectValue placeholder="选择时间段" />
              </SelectTrigger>
              <SelectContent>
                {timeSlots.map((slot) => (
                  <SelectItem key={slot} value={slot}>
                    {slot}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* 改期原因 */}
          <div className="space-y-2">
            <Label htmlFor="reason">改期原因</Label>
            <Textarea
              id="reason"
              placeholder="请说明改期原因..."
              value={formData.reason}
              onChange={(e) =>
                setFormData((prev) => ({ ...prev, reason: e.target.value }))
              }
              rows={3}
              className="resize-none"
            />
          </div>

          {/* 提交按钮 */}
          <div className="flex gap-3">
            <Button
              type="button"
              variant="outline"
              onClick={() => setOpen(false)}
              className="flex-1"
            >
              取消
            </Button>
            <Button type="submit" disabled={submitting} className="flex-1">
              {submitting ? '提交中...' : '发起申请'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
