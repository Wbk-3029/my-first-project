-- 添加连续签到天数字段
ALTER TABLE sign_ins ADD COLUMN IF NOT EXISTS continuous_days INT NOT NULL DEFAULT 1;

-- 创建签到RPC函数
CREATE OR REPLACE FUNCTION daily_sign_in(p_user_id UUID)
RETURNS JSON AS $$
DECLARE
  v_today DATE;
  v_yesterday DATE;
  v_last_sign_date DATE;
  v_continuous_days INT;
  v_already_signed BOOLEAN;
  v_result JSON;
BEGIN
  v_today := CURRENT_DATE;
  v_yesterday := v_today - INTERVAL '1 day';
  
  -- 检查今天是否已签到
  SELECT EXISTS(
    SELECT 1 FROM sign_ins 
    WHERE user_id = p_user_id AND sign_date = v_today
  ) INTO v_already_signed;
  
  IF v_already_signed THEN
    -- 获取今天的连续天数
    SELECT continuous_days INTO v_continuous_days
    FROM sign_ins
    WHERE user_id = p_user_id AND sign_date = v_today;
    
    v_result := json_build_object(
      'success', false,
      'message', '今日已签到',
      'continuous_days', v_continuous_days
    );
    RETURN v_result;
  END IF;
  
  -- 获取最后一次签到日期
  SELECT sign_date INTO v_last_sign_date
  FROM sign_ins
  WHERE user_id = p_user_id
  ORDER BY sign_date DESC
  LIMIT 1;
  
  -- 计算连续签到天数
  IF v_last_sign_date IS NULL THEN
    -- 首次签到
    v_continuous_days := 1;
  ELSIF v_last_sign_date = v_yesterday THEN
    -- 连续签到
    SELECT continuous_days + 1 INTO v_continuous_days
    FROM sign_ins
    WHERE user_id = p_user_id AND sign_date = v_last_sign_date;
  ELSE
    -- 中断后重新开始
    v_continuous_days := 1;
  END IF;
  
  -- 记录签到
  INSERT INTO sign_ins (user_id, sign_date, continuous_days)
  VALUES (p_user_id, v_today, v_continuous_days);
  
  -- 添加5积分
  PERFORM add_integral(
    p_user_id,
    5,
    '每日签到',
    NULL,
    365
  );
  
  v_result := json_build_object(
    'success', true,
    'message', '签到成功！获得5技易点',
    'continuous_days', v_continuous_days,
    'integral_earned', 5
  );
  
  RETURN v_result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 获取用户签到信息
CREATE OR REPLACE FUNCTION get_sign_in_info(p_user_id UUID)
RETURNS JSON AS $$
DECLARE
  v_today DATE;
  v_already_signed BOOLEAN;
  v_continuous_days INT;
  v_total_days INT;
  v_result JSON;
BEGIN
  v_today := CURRENT_DATE;
  
  -- 检查今天是否已签到
  SELECT EXISTS(
    SELECT 1 FROM sign_ins 
    WHERE user_id = p_user_id AND sign_date = v_today
  ) INTO v_already_signed;
  
  -- 获取连续签到天数
  IF v_already_signed THEN
    SELECT continuous_days INTO v_continuous_days
    FROM sign_ins
    WHERE user_id = p_user_id AND sign_date = v_today;
  ELSE
    -- 获取最后一次签到的连续天数
    SELECT 
      CASE 
        WHEN sign_date = v_today - INTERVAL '1 day' THEN continuous_days
        ELSE 0
      END INTO v_continuous_days
    FROM sign_ins
    WHERE user_id = p_user_id
    ORDER BY sign_date DESC
    LIMIT 1;
    
    IF v_continuous_days IS NULL THEN
      v_continuous_days := 0;
    END IF;
  END IF;
  
  -- 获取总签到天数
  SELECT COUNT(*) INTO v_total_days
  FROM sign_ins
  WHERE user_id = p_user_id;
  
  v_result := json_build_object(
    'already_signed', v_already_signed,
    'continuous_days', COALESCE(v_continuous_days, 0),
    'total_days', COALESCE(v_total_days, 0)
  );
  
  RETURN v_result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;