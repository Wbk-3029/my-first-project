-- 添加required_skills字段到skills表
ALTER TABLE skills ADD COLUMN IF NOT EXISTS required_skills TEXT;