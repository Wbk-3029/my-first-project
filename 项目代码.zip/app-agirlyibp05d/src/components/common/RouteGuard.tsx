import { useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useLoginDialog } from '@/contexts/LoginDialogContext';

interface RouteGuardProps {
  children: React.ReactNode;
}

// Please add the pages that can be accessed without logging in to PUBLIC_ROUTES.
const PUBLIC_ROUTES = ['/login', '/403', '/404', '/', '/forum', '/forum/*', '/skills', '/skills/*', '/onboarding'];

function matchPublicRoute(path: string, patterns: string[]) {
  return patterns.some((pattern) => {
    if (pattern.includes('*')) {
      const regex = new RegExp('^' + pattern.replace('*', '.*') + '$');
      return regex.test(path);
    }
    return path === pattern;
  });
}

export function RouteGuard({ children }: RouteGuardProps) {
  const { user, profile, loading } = useAuth();
  const { openLoginDialog } = useLoginDialog();
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    if (loading) return;

    const isPublic = matchPublicRoute(location.pathname, PUBLIC_ROUTES);

    // 未登录且访问非公开页面
    if (!user && !isPublic) {
      openLoginDialog();
      navigate('/', { replace: true });
      return;
    }

    // 已登录但未完成新手引导，且不在新手引导页面
    if (user && profile && !profile.onboarding_completed && location.pathname !== '/onboarding') {
      navigate('/onboarding', { replace: true });
      return;
    }

    // 已完成新手引导但访问新手引导页面，跳转到首页
    if (user && profile && profile.onboarding_completed && location.pathname === '/onboarding') {
      navigate('/', { replace: true });
    }
  }, [user, profile, loading, location.pathname, navigate, openLoginDialog]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return <>{children}</>;
}