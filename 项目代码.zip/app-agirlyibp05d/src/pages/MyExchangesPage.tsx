import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { MainLayout } from '@/components/layouts/MainLayout';
import { Card } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  getReceivedExchangeRequests,
  getMyExchanges,
  getExchangeStats,
  type ExchangeRequest,
  type ExchangeWithDetails,
} from '@/db/api';
import { Clock, Calendar, ChevronRight, Package } from 'lucide-react';
import { format } from 'date-fns';
import { zhCN } from 'date-fns/locale';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';

export default function MyExchangesPage() {
  const { profile } = useAuth();
  const [pendingRequests, setPendingRequests] = useState<ExchangeRequest[]>([]);
  const [inProgressExchanges, setInProgressExchanges] = useState<ExchangeWithDetails[]>([]);
  const [completedExchanges, setCompletedExchanges] = useState<ExchangeWithDetails[]>([]);
  const [stats, setStats] = useState({ pending: 0, in_progress: 0, completed: 0 });
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('pending');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const [pendingData, inProgressData, completedData, statsData] = await Promise.all([
        getReceivedExchangeRequests('pending'),
        getMyExchanges('in_progress'),
        getMyExchanges('completed'),
        getExchangeStats(),
      ]);
      setPendingRequests(pendingData);
      setInProgressExchanges(inProgressData);
      setCompletedExchanges(completedData);
      setStats(statsData);
    } catch (error) {
      toast.error('加载失败');
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status: string) => {
    const statusMap = {
      pending: { label: '待确认', variant: 'default' as const, color: 'text-yellow-600' },
      in_progress: { label: '进行中', variant: 'default' as const, color: 'text-blue-600' },
      completed: { label: '已完成', variant: 'secondary' as const, color: 'text-green-600' },
    };
    const config = statusMap[status as keyof typeof statusMap] || statusMap.pending;
    return (
      <Badge variant={config.variant} className={config.color}>
        {config.label}
      </Badge>
    );
  };

  const RequestCard = ({ request }: { request: ExchangeRequest }) => {
    const otherUser = request.from_user;

    return (
      <Link to={`/exchange-requests`}>
        <Card className="rounded-xl overflow-hidden hover:shadow-md transition-shadow">
          <div className="p-4">
            <div className="flex items-center gap-3 mb-3">
              <Avatar className="h-10 w-10">
                <AvatarImage src={otherUser?.avatar_url || undefined} />
                <AvatarFallback>{otherUser?.nickname?.[0] || '用'}</AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <div className="font-medium truncate">{otherUser?.nickname || '匿名用户'}</div>
                <div className="text-xs text-muted-foreground">向你发起交换申请</div>
              </div>
              {getStatusBadge('pending')}
            </div>

            <div className="p-3 bg-muted/50 rounded-lg space-y-2">
              <div className="flex items-center gap-2">
                <Package className="h-4 w-4 text-muted-foreground" />
                <span className="font-medium">{request.skill?.name}</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Calendar className="h-3.5 w-3.5" />
                <span>
                  {format(new Date(request.start_time), 'yyyy-MM-dd HH:mm', { locale: zhCN })}
                </span>
              </div>
            </div>

            <div className="flex items-center justify-end mt-3 text-sm text-primary">
              <span>查看详情</span>
              <ChevronRight className="h-4 w-4" />
            </div>
          </div>
        </Card>
      </Link>
    );
  };

  const ExchangeCard = ({ exchange }: { exchange: ExchangeWithDetails }) => {
    const isInitiator = profile?.id === exchange.initiator_id;
    const otherUser = isInitiator ? exchange.receiver : exchange.initiator;
    const skill = isInitiator ? exchange.receiver_skill : exchange.initiator_skill;

    return (
      <Link to={`/exchanges/${exchange.id}`}>
        <Card className="rounded-xl overflow-hidden hover:shadow-md transition-shadow">
          <div className="p-4">
            <div className="flex items-center gap-3 mb-3">
              <Avatar className="h-10 w-10">
                <AvatarImage src={otherUser?.avatar_url || undefined} />
                <AvatarFallback>{otherUser?.nickname?.[0] || '用'}</AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <div className="font-medium truncate">{otherUser?.nickname || '匿名用户'}</div>
                <div className="text-xs text-muted-foreground">
                  {isInitiator ? '你发起的交换' : '对方发起的交换'}
                </div>
              </div>
              {getStatusBadge(exchange.status)}
            </div>

            <div className="p-3 bg-muted/50 rounded-lg space-y-2">
              <div className="flex items-center gap-2">
                <Package className="h-4 w-4 text-muted-foreground" />
                <span className="font-medium">{skill?.name || '未知技能'}</span>
              </div>
              {exchange.start_time && (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Calendar className="h-3.5 w-3.5" />
                  <span>
                    {format(new Date(exchange.start_time), 'yyyy-MM-dd HH:mm', { locale: zhCN })}
                  </span>
                </div>
              )}
              {exchange.completed_at && (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Clock className="h-3.5 w-3.5" />
                  <span>
                    完成于 {format(new Date(exchange.completed_at), 'yyyy-MM-dd HH:mm', { locale: zhCN })}
                  </span>
                </div>
              )}
            </div>

            <div className="flex items-center justify-end mt-3 text-sm text-primary">
              <span>查看详情</span>
              <ChevronRight className="h-4 w-4" />
            </div>
          </div>
        </Card>
      </Link>
    );
  };

  if (loading) {
    return (
      <MainLayout>
        <div className="space-y-4">
          <Skeleton className="h-8 w-48 bg-muted" />
          <Skeleton className="h-40 w-full rounded-xl bg-muted" />
          <Skeleton className="h-40 w-full rounded-xl bg-muted" />
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="space-y-4">
        <h1 className="text-title-lg">我的交换</h1>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="pending">
              待处理
              {stats.pending > 0 && (
                <Badge variant="destructive" className="ml-2">
                  {stats.pending}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="in_progress">
              进行中
              {stats.in_progress > 0 && (
                <Badge variant="default" className="ml-2">
                  {stats.in_progress}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="completed">已完成</TabsTrigger>
          </TabsList>

          <TabsContent value="pending" className="space-y-3 mt-4">
            {pendingRequests.length > 0 ? (
              pendingRequests.map((request) => (
                <RequestCard key={request.id} request={request} />
              ))
            ) : (
              <Card className="rounded-xl">
                <div className="p-12 text-center text-muted-foreground">
                  暂无待处理的交换申请
                </div>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="in_progress" className="space-y-3 mt-4">
            {inProgressExchanges.length > 0 ? (
              inProgressExchanges.map((exchange) => (
                <ExchangeCard key={exchange.id} exchange={exchange} />
              ))
            ) : (
              <Card className="rounded-xl">
                <div className="p-12 text-center text-muted-foreground">
                  暂无进行中的交换
                </div>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="completed" className="space-y-3 mt-4">
            {completedExchanges.length > 0 ? (
              completedExchanges.map((exchange) => (
                <ExchangeCard key={exchange.id} exchange={exchange} />
              ))
            ) : (
              <Card className="rounded-xl">
                <div className="p-12 text-center text-muted-foreground">
                  暂无已完成的交换
                </div>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  );
}
