import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { MainLayout } from '@/components/layouts/MainLayout';
import { PageHeader } from '@/components/layouts/PageHeader';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Skeleton } from '@/components/ui/skeleton';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { getFriends, deleteFriend } from '@/db/api';
import { Search, MessageCircle, UserMinus, Award } from 'lucide-react';
import { toast } from 'sonner';
import { formatDistanceToNow } from 'date-fns';
import { zhCN } from 'date-fns/locale';

interface Friend {
  friend_profile_id: string;
  friend_nickname: string;
  friend_avatar_url: string | null;
  friend_credit_score: number;
  last_message_time: string | null;
  unread_count: number;
}

export default function FriendsPage() {
  const [friends, setFriends] = useState<Friend[]>([]);
  const [filteredFriends, setFilteredFriends] = useState<Friend[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    loadFriends();
  }, []);

  useEffect(() => {
    if (searchQuery) {
      const filtered = friends.filter((f) =>
        f.friend_nickname?.toLowerCase().includes(searchQuery.toLowerCase())
      );
      setFilteredFriends(filtered);
    } else {
      setFilteredFriends(friends);
    }
  }, [searchQuery, friends]);

  const loadFriends = async () => {
    try {
      setLoading(true);
      const data = await getFriends();
      setFriends(data);
      setFilteredFriends(data);
    } catch (error) {
      console.error('加载好友列表失败:', error);
      toast.error('加载好友列表失败');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteFriend = async (friendId: string, friendName: string) => {
    try {
      await deleteFriend(friendId);
      toast.success(`已删除好友 ${friendName}`);
      loadFriends();
    } catch (error) {
      console.error('删除好友失败:', error);
      toast.error('删除好友失败');
    }
  };

  return (
    <MainLayout>
      <PageHeader title="我的好友" />

      <div className="space-y-6">
        {/* 搜索栏 */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="搜索好友昵称..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>

        {/* 好友列表 */}
        {loading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <Card key={i}>
                <CardContent className="p-4">
                  <div className="flex items-center gap-4">
                    <Skeleton className="h-12 w-12 rounded-full bg-muted" />
                    <div className="flex-1 space-y-2">
                      <Skeleton className="h-4 w-24 bg-muted" />
                      <Skeleton className="h-3 w-32 bg-muted" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : filteredFriends.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center text-muted-foreground">
              {searchQuery ? '未找到匹配的好友' : '暂无好友，快去添加吧！'}
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-3">
            {filteredFriends.map((friend) => (
              <Card key={friend.friend_profile_id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-center gap-4">
                    {/* 头像 */}
                    <Link to={`/profile/${friend.friend_profile_id}`}>
                      <Avatar className="h-12 w-12">
                        <AvatarImage src={friend.friend_avatar_url || undefined} />
                        <AvatarFallback>
                          {friend.friend_nickname?.[0] || '友'}
                        </AvatarFallback>
                      </Avatar>
                    </Link>

                    {/* 信息 */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <Link
                          to={`/profile/${friend.friend_profile_id}`}
                          className="font-medium hover:text-primary transition-colors"
                        >
                          {friend.friend_nickname || '未知用户'}
                        </Link>
                        <div className="flex items-center gap-1 text-xs text-muted-foreground">
                          <Award className="h-3 w-3" />
                          <span>{friend.friend_credit_score}</span>
                        </div>
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {friend.last_message_time
                          ? `最近联系: ${formatDistanceToNow(new Date(friend.last_message_time), {
                              addSuffix: true,
                              locale: zhCN,
                            })}`
                          : '暂无消息'}
                      </div>
                    </div>

                    {/* 未读消息标识 */}
                    {friend.unread_count > 0 && (
                      <Badge variant="destructive" className="shrink-0">
                        {friend.unread_count}
                      </Badge>
                    )}

                    {/* 操作按钮 */}
                    <div className="flex items-center gap-2 shrink-0">
                      <Button
                        asChild
                        size="sm"
                        variant="default"
                        className="gap-1"
                      >
                        <Link to={`/messages/${friend.friend_profile_id}`}>
                          <MessageCircle className="h-4 w-4" />
                          发消息
                        </Link>
                      </Button>

                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button size="sm" variant="ghost" className="gap-1 text-destructive hover:text-destructive">
                            <UserMinus className="h-4 w-4" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>确认删除好友？</AlertDialogTitle>
                            <AlertDialogDescription>
                              删除后将无法查看对方信息，聊天记录也将被清空。
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>取消</AlertDialogCancel>
                            <AlertDialogAction
                              onClick={() => handleDeleteFriend(friend.friend_profile_id, friend.friend_nickname)}
                            >
                              确认删除
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </MainLayout>
  );
}
