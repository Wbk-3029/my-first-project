-- 为profiles表添加兴趣标签字段
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS interest_tags text[] DEFAULT '{}';
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS want_to_learn text[] DEFAULT '{}';
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS can_teach text[] DEFAULT '{}';

-- 添加注释
COMMENT ON COLUMN profiles.interest_tags IS '兴趣标签';
COMMENT ON COLUMN profiles.want_to_learn IS '我想学的技能';
COMMENT ON COLUMN profiles.can_teach IS '我能教的技能';

-- 创建RPC函数：获取推荐技能
CREATE OR REPLACE FUNCTION get_recommended_skills(
  p_user_id uuid DEFAULT NULL,
  p_limit int DEFAULT 10
) RETURNS TABLE (
  skill_id uuid,
  skill_name text,
  skill_description text,
  skill_type text,
  skill_price numeric,
  provider_id uuid,
  provider_nickname text,
  provider_avatar text,
  provider_credit int,
  exchange_count bigint,
  match_score numeric
) AS $$
DECLARE
  v_user_profile record;
  v_user_id uuid;
BEGIN
  -- 如果未传入用户ID，使用当前登录用户
  v_user_id := COALESCE(p_user_id, auth.uid());

  -- 如果用户未登录，返回热门技能
  IF v_user_id IS NULL THEN
    RETURN QUERY
    SELECT 
      s.id AS skill_id,
      s.name AS skill_name,
      s.description AS skill_description,
      s.type AS skill_type,
      s.price AS skill_price,
      p.id AS provider_id,
      p.nickname AS provider_nickname,
      p.avatar_url AS provider_avatar,
      p.credit_score AS provider_credit,
      COUNT(DISTINCT e.id) AS exchange_count,
      50.0 AS match_score
    FROM skills s
    JOIN profiles p ON s.user_id = p.id
    LEFT JOIN exchanges e ON s.id = e.skill_id AND e.status = 'completed'
    WHERE s.status = 'active'
    GROUP BY s.id, s.name, s.description, s.type, s.price, p.id, p.nickname, p.avatar_url, p.credit_score
    ORDER BY COUNT(DISTINCT e.id) DESC, p.credit_score DESC
    LIMIT p_limit;
    RETURN;
  END IF;

  -- 获取用户信息
  SELECT * INTO v_user_profile
  FROM profiles
  WHERE id = v_user_id;

  -- 如果用户不存在，返回空
  IF v_user_profile IS NULL THEN
    RETURN;
  END IF;

  -- 推荐算法
  RETURN QUERY
  WITH user_exchanges AS (
    -- 用户历史交换的技能
    SELECT DISTINCT s.type, s.name
    FROM exchanges e
    JOIN skills s ON e.skill_id = s.id
    WHERE (e.initiator_id = v_user_id OR e.receiver_id = v_user_id)
      AND e.status = 'completed'
  ),
  skill_scores AS (
    SELECT 
      s.id AS skill_id,
      s.name AS skill_name,
      s.description AS skill_description,
      s.type AS skill_type,
      s.price AS skill_price,
      p.id AS provider_id,
      p.nickname AS provider_nickname,
      p.avatar_url AS provider_avatar,
      p.credit_score AS provider_credit,
      COUNT(DISTINCT e.id) AS exchange_count,
      -- 计算匹配分数
      (
        -- 基于"我想学的技能"匹配（40分）
        CASE 
          WHEN v_user_profile.want_to_learn IS NOT NULL 
            AND s.name = ANY(v_user_profile.want_to_learn) 
          THEN 40
          WHEN v_user_profile.want_to_learn IS NOT NULL 
            AND s.type IN (
              SELECT DISTINCT s2.type 
              FROM skills s2 
              WHERE s2.name = ANY(v_user_profile.want_to_learn)
            )
          THEN 20
          ELSE 0
        END
        +
        -- 基于兴趣标签匹配（30分）
        CASE 
          WHEN v_user_profile.interest_tags IS NOT NULL 
            AND s.type = ANY(v_user_profile.interest_tags) 
          THEN 30
          ELSE 0
        END
        +
        -- 基于历史交换记录匹配（20分）
        CASE 
          WHEN EXISTS (
            SELECT 1 FROM user_exchanges ue 
            WHERE ue.type = s.type
          )
          THEN 20
          ELSE 0
        END
        +
        -- 基于提供者信用分（10分）
        CASE 
          WHEN p.credit_score >= 90 THEN 10
          WHEN p.credit_score >= 80 THEN 8
          WHEN p.credit_score >= 70 THEN 6
          WHEN p.credit_score >= 60 THEN 4
          ELSE 2
        END
      ) AS match_score
    FROM skills s
    JOIN profiles p ON s.user_id = p.id
    LEFT JOIN exchanges e ON s.id = e.skill_id AND e.status = 'completed'
    WHERE s.status = 'active'
      AND s.user_id != v_user_id  -- 排除自己发布的技能
    GROUP BY s.id, s.name, s.description, s.type, s.price, p.id, p.nickname, p.avatar_url, p.credit_score
  )
  SELECT *
  FROM skill_scores
  WHERE match_score > 0  -- 只返回有匹配分数的技能
  ORDER BY match_score DESC, exchange_count DESC, provider_credit DESC
  LIMIT p_limit;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 创建RPC函数：更新用户兴趣标签
CREATE OR REPLACE FUNCTION update_user_interests(
  p_interest_tags text[],
  p_want_to_learn text[],
  p_can_teach text[]
) RETURNS json AS $$
DECLARE
  v_user_id uuid;
  v_result json;
BEGIN
  v_user_id := auth.uid();

  IF v_user_id IS NULL THEN
    RAISE EXCEPTION '未登录';
  END IF;

  -- 更新用户兴趣标签
  UPDATE profiles
  SET 
    interest_tags = p_interest_tags,
    want_to_learn = p_want_to_learn,
    can_teach = p_can_teach,
    updated_at = now()
  WHERE id = v_user_id;

  SELECT json_build_object(
    'success', true,
    'message', '兴趣标签更新成功'
  ) INTO v_result;

  RETURN v_result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
