import { useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { createExchangeRequest } from '@/db/api';
import { CalendarIcon, Clock, MessageSquare, Repeat, FileText } from 'lucide-react';
import { format } from 'date-fns';
import { zhCN } from 'date-fns/locale';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import { TemplateSelectDialog } from './TemplateSelectDialog';
import type { ExchangeTemplate } from '@/types';

interface ExchangeRequestDialogProps {
  skillId: string;
  skillName: string;
  skillPrice: number;
  publisherId: string;
  trigger?: React.ReactNode;
  onSuccess?: () => void;
}

export function ExchangeRequestDialog({
  skillId,
  skillName,
  skillPrice,
  publisherId,
  trigger,
  onSuccess,
}: ExchangeRequestDialogProps) {
  const [open, setOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [mode, setMode] = useState<'direct' | 'integral' | 'group'>('integral');
  const [duration, setDuration] = useState<string>('1');
  const [date, setDate] = useState<Date>();
  const [timeSlot, setTimeSlot] = useState<string>('');
  const [message, setMessage] = useState('');
  const [templateDialogOpen, setTemplateDialogOpen] = useState(false);

  const handleTemplateSelect = (template: ExchangeTemplate) => {
    setMessage(template.content);
    toast.success('已应用模板，可继续编辑');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!date) {
      toast.error('请选择日期');
      return;
    }

    if (!timeSlot) {
      toast.error('请选择时间段');
      return;
    }

    try {
      setSubmitting(true);

      // 组合日期和时间
      const [startHour] = timeSlot.split('-');
      const startTime = new Date(date);
      startTime.setHours(parseInt(startHour), 0, 0, 0);

      const result = await createExchangeRequest({
        toUserId: publisherId,
        skillId,
        mode,
        duration: parseFloat(duration),
        startTime: startTime.toISOString(),
        message: message.trim() || undefined,
      });

      toast.success(result.message);
      setOpen(false);
      onSuccess?.();

      // 重置表单
      setMode('integral');
      setDuration('1');
      setDate(undefined);
      setTimeSlot('');
      setMessage('');
    } catch (error: any) {
      toast.error(error.message || '发起交换失败');
    } finally {
      setSubmitting(false);
    }
  };

  const timeSlots = [
    '08:00-09:00',
    '09:00-10:00',
    '10:00-11:00',
    '11:00-12:00',
    '13:00-14:00',
    '14:00-15:00',
    '15:00-16:00',
    '16:00-17:00',
    '17:00-18:00',
    '18:00-19:00',
    '19:00-20:00',
    '20:00-21:00',
  ];

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger || (
          <Button className="w-full min-h-[44px]">
            <Repeat className="h-4 w-4 mr-2" />
            发起交换
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>发起交换申请</DialogTitle>
          <DialogDescription>向技能发布者发起交换申请</DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* 技能信息 */}
          <div className="p-3 bg-muted rounded-lg">
            <div className="text-sm font-medium mb-1">交换技能</div>
            <div className="text-base font-semibold">{skillName}</div>
            {mode === 'integral' && (
              <div className="text-sm text-muted-foreground mt-1">
                需要积分：{skillPrice} 点
              </div>
            )}
          </div>

          {/* 交换模式 */}
          <div className="space-y-2">
            <Label htmlFor="mode" className="flex items-center gap-2">
              <Repeat className="h-4 w-4" />
              交换模式
            </Label>
            <Select value={mode} onValueChange={(v) => setMode(v as any)}>
              <SelectTrigger id="mode" className="h-11">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="integral">积分交换</SelectItem>
                <SelectItem value="direct">直接交换</SelectItem>
                <SelectItem value="group">团购交换</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground">
              {mode === 'integral' && '使用积分购买技能服务'}
              {mode === 'direct' && '用自己的技能交换对方的技能'}
              {mode === 'group' && '参与团购，享受优惠价格'}
            </p>
          </div>

          {/* 交换时长 */}
          <div className="space-y-2">
            <Label htmlFor="duration" className="flex items-center gap-2">
              <Clock className="h-4 w-4" />
              交换时长
            </Label>
            <Select value={duration} onValueChange={setDuration}>
              <SelectTrigger id="duration" className="h-11">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="0.5">0.5 小时</SelectItem>
                <SelectItem value="1">1 小时</SelectItem>
                <SelectItem value="1.5">1.5 小时</SelectItem>
                <SelectItem value="2">2 小时</SelectItem>
                <SelectItem value="2.5">2.5 小时</SelectItem>
                <SelectItem value="3">3 小时</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* 期望日期 */}
          <div className="space-y-2">
            <Label className="flex items-center gap-2">
              <CalendarIcon className="h-4 w-4" />
              期望日期
            </Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    'w-full h-11 justify-start text-left font-normal',
                    !date && 'text-muted-foreground'
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {date ? format(date, 'PPP', { locale: zhCN }) : '选择日期'}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={date}
                  onSelect={setDate}
                  disabled={(date) => date < new Date()}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          </div>

          {/* 时间段 */}
          <div className="space-y-2">
            <Label htmlFor="timeSlot" className="flex items-center gap-2">
              <Clock className="h-4 w-4" />
              时间段
            </Label>
            <Select value={timeSlot} onValueChange={setTimeSlot}>
              <SelectTrigger id="timeSlot" className="h-11">
                <SelectValue placeholder="选择时间段" />
              </SelectTrigger>
              <SelectContent>
                {timeSlots.map((slot) => (
                  <SelectItem key={slot} value={slot}>
                    {slot}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* 附加留言 */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="message" className="flex items-center gap-2">
                <MessageSquare className="h-4 w-4" />
                附加留言（选填）
              </Label>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="h-8 gap-1 text-xs"
                onClick={() => setTemplateDialogOpen(true)}
              >
                <FileText className="h-3 w-3" />
                使用模板
              </Button>
            </div>
            <Textarea
              id="message"
              placeholder={`例如：我想学PS基础，可以教英语\n\n点击"使用模板"可快速填充交换协议内容`}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="min-h-[120px] resize-none"
            />
          </div>

          {/* 提交按钮 */}
          <div className="flex gap-2 pt-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => setOpen(false)}
              className="flex-1 min-h-[44px]"
            >
              取消
            </Button>
            <Button type="submit" disabled={submitting} className="flex-1 min-h-[44px]">
              {submitting ? '提交中...' : '发起申请'}
            </Button>
          </div>
        </form>
      </DialogContent>

      {/* 模板选择对话框 */}
      <TemplateSelectDialog
        open={templateDialogOpen}
        onOpenChange={setTemplateDialogOpen}
        onSelect={handleTemplateSelect}
      />
    </Dialog>
  );
}
