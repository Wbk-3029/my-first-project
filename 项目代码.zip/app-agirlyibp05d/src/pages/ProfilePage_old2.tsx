import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { MainLayout } from '@/components/layouts/MainLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { AvatarUpload } from '@/components/profile/AvatarUpload';
import { BindPhoneDialog } from '@/components/profile/BindPhoneDialog';
import { useAuth } from '@/contexts/AuthContext';
import { getUserSkills, getUserExchanges, getSignInInfo, dailySignIn } from '@/db/api';
import { updateProfile } from '@/db/api';
import type { Skill, Exchange } from '@/types';
import type { SignInInfo } from '@/db/api';
import { Coins, Award, Package, Repeat, Star, Edit, Settings, Calendar } from 'lucide-react';
import { toast } from 'sonner';
import confetti from 'canvas-confetti';

export default function ProfilePage() {
  const { profile, refreshProfile } = useAuth();
  const [skills, setSkills] = useState<Skill[]>([]);
  const [exchanges, setExchanges] = useState<Exchange[]>([]);
  const [loading, setLoading] = useState(true);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [signInInfo, setSignInInfo] = useState<SignInInfo | null>(null);
  const [signingIn, setSigningIn] = useState(false);
  const [editForm, setEditForm] = useState({
    nickname: '',
  });

  useEffect(() => {
    if (profile) {
      loadData();
      loadSignInInfo();
      setEditForm({ nickname: profile.nickname || '' });
    }
  }, [profile]);

  const loadData = async () => {
    if (!profile) return;

    try {
      setLoading(true);
      const [skillsData, exchangesData] = await Promise.all([
        getUserSkills(profile.id),
        getUserExchanges(profile.id),
      ]);
      setSkills(skillsData);
      setExchanges(exchangesData.filter((e) => e.status === 'completed'));
    } catch (error) {
      toast.error('加载数据失败');
    } finally {
      setLoading(false);
    }
  };

  const loadSignInInfo = async () => {
    try {
      const info = await getSignInInfo();
      setSignInInfo(info);
    } catch (error) {
      console.error('加载签到信息失败:', error);
    }
  };

  const handleSignIn = async () => {
    try {
      setSigningIn(true);
      const result = await dailySignIn();
      
      if (result.success) {
        // 签到成功，播放庆祝动画
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 }
        });
        
        toast.success(result.message);
        
        // 刷新签到信息和用户资料
        await Promise.all([
          loadSignInInfo(),
          refreshProfile()
        ]);
      } else {
        toast.info(result.message);
      }
    } catch (error: any) {
      console.error('签到失败:', error);
      toast.error(error.message || '签到失败');
    } finally {
      setSigningIn(false);
    }
  };

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile) return;

    try {
      await updateProfile(profile.id, { nickname: editForm.nickname });
      await refreshProfile();
      toast.success('更新成功');
      setEditDialogOpen(false);
    } catch (error) {
      toast.error('更新失败');
    }
  };

  if (!profile) {
    return (
      <MainLayout>
        <Card>
          <CardContent className="py-12 text-center text-muted-foreground">
            请先登录
          </CardContent>
        </Card>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Profile Header */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row items-start md:items-center gap-6">
              <AvatarUpload
                currentAvatar={profile.avatar_url || undefined}
                userId={profile.id}
                onUploadSuccess={refreshProfile}
              />

              <div className="flex-1 space-y-3">
                <div className="flex items-center gap-3">
                  <h1 className="text-2xl font-bold">{profile.nickname || '未设置昵称'}</h1>
                  <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm" className="gap-2">
                        <Edit className="h-3.5 w-3.5" />
                        编辑
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>编辑个人信息</DialogTitle>
                        <DialogDescription>更新你的个人资料</DialogDescription>
                      </DialogHeader>
                      <form onSubmit={handleUpdateProfile} className="space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor="nickname">昵称</Label>
                          <Input
                            id="nickname"
                            value={editForm.nickname}
                            onChange={(e) => setEditForm({ ...editForm, nickname: e.target.value })}
                            required
                          />
                        </div>
                        <div className="flex justify-end gap-2">
                          <Button type="button" variant="outline" onClick={() => setEditDialogOpen(false)}>
                            取消
                          </Button>
                          <Button type="submit">保存</Button>
                        </div>
                      </form>
                    </DialogContent>
                  </Dialog>
                </div>

                <div className="flex items-center gap-2">
                  <div className="text-sm text-muted-foreground">
                    {profile.phone || '未绑定手机号'}
                  </div>
                  {!profile.phone && (
                    <BindPhoneDialog onBindSuccess={refreshProfile} />
                  )}
                </div>

                <div className="flex flex-wrap gap-4">
                  <Link
                    to="/profile/integral"
                    className="flex items-center space-x-2 px-3 py-1.5 rounded-lg bg-secondary/10 border border-secondary/20 hover:bg-secondary/20 transition-colors cursor-pointer"
                  >
                    <Coins className="h-4 w-4 text-secondary" />
                    <span className="text-sm font-medium">{profile.points} 技易点</span>
                  </Link>
                  <Link
                    to="/profile/credit"
                    className="flex items-center space-x-2 px-3 py-1.5 rounded-lg bg-primary/10 border border-primary/20 hover:bg-primary/20 transition-colors cursor-pointer"
                  >
                    <Award className="h-4 w-4 text-primary" />
                    <span className="text-sm font-medium">信用分 {profile.credit_score}</span>
                  </Link>
                </div>

                {/* 签到区域 */}
                <div className="flex items-center gap-4 pt-2">
                  <Button
                    onClick={handleSignIn}
                    disabled={signInInfo?.already_signed || signingIn}
                    className="gap-2"
                    variant={signInInfo?.already_signed ? 'outline' : 'default'}
                  >
                    <Calendar className="h-4 w-4" />
                    {signingIn ? '签到中...' : signInInfo?.already_signed ? '今日已签到' : '每日签到'}
                  </Button>
                  
                  {signInInfo && (
                    <div className="flex items-center gap-4 text-sm">
                      <div className="flex items-center gap-1">
                        <span className="text-muted-foreground">连续签到</span>
                        <Badge variant="secondary" className="font-bold">
                          {signInInfo.continuous_days} 天
                        </Badge>
                      </div>
                      <div className="flex items-center gap-1">
                        <span className="text-muted-foreground">累计签到</span>
                        <Badge variant="outline">
                          {signInInfo.total_days} 天
                        </Badge>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                已发布技能
              </CardTitle>
              <Package className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{skills.length}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                已完成交换
              </CardTitle>
              <Repeat className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{exchanges.length}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                收藏数
              </CardTitle>
              <Star className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">-</div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Links */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="hover:shadow-lg transition-shadow cursor-pointer">
            <Link to="/profile/skills">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Package className="h-5 w-5" />
                  我的技能
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  管理你发布的所有技能
                </p>
              </CardContent>
            </Link>
          </Card>

          <Card className="hover:shadow-lg transition-shadow cursor-pointer">
            <Link to="/profile/exchanges">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Repeat className="h-5 w-5" />
                  交换记录
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  查看所有交换历史记录
                </p>
              </CardContent>
            </Link>
          </Card>

          <Card className="hover:shadow-lg transition-shadow cursor-pointer">
            <Link to="/profile/favorites">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Star className="h-5 w-5" />
                  我的收藏
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  查看收藏的技能和帖子
                </p>
              </CardContent>
            </Link>
          </Card>

          <Card className="hover:shadow-lg transition-shadow cursor-pointer">
            <Link to="/profile/settings">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="h-5 w-5" />
                  设置
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  管理账户和安全设置
                </p>
              </CardContent>
            </Link>
          </Card>
        </div>
      </div>
    </MainLayout>
  );
}
