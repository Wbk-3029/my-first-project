import { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { MainLayout } from '@/components/layouts/MainLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Separator } from '@/components/ui/separator';
import { RescheduleDialog } from '@/components/exchange/RescheduleDialog';
import { BreachReportDialog } from '@/components/exchange/BreachReportDialog';
import {
  getExchangeDetail,
  completeExchange,
  checkExchangeRated,
  getRescheduleRequests,
  handleRescheduleRequest,
  type ExchangeWithDetails,
  type RescheduleRequest,
} from '@/db/api';
import {
  ArrowLeft,
  Package,
  Clock,
  Calendar,
  MessageSquare,
  CheckCircle2,
  Star,
  User,
  AlertTriangle,
} from 'lucide-react';
import { format } from 'date-fns';
import { zhCN } from 'date-fns/locale';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';

export default function ExchangeDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { profile } = useAuth();
  const [exchange, setExchange] = useState<ExchangeWithDetails | null>(null);
  const [rescheduleRequests, setRescheduleRequests] = useState<RescheduleRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [completing, setCompleting] = useState(false);
  const [hasRated, setHasRated] = useState(false);

  useEffect(() => {
    if (id) {
      loadData();
    }
  }, [id]);

  const loadData = async () => {
    if (!id) return;

    try {
      setLoading(true);
      const [exchangeData, rescheduleData] = await Promise.all([
        getExchangeDetail(id),
        getRescheduleRequests(id),
      ]);
      setExchange(exchangeData);
      setRescheduleRequests(rescheduleData);

      // 检查是否已评价
      if (exchangeData?.status === 'completed') {
        const rated = await checkExchangeRated(id);
        setHasRated(rated);
      }
    } catch (error) {
      toast.error('加载失败');
    } finally {
      setLoading(false);
    }
  };

  const handleComplete = async () => {
    if (!id) return;

    try {
      setCompleting(true);
      const result = await completeExchange(id);
      toast.success(result.message);
      await loadData();
    } catch (error: any) {
      toast.error(error.message || '操作失败');
    } finally {
      setCompleting(false);
    }
  };

  const handleReschedule = async (requestId: string, action: 'approve' | 'reject') => {
    try {
      const result = await handleRescheduleRequest(requestId, action);
      toast.success(result.message);
      await loadData();
    } catch (error: any) {
      toast.error(error.message || '操作失败');
    }
  };

  const canReportBreach = () => {
    if (!exchange?.start_time) return false;
    const startTime = new Date(exchange.start_time);
    const now = new Date();
    const minutesSinceStart = (now.getTime() - startTime.getTime()) / (1000 * 60);
    return minutesSinceStart >= 15;
  };

  const getStatusBadge = (status: string) => {
    const statusMap = {
      pending: { label: '待确认', color: 'bg-yellow-100 text-yellow-700 dark:bg-yellow-950 dark:text-yellow-300' },
      accepted: { label: '已同意', color: 'bg-green-100 text-green-700 dark:bg-green-950 dark:text-green-300' },
      in_progress: { label: '进行中', color: 'bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300' },
      completed: { label: '已完成', color: 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300' },
      rejected: { label: '已拒绝', color: 'bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-300' },
      cancelled: { label: '已取消', color: 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300' },
    };
    const config = statusMap[status as keyof typeof statusMap] || statusMap.pending;
    return (
      <span className={`text-xs px-2 py-0.5 rounded-full ${config.color}`}>
        {config.label}
      </span>
    );
  };

  const getTypeLabel = (type: string) => {
    const typeMap = {
      direct: '直接交换',
      point: '积分交换',
      group: '团购交换',
    };
    return typeMap[type as keyof typeof typeMap] || type;
  };

  if (loading) {
    return (
      <MainLayout>
        <div className="space-y-4">
          <Skeleton className="h-10 w-full bg-muted" />
          <Skeleton className="h-64 w-full rounded-xl bg-muted" />
          <Skeleton className="h-40 w-full rounded-xl bg-muted" />
        </div>
      </MainLayout>
    );
  }

  if (!exchange) {
    return (
      <MainLayout>
        <Card className="rounded-xl">
          <div className="p-12 text-center text-muted-foreground">
            交换不存在
          </div>
        </Card>
      </MainLayout>
    );
  }

  const isInitiator = profile?.id === exchange.initiator_id;
  const otherUser = isInitiator ? exchange.receiver : exchange.initiator;
  const mySkill = isInitiator ? exchange.initiator_skill : exchange.receiver_skill;
  const otherSkill = isInitiator ? exchange.receiver_skill : exchange.initiator_skill;

  return (
    <MainLayout>
      <div className="space-y-4">
        {/* 返回按钮 */}
        <Button asChild variant="ghost" size="sm" className="gap-2">
          <Link to="/my-exchanges">
            <ArrowLeft className="h-4 w-4" />
            返回
          </Link>
        </Button>

        {/* 交换详情卡片 */}
        <Card className="rounded-xl">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>交换详情</CardTitle>
              {getStatusBadge(exchange.status)}
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* 对方信息 */}
            <div className="flex items-center gap-3">
              <Avatar className="h-12 w-12">
                <AvatarImage src={otherUser?.avatar_url || undefined} />
                <AvatarFallback>{otherUser?.nickname?.[0] || '用'}</AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <div className="font-medium">{otherUser?.nickname || '匿名用户'}</div>
                <div className="text-sm text-muted-foreground flex items-center gap-2">
                  <Star className="h-3.5 w-3.5 fill-yellow-400 text-yellow-400" />
                  信用分：{otherUser?.credit_score || 0}
                </div>
              </div>
              <Button asChild variant="outline" size="sm">
                <Link to={`/profile/${otherUser?.id}`}>
                  <User className="h-4 w-4 mr-2" />
                  查看主页
                </Link>
              </Button>
            </div>

            <Separator />

            {/* 交换信息 */}
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-sm">
                <Package className="h-4 w-4 text-muted-foreground" />
                <span className="text-muted-foreground">交换类型：</span>
                <span className="font-medium">{getTypeLabel(exchange.type)}</span>
              </div>

              {exchange.points_amount && (
                <div className="flex items-center gap-2 text-sm">
                  <span className="text-muted-foreground">积分金额：</span>
                  <span className="font-medium">{exchange.points_amount} 点</span>
                </div>
              )}

              {exchange.start_time && (
                <div className="flex items-center gap-2 text-sm">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <span className="text-muted-foreground">约定时间：</span>
                  <span className="font-medium">
                    {format(new Date(exchange.start_time), 'yyyy-MM-dd HH:mm', { locale: zhCN })}
                  </span>
                </div>
              )}
            </div>

            <Separator />

            {/* 技能信息 */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* 我的技能 */}
              {mySkill && (
                <div className="p-3 bg-muted/50 rounded-lg">
                  <div className="text-xs text-muted-foreground mb-1">我的技能</div>
                  <div className="font-medium">{mySkill.name}</div>
                  {mySkill.description && (
                    <div className="text-sm text-muted-foreground mt-1 line-clamp-2">
                      {mySkill.description}
                    </div>
                  )}
                </div>
              )}

              {/* 对方技能 */}
              {otherSkill && (
                <div className="p-3 bg-muted/50 rounded-lg">
                  <div className="text-xs text-muted-foreground mb-1">对方技能</div>
                  <div className="font-medium">{otherSkill.name}</div>
                  {otherSkill.description && (
                    <div className="text-sm text-muted-foreground mt-1 line-clamp-2">
                      {otherSkill.description}
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* 备注 */}
            {exchange.note && (
              <>
                <Separator />
                <div className="p-3 bg-muted/30 rounded-lg">
                  <div className="flex items-start gap-2">
                    <MessageSquare className="h-4 w-4 mt-0.5 text-muted-foreground shrink-0" />
                    <div>
                      <div className="text-xs text-muted-foreground mb-1">备注</div>
                      <div className="text-sm">{exchange.note}</div>
                    </div>
                  </div>
                </div>
              </>
            )}
          </CardContent>
        </Card>

        {/* 状态时间线 */}
        <Card className="rounded-xl">
          <CardHeader>
            <CardTitle>状态时间线</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* 创建时间 */}
              <div className="flex gap-3">
                <div className="flex flex-col items-center">
                  <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                    <CheckCircle2 className="h-4 w-4 text-primary" />
                  </div>
                  {exchange.status !== 'pending' && (
                    <div className="w-0.5 h-full bg-border mt-2" />
                  )}
                </div>
                <div className="flex-1 pb-4">
                  <div className="font-medium">发起申请</div>
                  <div className="text-sm text-muted-foreground">
                    {format(new Date(exchange.created_at), 'yyyy-MM-dd HH:mm', { locale: zhCN })}
                  </div>
                </div>
              </div>

              {/* 同意时间 */}
              {(exchange.status === 'accepted' || exchange.status === 'in_progress' || exchange.status === 'completed') && (
                <div className="flex gap-3">
                  <div className="flex flex-col items-center">
                    <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                      <CheckCircle2 className="h-4 w-4 text-primary" />
                    </div>
                    {(exchange.status === 'in_progress' || exchange.status === 'completed') && (
                      <div className="w-0.5 h-full bg-border mt-2" />
                    )}
                  </div>
                  <div className="flex-1 pb-4">
                    <div className="font-medium">对方同意</div>
                    <div className="text-sm text-muted-foreground">
                      {format(new Date(exchange.updated_at), 'yyyy-MM-dd HH:mm', { locale: zhCN })}
                    </div>
                  </div>
                </div>
              )}

              {/* 进行中 */}
              {(exchange.status === 'in_progress' || exchange.status === 'completed') && (
                <div className="flex gap-3">
                  <div className="flex flex-col items-center">
                    <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                      <Clock className="h-4 w-4 text-primary" />
                    </div>
                    {exchange.status === 'completed' && (
                      <div className="w-0.5 h-full bg-border mt-2" />
                    )}
                  </div>
                  <div className="flex-1 pb-4">
                    <div className="font-medium">进行中</div>
                    {exchange.start_time && (
                      <div className="text-sm text-muted-foreground">
                        {format(new Date(exchange.start_time), 'yyyy-MM-dd HH:mm', { locale: zhCN })}
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* 已完成 */}
              {exchange.status === 'completed' && exchange.completed_at && (
                <div className="flex gap-3">
                  <div className="flex flex-col items-center">
                    <div className="h-8 w-8 rounded-full bg-green-100 dark:bg-green-950 flex items-center justify-center">
                      <CheckCircle2 className="h-4 w-4 text-green-600 dark:text-green-400" />
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="font-medium">已完成</div>
                    <div className="text-sm text-muted-foreground">
                      {format(new Date(exchange.completed_at), 'yyyy-MM-dd HH:mm', { locale: zhCN })}
                    </div>
                  </div>
                </div>
              )}

              {/* 待完成 */}
              {exchange.status === 'in_progress' && (
                <div className="flex gap-3">
                  <div className="flex flex-col items-center">
                    <div className="h-8 w-8 rounded-full bg-muted flex items-center justify-center">
                      <Clock className="h-4 w-4 text-muted-foreground" />
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="font-medium text-muted-foreground">待完成</div>
                    <div className="text-sm text-muted-foreground">
                      等待双方确认完成
                    </div>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* 改期申请列表 */}
        {rescheduleRequests.length > 0 && (
          <Card className="rounded-xl">
            <CardHeader>
              <CardTitle>改期申请</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {rescheduleRequests.map((request) => {
                const isRequester = profile?.id === request.requester_id;
                return (
                  <div
                    key={request.id}
                    className="p-3 bg-muted/50 rounded-lg space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">
                        {isRequester ? '你发起的改期申请' : '对方发起的改期申请'}
                      </span>
                      <Badge
                        variant={
                          request.status === 'approved'
                            ? 'default'
                            : request.status === 'rejected'
                            ? 'destructive'
                            : 'secondary'
                        }
                      >
                        {request.status === 'pending' && '待处理'}
                        {request.status === 'approved' && '已同意'}
                        {request.status === 'rejected' && '已拒绝'}
                      </Badge>
                    </div>
                    <div className="text-sm text-muted-foreground space-y-1">
                      <div>
                        原时间：
                        {format(new Date(request.old_start_time), 'yyyy-MM-dd HH:mm', {
                          locale: zhCN,
                        })}
                      </div>
                      <div>
                        新时间：
                        {format(new Date(request.new_start_time), 'yyyy-MM-dd HH:mm', {
                          locale: zhCN,
                        })}
                      </div>
                      <div>原因：{request.reason}</div>
                    </div>
                    {!isRequester && request.status === 'pending' && (
                      <div className="flex gap-2 mt-2">
                        <Button
                          size="sm"
                          onClick={() => handleReschedule(request.id, 'approve')}
                          className="flex-1"
                        >
                          同意
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleReschedule(request.id, 'reject')}
                          className="flex-1"
                        >
                          拒绝
                        </Button>
                      </div>
                    )}
                  </div>
                );
              })}
            </CardContent>
          </Card>
        )}

        {/* 操作按钮 */}
        {exchange.status === 'in_progress' && (
          <div className="space-y-3">
            <div className="flex gap-3">
              <Button
                onClick={handleComplete}
                disabled={completing}
                className="flex-1 min-h-[44px] gap-2"
              >
                <CheckCircle2 className="h-4 w-4" />
                {completing ? '处理中...' : '确认完成'}
              </Button>
            </div>
            <div className="flex gap-3">
              {exchange.start_time && (
                <RescheduleDialog
                  exchangeId={exchange.id}
                  currentStartTime={exchange.start_time}
                  onSuccess={loadData}
                  trigger={
                    <Button asChild variant="outline" className="flex-1 min-h-[44px] gap-2">
                      <div>
                        <Clock className="h-4 w-4" />
                        申请改期
                      </div>
                    </Button>
                  }
                />
              )}
              {canReportBreach() && (
                <BreachReportDialog
                  exchangeId={exchange.id}
                  reportedId={isInitiator ? exchange.receiver_id : exchange.initiator_id}
                  reportedName={otherUser?.nickname || '对方'}
                  onSuccess={loadData}
                  trigger={
                    <Button asChild variant="destructive" className="flex-1 min-h-[44px] gap-2">
                      <div>
                        <AlertTriangle className="h-4 w-4" />
                        举报未履约
                      </div>
                    </Button>
                  }
                />
              )}
            </div>
          </div>
        )}

        {/* 评价按钮 */}
        {exchange.status === 'completed' && !hasRated && (
          <Button
            asChild
            className="w-full min-h-[44px] gap-2"
          >
            <Link to={`/rate/${exchange.id}`}>
              <Star className="h-4 w-4" />
              评价对方
            </Link>
          </Button>
        )}

        {exchange.status === 'completed' && hasRated && (
          <Card className="rounded-xl bg-muted/50">
            <div className="p-4 text-center text-sm text-muted-foreground">
              你已评价过此次交换
            </div>
          </Card>
        )}
      </div>
    </MainLayout>
  );
}
