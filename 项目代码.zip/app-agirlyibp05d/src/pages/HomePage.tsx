import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { MainLayout } from '@/components/layouts/MainLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { SkillCard } from '@/components/skill/SkillCard';
import { PostCard } from '@/components/forum/PostCard';
import { Skeleton } from '@/components/ui/skeleton';
import { getSkills, getPosts } from '@/db/api';
import type { Skill, Post } from '@/types';
import { MessageSquare, Store, Repeat, TrendingUp, Sparkles } from 'lucide-react';
import { toast } from 'sonner';

export default function HomePage() {
  const navigate = useNavigate();
  const [hotSkills, setHotSkills] = useState<Skill[]>([]);
  const [latestPosts, setLatestPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const [skills, posts] = await Promise.all([
        getSkills({ sortBy: 'hot', limit: 3 }),
        getPosts({ sortBy: 'time', limit: 3 }),
      ]);
      setHotSkills(skills);
      setLatestPosts(posts);
    } catch (error) {
      toast.error('加载数据失败');
    } finally {
      setLoading(false);
    }
  };

  return (
    <MainLayout>
      {/* Hero Section */}
      <section className="mb-12 text-center space-y-4">
        <h1 className="text-4xl md:text-5xl font-bold gradient-text">
          欢迎来到技遇
        </h1>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          大学生技能交换平台,让你的技能遇见更多可能
        </p>
        <div className="flex flex-wrap justify-center gap-4 pt-4">
          <Button asChild size="lg" className="gap-2">
            <Link to="/skills">
              <Store className="h-5 w-5" />
              浏览技能广场
            </Link>
          </Button>
          <Button asChild size="lg" variant="outline" className="gap-2">
            <Link to="/forum">
              <MessageSquare className="h-5 w-5" />
              进入社区论坛
            </Link>
          </Button>
        </div>
      </section>

      {/* Feature Cards */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
        <Card
          className="border-primary/20 hover:border-primary/50 transition-all cursor-pointer hover:shadow-lg"
          onClick={() => navigate('/skills?method=direct')}
        >
          <CardHeader>
            <div className="flex items-center space-x-2">
              <div className="p-2 rounded-lg bg-primary/10">
                <Repeat className="h-5 w-5 text-primary" />
              </div>
              <CardTitle>直接交换</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <CardDescription>
              用你的技能直接交换他人技能,实现技能互补
            </CardDescription>
          </CardContent>
        </Card>

        <Card
          className="border-secondary/20 hover:border-secondary/50 transition-all cursor-pointer hover:shadow-lg"
          onClick={() => navigate('/skills?method=point')}
        >
          <CardHeader>
            <div className="flex items-center space-x-2">
              <div className="p-2 rounded-lg bg-secondary/10">
                <Sparkles className="h-5 w-5 text-secondary" />
              </div>
              <CardTitle>技易点交换</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <CardDescription>
              使用技易点购买技能,完成交换获得奖励
            </CardDescription>
          </CardContent>
        </Card>

        <Card
          className="border-primary/20 hover:border-primary/50 transition-all cursor-pointer hover:shadow-lg"
          onClick={() => navigate('/skills?method=group')}
        >
          <CardHeader>
            <div className="flex items-center space-x-2">
              <div className="p-2 rounded-lg bg-primary/10">
                <TrendingUp className="h-5 w-5 text-primary" />
              </div>
              <CardTitle>团购优惠</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <CardDescription>
              发起或参与团购,以更优惠的价格获取技能
            </CardDescription>
          </CardContent>
        </Card>
      </section>

      {/* Hot Skills */}
      <section className="mb-12">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">🔥 热门技能</h2>
          <Button asChild variant="ghost">
            <Link to="/skills">查看更多</Link>
          </Button>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array.from({ length: 3 }).map((_, i) => (
              <Card key={i}>
                <CardHeader>
                  <Skeleton className="h-6 w-3/4 bg-muted" />
                  <Skeleton className="h-4 w-full bg-muted" />
                </CardHeader>
                <CardContent>
                  <Skeleton className="h-4 w-1/2 bg-muted" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : hotSkills.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {hotSkills.map((skill) => (
              <SkillCard key={skill.id} skill={skill} />
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="py-12 text-center text-muted-foreground">
              暂无热门技能
            </CardContent>
          </Card>
        )}
      </section>

      {/* Latest Posts */}
      <section>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">💬 最新帖子</h2>
          <Button asChild variant="ghost">
            <Link to="/forum">查看更多</Link>
          </Button>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {Array.from({ length: 3 }).map((_, i) => (
              <Card key={i}>
                <CardHeader>
                  <Skeleton className="h-6 w-3/4 bg-muted" />
                  <Skeleton className="h-4 w-full bg-muted" />
                </CardHeader>
                <CardContent>
                  <Skeleton className="h-4 w-1/2 bg-muted" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : latestPosts.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {latestPosts.map((post) => (
              <PostCard key={post.id} post={post} />
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="py-12 text-center text-muted-foreground">
              暂无帖子
            </CardContent>
          </Card>
        )}
      </section>
    </MainLayout>
  );
}
