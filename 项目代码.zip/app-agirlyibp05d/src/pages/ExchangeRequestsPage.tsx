import { useEffect, useState } from 'react';
import { MainLayout } from '@/components/layouts/MainLayout';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  getMyExchangeRequests,
  getReceivedExchangeRequests,
  handleExchangeRequest,
  cancelExchangeRequest,
  type ExchangeRequest,
} from '@/db/api';
import { Clock, Calendar, MessageSquare, Check, X, Ban } from 'lucide-react';
import { format } from 'date-fns';
import { zhCN } from 'date-fns/locale';
import { toast } from 'sonner';

export default function ExchangeRequestsPage() {
  const [myRequests, setMyRequests] = useState<ExchangeRequest[]>([]);
  const [receivedRequests, setReceivedRequests] = useState<ExchangeRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('received');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const [myData, receivedData] = await Promise.all([
        getMyExchangeRequests(),
        getReceivedExchangeRequests(),
      ]);
      setMyRequests(myData);
      setReceivedRequests(receivedData);
    } catch (error) {
      toast.error('加载失败');
    } finally {
      setLoading(false);
    }
  };

  const handleAccept = async (requestId: string) => {
    try {
      const result = await handleExchangeRequest(requestId, 'accept');
      toast.success(result.message);
      await loadData();
    } catch (error: any) {
      toast.error(error.message || '操作失败');
    }
  };

  const handleReject = async (requestId: string) => {
    try {
      const result = await handleExchangeRequest(requestId, 'reject');
      toast.success(result.message);
      await loadData();
    } catch (error: any) {
      toast.error(error.message || '操作失败');
    }
  };

  const handleCancel = async (requestId: string) => {
    try {
      const result = await cancelExchangeRequest(requestId);
      toast.success(result.message);
      await loadData();
    } catch (error: any) {
      toast.error(error.message || '操作失败');
    }
  };

  const getStatusBadge = (status: string) => {
    const statusMap = {
      pending: { label: '待确认', variant: 'default' as const },
      accepted: { label: '已同意', variant: 'default' as const },
      rejected: { label: '已拒绝', variant: 'destructive' as const },
      cancelled: { label: '已取消', variant: 'secondary' as const },
    };
    const config = statusMap[status as keyof typeof statusMap] || statusMap.pending;
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  const getModeBadge = (mode: string) => {
    const modeMap = {
      direct: { label: '直接交换', color: 'bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300' },
      integral: { label: '积分交换', color: 'bg-green-100 text-green-700 dark:bg-green-950 dark:text-green-300' },
      group: { label: '团购交换', color: 'bg-purple-100 text-purple-700 dark:bg-purple-950 dark:text-purple-300' },
    };
    const config = modeMap[mode as keyof typeof modeMap] || modeMap.integral;
    return (
      <span className={`text-xs px-2 py-0.5 rounded-full ${config.color}`}>
        {config.label}
      </span>
    );
  };

  const RequestCard = ({ request, type }: { request: ExchangeRequest; type: 'sent' | 'received' }) => {
    const otherUser = type === 'sent' ? request.to_user : request.from_user;
    const isPending = request.status === 'pending';

    return (
      <Card className="rounded-xl overflow-hidden">
        <div className="p-4 space-y-3">
          {/* 用户信息 */}
          <div className="flex items-center gap-3">
            <Avatar className="h-10 w-10">
              <AvatarImage src={otherUser?.avatar_url || undefined} />
              <AvatarFallback>{otherUser?.nickname?.[0] || '用'}</AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <div className="font-medium truncate">{otherUser?.nickname || '匿名用户'}</div>
              <div className="text-xs text-muted-foreground">
                {type === 'sent' ? '向你发起申请' : '你向TA发起申请'}
              </div>
            </div>
            {getStatusBadge(request.status)}
          </div>

          {/* 技能信息 */}
          <div className="p-3 bg-muted/50 rounded-lg space-y-2">
            <div className="flex items-center justify-between">
              <div className="font-medium">{request.skill?.name}</div>
              {getModeBadge(request.mode)}
            </div>
            {request.points_amount && (
              <div className="text-sm text-muted-foreground">
                积分：{request.points_amount} 点
              </div>
            )}
          </div>

          {/* 时间信息 */}
          <div className="space-y-1.5 text-sm">
            <div className="flex items-center gap-2 text-muted-foreground">
              <Clock className="h-3.5 w-3.5" />
              <span>时长：{request.duration} 小时</span>
            </div>
            <div className="flex items-center gap-2 text-muted-foreground">
              <Calendar className="h-3.5 w-3.5" />
              <span>
                {format(new Date(request.start_time), 'yyyy-MM-dd HH:mm', { locale: zhCN })}
                {' - '}
                {format(new Date(request.end_time), 'HH:mm', { locale: zhCN })}
              </span>
            </div>
          </div>

          {/* 留言 */}
          {request.message && (
            <div className="p-3 bg-muted/30 rounded-lg">
              <div className="flex items-start gap-2">
                <MessageSquare className="h-3.5 w-3.5 mt-0.5 text-muted-foreground shrink-0" />
                <div className="text-sm text-muted-foreground">{request.message}</div>
              </div>
            </div>
          )}

          {/* 操作按钮 */}
          {isPending && (
            <div className="flex gap-2 pt-2">
              {type === 'received' ? (
                <>
                  <Button
                    onClick={() => handleAccept(request.id)}
                    className="flex-1 min-h-[44px] gap-2"
                  >
                    <Check className="h-4 w-4" />
                    同意
                  </Button>
                  <Button
                    onClick={() => handleReject(request.id)}
                    variant="outline"
                    className="flex-1 min-h-[44px] gap-2"
                  >
                    <X className="h-4 w-4" />
                    拒绝
                  </Button>
                </>
              ) : (
                <Button
                  onClick={() => handleCancel(request.id)}
                  variant="outline"
                  className="w-full min-h-[44px] gap-2"
                >
                  <Ban className="h-4 w-4" />
                  取消申请
                </Button>
              )}
            </div>
          )}
        </div>
      </Card>
    );
  };

  if (loading) {
    return (
      <MainLayout>
        <div className="space-y-4">
          <Skeleton className="h-8 w-48 bg-muted" />
          <Skeleton className="h-40 w-full rounded-xl bg-muted" />
          <Skeleton className="h-40 w-full rounded-xl bg-muted" />
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="space-y-4">
        <h1 className="text-title-lg">交换申请</h1>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="received">
              收到的申请
              {receivedRequests.filter((r) => r.status === 'pending').length > 0 && (
                <Badge variant="destructive" className="ml-2">
                  {receivedRequests.filter((r) => r.status === 'pending').length}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="sent">我发起的</TabsTrigger>
          </TabsList>

          <TabsContent value="received" className="space-y-3 mt-4">
            {receivedRequests.length > 0 ? (
              receivedRequests.map((request) => (
                <RequestCard key={request.id} request={request} type="received" />
              ))
            ) : (
              <Card className="rounded-xl">
                <div className="p-12 text-center text-muted-foreground">
                  暂无收到的申请
                </div>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="sent" className="space-y-3 mt-4">
            {myRequests.length > 0 ? (
              myRequests.map((request) => (
                <RequestCard key={request.id} request={request} type="sent" />
              ))
            ) : (
              <Card className="rounded-xl">
                <div className="p-12 text-center text-muted-foreground">
                  暂无发起的申请
                </div>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  );
}
