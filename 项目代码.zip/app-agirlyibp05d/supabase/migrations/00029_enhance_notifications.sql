-- 扩展notifications表的类型
ALTER TABLE notifications DROP CONSTRAINT IF EXISTS notifications_type_check;
ALTER TABLE notifications ADD CONSTRAINT notifications_type_check 
  CHECK (type IN (
    'exchange_request',      -- 交换申请
    'exchange_accepted',     -- 申请同意
    'exchange_rejected',     -- 申请拒绝
    'exchange_reminder',     -- 交换提醒
    'rating_reminder',       -- 评价提醒
    'credit_change',         -- 信用分变化
    'points_change',         -- 技易点变动
    'system',                -- 系统通知
    'friend_request'         -- 好友申请
  ));

-- 添加action_url字段，用于跳转
ALTER TABLE notifications ADD COLUMN IF NOT EXISTS action_url TEXT;

-- 添加注释
COMMENT ON COLUMN notifications.action_url IS '操作跳转URL';

-- 创建RPC函数：获取未读消息数量
CREATE OR REPLACE FUNCTION get_unread_notification_count()
RETURNS INTEGER AS $$
DECLARE
  v_user_id uuid;
  v_count integer;
BEGIN
  v_user_id := auth.uid();

  IF v_user_id IS NULL THEN
    RETURN 0;
  END IF;

  SELECT COUNT(*)::integer INTO v_count
  FROM notifications
  WHERE user_id = v_user_id AND is_read = false;

  RETURN v_count;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 创建RPC函数：标记所有通知为已读
CREATE OR REPLACE FUNCTION mark_all_notifications_as_read()
RETURNS json AS $$
DECLARE
  v_user_id uuid;
  v_count integer;
BEGIN
  v_user_id := auth.uid();

  IF v_user_id IS NULL THEN
    RAISE EXCEPTION '未登录';
  END IF;

  UPDATE notifications
  SET is_read = true
  WHERE user_id = v_user_id AND is_read = false;

  GET DIAGNOSTICS v_count = ROW_COUNT;

  RETURN json_build_object(
    'success', true,
    'count', v_count,
    'message', format('已标记%s条通知为已读', v_count)
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 创建RPC函数：创建通知
CREATE OR REPLACE FUNCTION create_notification(
  p_user_id uuid,
  p_type text,
  p_title text,
  p_content text DEFAULT NULL,
  p_related_id uuid DEFAULT NULL,
  p_action_url text DEFAULT NULL
) RETURNS json AS $$
DECLARE
  v_notification_id uuid;
BEGIN
  INSERT INTO notifications (user_id, type, title, content, related_id, action_url)
  VALUES (p_user_id, p_type, p_title, p_content, p_related_id, p_action_url)
  RETURNING id INTO v_notification_id;

  RETURN json_build_object(
    'success', true,
    'notification_id', v_notification_id
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 创建触发器：交换申请时发送通知
CREATE OR REPLACE FUNCTION notify_exchange_request()
RETURNS TRIGGER AS $$
DECLARE
  v_initiator_name text;
  v_skill_name text;
BEGIN
  -- 获取发起人昵称
  SELECT nickname INTO v_initiator_name
  FROM profiles
  WHERE id = NEW.initiator_id;

  -- 获取技能名称
  SELECT name INTO v_skill_name
  FROM skills
  WHERE id = NEW.skill_id;

  -- 发送通知给接收方
  INSERT INTO notifications (user_id, type, title, content, related_id, action_url)
  VALUES (
    NEW.receiver_id,
    'exchange_request',
    '收到新的交换申请',
    format('%s 想要与你交换技能：%s', v_initiator_name, v_skill_name),
    NEW.id,
    format('/exchanges/%s', NEW.id)
  );

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 创建触发器：交换状态变化时发送通知
CREATE OR REPLACE FUNCTION notify_exchange_status_change()
RETURNS TRIGGER AS $$
DECLARE
  v_receiver_name text;
  v_skill_name text;
BEGIN
  -- 只在状态变化时触发
  IF OLD.status = NEW.status THEN
    RETURN NEW;
  END IF;

  -- 获取接收方昵称
  SELECT nickname INTO v_receiver_name
  FROM profiles
  WHERE id = NEW.receiver_id;

  -- 获取技能名称
  SELECT name INTO v_skill_name
  FROM skills
  WHERE id = NEW.skill_id;

  -- 根据状态发送不同通知
  IF NEW.status = 'accepted' THEN
    -- 发送通知给发起方
    INSERT INTO notifications (user_id, type, title, content, related_id, action_url)
    VALUES (
      NEW.initiator_id,
      'exchange_accepted',
      '交换申请已同意',
      format('%s 同意了你的交换申请：%s', v_receiver_name, v_skill_name),
      NEW.id,
      format('/exchanges/%s', NEW.id)
    );
  ELSIF NEW.status = 'rejected' THEN
    -- 发送通知给发起方
    INSERT INTO notifications (user_id, type, title, content, related_id, action_url)
    VALUES (
      NEW.initiator_id,
      'exchange_rejected',
      '交换申请已拒绝',
      format('%s 拒绝了你的交换申请：%s', v_receiver_name, v_skill_name),
      NEW.id,
      format('/exchanges/%s', NEW.id)
    );
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 删除旧触发器（如果存在）
DROP TRIGGER IF EXISTS trigger_notify_exchange_request ON exchanges;
DROP TRIGGER IF EXISTS trigger_notify_exchange_status_change ON exchanges;

-- 创建触发器
CREATE TRIGGER trigger_notify_exchange_request
  AFTER INSERT ON exchanges
  FOR EACH ROW
  EXECUTE FUNCTION notify_exchange_request();

CREATE TRIGGER trigger_notify_exchange_status_change
  AFTER UPDATE ON exchanges
  FOR EACH ROW
  EXECUTE FUNCTION notify_exchange_status_change();
