import { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { getExchangeTemplates, incrementTemplateUsage } from '@/db/api';
import type { ExchangeTemplate } from '@/types';
import { FileText, Sparkles, BookOpen, Heart, User } from 'lucide-react';
import { toast } from 'sonner';

interface TemplateSelectDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSelect: (template: ExchangeTemplate) => void;
}

export function TemplateSelectDialog({
  open,
  onOpenChange,
  onSelect,
}: TemplateSelectDialogProps) {
  const [templates, setTemplates] = useState<ExchangeTemplate[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('all');

  useEffect(() => {
    if (open) {
      loadTemplates();
    }
  }, [open]);

  const loadTemplates = async () => {
    try {
      setLoading(true);
      const data = await getExchangeTemplates();
      setTemplates(data);
    } catch (error) {
      console.error('加载模板失败:', error);
      toast.error('加载模板失败');
    } finally {
      setLoading(false);
    }
  };

  const handleSelectTemplate = async (template: ExchangeTemplate) => {
    try {
      // 增加使用次数
      await incrementTemplateUsage(template.id);
      onSelect(template);
      onOpenChange(false);
      toast.success('已应用模板');
    } catch (error) {
      console.error('应用模板失败:', error);
      toast.error('应用模板失败');
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'skill_learning':
        return <BookOpen className="h-4 w-4" />;
      case 'exam_tutoring':
        return <Sparkles className="h-4 w-4" />;
      case 'interest_exchange':
        return <Heart className="h-4 w-4" />;
      case 'custom':
        return <User className="h-4 w-4" />;
      default:
        return <FileText className="h-4 w-4" />;
    }
  };

  const getCategoryName = (category: string) => {
    switch (category) {
      case 'skill_learning':
        return '技能学习';
      case 'exam_tutoring':
        return '考试辅导';
      case 'interest_exchange':
        return '兴趣交流';
      case 'custom':
        return '自定义';
      default:
        return '其他';
    }
  };

  const filteredTemplates = templates.filter((t) => {
    if (activeTab === 'all') return true;
    if (activeTab === 'system') return t.is_system;
    if (activeTab === 'custom') return !t.is_system;
    return t.category === activeTab;
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>选择交换模板</DialogTitle>
          <DialogDescription>
            从预设模板中选择一个，或使用自己创建的模板
          </DialogDescription>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="all">全部</TabsTrigger>
            <TabsTrigger value="system">系统模板</TabsTrigger>
            <TabsTrigger value="skill_learning">技能学习</TabsTrigger>
            <TabsTrigger value="exam_tutoring">考试辅导</TabsTrigger>
            <TabsTrigger value="interest_exchange">兴趣交流</TabsTrigger>
          </TabsList>

          <TabsContent value={activeTab} className="mt-4 space-y-3">
            {loading ? (
              // 骨架屏
              Array.from({ length: 3 }).map((_, i) => (
                <Card key={i}>
                  <CardContent className="p-4">
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <Skeleton className="h-5 w-48 bg-muted" />
                        <Skeleton className="h-5 w-20 bg-muted" />
                      </div>
                      <Skeleton className="h-20 w-full bg-muted" />
                      <div className="flex items-center justify-between">
                        <Skeleton className="h-4 w-32 bg-muted" />
                        <Skeleton className="h-9 w-24 bg-muted" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : filteredTemplates.length === 0 ? (
              // 空状态
              <Card>
                <CardContent className="p-12 text-center">
                  <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <p className="text-muted-foreground">暂无模板</p>
                </CardContent>
              </Card>
            ) : (
              // 模板列表
              filteredTemplates.map((template) => (
                <Card
                  key={template.id}
                  className="cursor-pointer transition-all hover:shadow-md"
                >
                  <CardContent className="p-4">
                    <div className="space-y-3">
                      {/* 标题和标签 */}
                      <div className="flex items-start justify-between gap-2">
                        <h3 className="text-base font-semibold flex-1">
                          {template.title}
                        </h3>
                        <div className="flex items-center gap-2 shrink-0">
                          {template.is_system && (
                            <Badge variant="secondary" className="gap-1">
                              <Sparkles className="h-3 w-3" />
                              系统
                            </Badge>
                          )}
                          <Badge variant="outline" className="gap-1">
                            {getCategoryIcon(template.category)}
                            {getCategoryName(template.category)}
                          </Badge>
                        </div>
                      </div>

                      {/* 内容预览 */}
                      <div className="text-sm text-muted-foreground line-clamp-3 bg-muted/50 p-3 rounded-md">
                        {template.content.substring(0, 150)}...
                      </div>

                      {/* 底部信息和操作 */}
                      <div className="flex items-center justify-between">
                        <div className="text-xs text-muted-foreground">
                          已使用 {template.usage_count} 次
                        </div>
                        <Button
                          size="sm"
                          onClick={() => handleSelectTemplate(template)}
                        >
                          使用此模板
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </TabsContent>
        </Tabs>

        <div className="flex justify-end gap-2 pt-4 border-t">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            取消
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
