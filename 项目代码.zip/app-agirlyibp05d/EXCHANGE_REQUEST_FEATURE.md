# 技能交换申请功能说明

## 功能概述
技能交换申请功能允许用户向技能发布者发起交换申请，支持三种交换模式（直接交换、积分交换、团购交换），并提供完整的申请管理流程。

---

## 1. 数据库设计

### 1.1 exchange_requests表
交换申请表，存储所有交换申请记录。

| 字段名 | 类型 | 说明 |
|--------|------|------|
| id | uuid | 主键 |
| from_user_id | uuid | 申请发起人ID |
| to_user_id | uuid | 申请接收人ID（技能发布者） |
| skill_id | uuid | 技能ID |
| mode | text | 交换模式：direct-直接交换, integral-积分交换, group-团购交换 |
| duration | numeric | 交换时长（小时） |
| start_time | timestamptz | 期望开始时间 |
| end_time | timestamptz | 期望结束时间 |
| message | text | 附加留言（可选） |
| status | text | 状态：pending-待确认, accepted-已同意, rejected-已拒绝, cancelled-已取消 |
| points_amount | int | 积分金额（积分交换模式） |
| created_at | timestamptz | 创建时间 |
| updated_at | timestamptz | 更新时间 |

### 1.2 索引
- `idx_exchange_requests_from_user`: from_user_id索引
- `idx_exchange_requests_to_user`: to_user_id索引
- `idx_exchange_requests_skill`: skill_id索引
- `idx_exchange_requests_status`: status索引

### 1.3 RLS策略
- 用户可以查看自己发起或接收的申请
- 用户可以创建交换申请
- 用户可以更新自己接收的申请（同意/拒绝）
- 用户可以取消自己发起的申请

---

## 2. RPC函数

### 2.1 create_exchange_request
创建交换申请

**参数**:
- `p_to_user_id`: 接收人ID
- `p_skill_id`: 技能ID
- `p_mode`: 交换模式
- `p_duration`: 交换时长
- `p_start_time`: 期望开始时间
- `p_message`: 附加留言（可选）

**返回**:
```json
{
  "success": true,
  "request_id": "uuid",
  "message": "交换申请已发送"
}
```

**业务逻辑**:
1. 检查是否向自己发起申请
2. 如果是积分交换，检查技能价格和用户余额
3. 创建交换申请记录
4. 自动计算结束时间

### 2.2 handle_exchange_request
处理交换申请（同意/拒绝）

**参数**:
- `p_request_id`: 申请ID
- `p_action`: 操作类型（'accept' 或 'reject'）

**返回**:
```json
{
  "success": true,
  "exchange_id": "uuid",
  "message": "已同意交换申请"
}
```

**业务逻辑**:
1. 检查申请是否存在且状态为pending
2. 如果同意：
   - 更新申请状态为accepted
   - 如果是积分交换，扣除申请方积分，增加接收方积分
   - 记录积分交易
   - 创建交换记录（exchanges表）
3. 如果拒绝：
   - 更新申请状态为rejected

### 2.3 cancel_exchange_request
取消交换申请

**参数**:
- `p_request_id`: 申请ID

**返回**:
```json
{
  "success": true,
  "message": "已取消交换申请"
}
```

**业务逻辑**:
1. 检查申请是否存在且状态为pending
2. 更新申请状态为cancelled

---

## 3. API函数

### 3.1 createExchangeRequest
创建交换申请

```typescript
createExchangeRequest(params: {
  toUserId: string;
  skillId: string;
  mode: 'direct' | 'integral' | 'group';
  duration: number;
  startTime: string;
  message?: string;
}): Promise<{ success: boolean; requestId: string; message: string }>
```

### 3.2 getMyExchangeRequests
获取我发起的交换申请

```typescript
getMyExchangeRequests(
  status?: 'pending' | 'accepted' | 'rejected' | 'cancelled'
): Promise<ExchangeRequest[]>
```

### 3.3 getReceivedExchangeRequests
获取我收到的交换申请

```typescript
getReceivedExchangeRequests(
  status?: 'pending' | 'accepted' | 'rejected' | 'cancelled'
): Promise<ExchangeRequest[]>
```

### 3.4 getExchangeRequestById
获取交换申请详情

```typescript
getExchangeRequestById(
  requestId: string
): Promise<ExchangeRequest | null>
```

### 3.5 handleExchangeRequest
处理交换申请（同意/拒绝）

```typescript
handleExchangeRequest(
  requestId: string,
  action: 'accept' | 'reject'
): Promise<{ success: boolean; exchangeId?: string; message: string }>
```

### 3.6 cancelExchangeRequest
取消交换申请

```typescript
cancelExchangeRequest(
  requestId: string
): Promise<{ success: boolean; message: string }>
```

### 3.7 getPendingExchangeRequestsCount
获取待处理的交换申请数量

```typescript
getPendingExchangeRequestsCount(): Promise<number>
```

---

## 4. 前端组件

### 4.1 ExchangeRequestDialog
交换申请对话框组件

**Props**:
- `skillId`: 技能ID
- `skillName`: 技能名称
- `skillPrice`: 技能价格
- `publisherId`: 发布者ID
- `trigger`: 触发按钮（可选）
- `onSuccess`: 成功回调（可选）

**功能**:
- 选择交换模式（直接交换/积分交换/团购交换）
- 选择交换时长（0.5-3小时）
- 选择期望日期（日历选择器）
- 选择时间段（下拉选择）
- 填写附加留言（可选）
- 提交申请

**表单验证**:
- 日期必选
- 时间段必选
- 积分交换模式下检查余额

**时间段选项**:
- 08:00-09:00
- 09:00-10:00
- 10:00-11:00
- 11:00-12:00
- 13:00-14:00
- 14:00-15:00
- 15:00-16:00
- 16:00-17:00
- 17:00-18:00
- 18:00-19:00
- 19:00-20:00
- 20:00-21:00

### 4.2 ExchangeRequestsPage
交换申请列表页面

**功能**:
- 两个标签页：收到的申请、我发起的
- 显示申请列表
- 显示待处理申请数量徽章
- 同意/拒绝申请（收到的申请）
- 取消申请（我发起的申请）

**申请卡片信息**:
- 用户头像和昵称
- 申请状态徽章
- 技能名称和交换模式
- 积分金额（积分交换）
- 交换时长
- 期望时间段
- 附加留言
- 操作按钮

---

## 5. 业务流程

### 5.1 发起交换申请流程
1. 用户在技能详情页点击"发起交换"按钮
2. 弹出交换申请对话框
3. 用户填写申请信息：
   - 选择交换模式
   - 选择交换时长
   - 选择期望日期和时间段
   - 填写附加留言（可选）
4. 用户点击"发起申请"按钮
5. 系统验证表单数据
6. 如果是积分交换，检查用户余额
7. 调用`createExchangeRequest` API
8. 系统创建交换申请记录
9. 显示成功提示
10. 关闭对话框

### 5.2 处理交换申请流程（同意）
1. 用户在交换申请页面查看收到的申请
2. 用户点击"同意"按钮
3. 调用`handleExchangeRequest` API，action='accept'
4. 系统更新申请状态为accepted
5. 如果是积分交换：
   - 扣除申请方积分
   - 增加接收方积分
   - 记录积分交易
6. 系统创建交换记录（exchanges表）
7. 显示成功提示
8. 刷新申请列表

### 5.3 处理交换申请流程（拒绝）
1. 用户在交换申请页面查看收到的申请
2. 用户点击"拒绝"按钮
3. 调用`handleExchangeRequest` API，action='reject'
4. 系统更新申请状态为rejected
5. 显示成功提示
6. 刷新申请列表

### 5.4 取消交换申请流程
1. 用户在交换申请页面查看我发起的申请
2. 用户点击"取消申请"按钮
3. 调用`cancelExchangeRequest` API
4. 系统更新申请状态为cancelled
5. 显示成功提示
6. 刷新申请列表

---

## 6. 交换模式说明

### 6.1 直接交换（direct）
- 用户用自己的技能交换对方的技能
- 不涉及积分交易
- 双方确认后进入交换中状态

### 6.2 积分交换（integral）
- 用户使用积分购买技能服务
- 申请时检查用户余额
- 对方同意后扣除申请方积分，增加接收方积分
- 记录积分交易

### 6.3 团购交换（group）
- 参与团购，享受优惠价格
- 类似积分交换，但价格不同
- 需要达到最低参团人数

---

## 7. 状态说明

### 7.1 申请状态
- **pending**: 待确认 - 申请已发送，等待对方确认
- **accepted**: 已同意 - 对方已同意申请，交换进行中
- **rejected**: 已拒绝 - 对方已拒绝申请
- **cancelled**: 已取消 - 申请方已取消申请

### 7.2 状态转换
```
pending → accepted (对方同意)
pending → rejected (对方拒绝)
pending → cancelled (申请方取消)
```

---

## 8. 积分交易

### 8.1 积分交换流程
1. 申请时检查用户余额是否足够
2. 对方同意后：
   - 扣除申请方积分：`balance - points_amount`
   - 增加接收方积分：`balance + points_amount`
   - 更新累计支出：`total_spent + points_amount`
   - 更新累计收入：`total_earned + points_amount`
3. 记录积分交易：
   - 申请方：expense类型，金额为负
   - 接收方：income类型，金额为正

### 8.2 积分交易记录
```sql
INSERT INTO integral_transactions (user_id, amount, type, reason, related_id)
VALUES
  (from_user_id, -points_amount, 'expense', '积分交换支付', request_id),
  (to_user_id, points_amount, 'income', '积分交换收入', request_id);
```

---

## 9. 通知机制

### 9.1 申请通知
- 申请发送后，接收方收到通知
- 通知内容：用户昵称、技能名称、交换模式
- 通知跳转：交换申请页面

### 9.2 处理通知
- 对方同意后，申请方收到通知
- 对方拒绝后，申请方收到通知
- 通知内容：处理结果、技能名称

---

## 10. 用户界面

### 10.1 技能详情页
- 显示"发起交换"按钮
- 点击按钮弹出交换申请对话框
- 非技能发布者可见

### 10.2 交换申请对话框
- 技能信息展示
- 交换模式选择
- 交换时长选择
- 期望日期选择（日历）
- 时间段选择（下拉）
- 附加留言输入
- 取消/发起申请按钮

### 10.3 交换申请页面
- 两个标签页：收到的申请、我发起的
- 申请列表展示
- 待处理申请数量徽章
- 申请卡片：
  - 用户信息
  - 技能信息
  - 时间信息
  - 留言信息
  - 操作按钮

---

## 11. 错误处理

### 11.1 前端验证
- 日期必选
- 时间段必选
- 积分交换模式下检查余额

### 11.2 后端验证
- 检查是否向自己发起申请
- 检查技能是否存在
- 检查用户余额是否足够
- 检查申请是否存在
- 检查申请状态是否为pending

### 11.3 错误提示
- "不能向自己发起交换申请"
- "技能不存在或已删除"
- "积分余额不足"
- "申请不存在或无权操作"
- "无效的操作"

---

## 12. 性能优化

### 12.1 数据库优化
- 创建索引：from_user_id、to_user_id、skill_id、status
- 使用RLS策略限制数据访问
- 使用RPC函数封装业务逻辑

### 12.2 前端优化
- 使用骨架屏提升加载体验
- 并行加载我发起的和收到的申请
- 操作后刷新列表

---

## 13. 安全性

### 13.1 RLS策略
- 用户只能查看自己相关的申请
- 用户只能创建自己发起的申请
- 用户只能更新自己接收的申请
- 用户只能取消自己发起的申请

### 13.2 业务逻辑
- 检查是否向自己发起申请
- 检查用户余额是否足够
- 检查申请状态是否为pending
- 使用SECURITY DEFINER确保权限

---

## 14. 测试建议

### 14.1 功能测试
1. 测试发起交换申请
2. 测试同意交换申请
3. 测试拒绝交换申请
4. 测试取消交换申请
5. 测试积分交换流程
6. 测试直接交换流程
7. 测试团购交换流程

### 14.2 边界测试
1. 测试向自己发起申请
2. 测试余额不足时发起积分交换
3. 测试重复处理申请
4. 测试取消已处理的申请

### 14.3 性能测试
1. 测试大量申请列表加载
2. 测试并发创建申请
3. 测试并发处理申请

---

## 15. 扩展功能建议

### 15.1 申请提醒
- 新申请推送通知
- 申请处理结果推送通知
- 申请即将过期提醒

### 15.2 申请筛选
- 按交换模式筛选
- 按状态筛选
- 按时间筛选

### 15.3 申请搜索
- 按技能名称搜索
- 按用户昵称搜索

### 15.4 申请统计
- 申请总数
- 成功率
- 平均响应时间

### 15.5 申请评价
- 交换完成后评价
- 评价展示在申请详情

---

## 16. 常见问题

### Q1: 为什么需要交换申请功能？
A: 交换申请功能提供了一个正式的交换流程，让用户可以明确交换的时间、时长和模式，避免沟通不畅导致的误解。

### Q2: 积分交换和直接交换有什么区别？
A: 积分交换使用积分购买技能服务，直接交换用自己的技能交换对方的技能。积分交换更灵活，直接交换更公平。

### Q3: 申请被拒绝后积分会退还吗？
A: 申请时不会预扣积分，只有对方同意后才会扣除积分，所以不存在退还问题。

### Q4: 可以取消已发送的申请吗？
A: 可以，只要申请状态为pending（待确认），申请方可以随时取消。

### Q5: 对方多久不响应申请会自动失效？
A: 目前没有自动失效机制，建议后续添加48小时自动失效功能。

---

## 17. 更新日志

### v1.0.0 (2026-03-23)
- 初始版本
- 创建exchange_requests表
- 创建RPC函数：create_exchange_request、handle_exchange_request、cancel_exchange_request
- 创建API函数：createExchangeRequest、getMyExchangeRequests、getReceivedExchangeRequests等
- 创建ExchangeRequestDialog组件
- 创建ExchangeRequestsPage页面
- 更新SkillDetailPage，添加"发起交换"按钮

---

**最后更新**: 2026-03-23
**版本**: v1.0.0
**维护者**: 技遇开发团队
