-- 积分交易记录表
CREATE TABLE IF NOT EXISTS integral_transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  type TEXT NOT NULL CHECK (type IN ('income', 'expense')),
  amount DECIMAL(10, 2) NOT NULL,
  balance DECIMAL(10, 2) NOT NULL,
  reason TEXT NOT NULL,
  related_id UUID,
  expire_date DATE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 信用变化记录表
CREATE TABLE IF NOT EXISTS credit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  change_amount DECIMAL(5, 2) NOT NULL,
  new_score DECIMAL(5, 2) NOT NULL,
  reason TEXT NOT NULL,
  related_id UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 用户积分账户表
CREATE TABLE IF NOT EXISTS user_integral (
  user_id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  balance DECIMAL(10, 2) NOT NULL DEFAULT 0,
  total_earned DECIMAL(10, 2) NOT NULL DEFAULT 0,
  total_spent DECIMAL(10, 2) NOT NULL DEFAULT 0,
  last_sign_time TIMESTAMPTZ,
  frozen_amount DECIMAL(10, 2) NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 用户信用表
CREATE TABLE IF NOT EXISTS user_credit (
  user_id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  score DECIMAL(5, 2) NOT NULL DEFAULT 100,
  level TEXT NOT NULL DEFAULT 'trusted' CHECK (level IN ('newbie', 'trusted', 'excellent', 'master')),
  completed_exchanges INT NOT NULL DEFAULT 0,
  total_exchanges INT NOT NULL DEFAULT 0,
  total_rating DECIMAL(10, 2) NOT NULL DEFAULT 0,
  rating_count INT NOT NULL DEFAULT 0,
  timely_count INT NOT NULL DEFAULT 0,
  activity_score DECIMAL(5, 2) NOT NULL DEFAULT 0,
  consecutive_good_ratings INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 定期存款记录表
CREATE TABLE IF NOT EXISTS fixed_deposits (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  amount DECIMAL(10, 2) NOT NULL,
  period_days INT NOT NULL CHECK (period_days IN (7, 30)),
  interest_rate DECIMAL(5, 4) NOT NULL,
  start_date TIMESTAMPTZ NOT NULL DEFAULT now(),
  end_date TIMESTAMPTZ NOT NULL,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'completed', 'cancelled')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 签到记录表
CREATE TABLE IF NOT EXISTS sign_ins (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  sign_date DATE NOT NULL DEFAULT CURRENT_DATE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(user_id, sign_date)
);

-- 邀请记录表
CREATE TABLE IF NOT EXISTS invitations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  inviter_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  invitee_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  reward_given BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(invitee_id)
);

-- 技能系数配置表
CREATE TABLE IF NOT EXISTS skill_coefficients (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  skill_id UUID NOT NULL REFERENCES skills(id) ON DELETE CASCADE,
  coefficient DECIMAL(3, 2) NOT NULL DEFAULT 1.0,
  reason TEXT,
  updated_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 连续学习记录表
CREATE TABLE IF NOT EXISTS learning_streaks (
  user_id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  current_streak INT NOT NULL DEFAULT 0,
  last_exchange_date DATE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 创建索引
CREATE INDEX IF NOT EXISTS idx_integral_transactions_user_id ON integral_transactions(user_id);
CREATE INDEX IF NOT EXISTS idx_integral_transactions_created_at ON integral_transactions(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_credit_logs_user_id ON credit_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_credit_logs_created_at ON credit_logs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_fixed_deposits_user_id ON fixed_deposits(user_id);
CREATE INDEX IF NOT EXISTS idx_fixed_deposits_end_date ON fixed_deposits(end_date);
CREATE INDEX IF NOT EXISTS idx_sign_ins_user_id ON sign_ins(user_id);
CREATE INDEX IF NOT EXISTS idx_invitations_inviter_id ON invitations(inviter_id);

-- RLS策略
ALTER TABLE integral_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE credit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_integral ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_credit ENABLE ROW LEVEL SECURITY;
ALTER TABLE fixed_deposits ENABLE ROW LEVEL SECURITY;
ALTER TABLE sign_ins ENABLE ROW LEVEL SECURITY;
ALTER TABLE invitations ENABLE ROW LEVEL SECURITY;
ALTER TABLE skill_coefficients ENABLE ROW LEVEL SECURITY;
ALTER TABLE learning_streaks ENABLE ROW LEVEL SECURITY;

-- integral_transactions策略
CREATE POLICY "Users can view own integral transactions" ON integral_transactions
  FOR SELECT USING (auth.uid() = user_id);

-- credit_logs策略
CREATE POLICY "Users can view own credit logs" ON credit_logs
  FOR SELECT USING (auth.uid() = user_id);

-- user_integral策略
CREATE POLICY "Users can view own integral account" ON user_integral
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can view others integral balance" ON user_integral
  FOR SELECT USING (true);

-- user_credit策略
CREATE POLICY "Users can view own credit" ON user_credit
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can view others credit" ON user_credit
  FOR SELECT USING (true);

-- fixed_deposits策略
CREATE POLICY "Users can view own deposits" ON fixed_deposits
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can create deposits" ON fixed_deposits
  FOR INSERT WITH CHECK (auth.uid() = user_id);

-- sign_ins策略
CREATE POLICY "Users can view own sign ins" ON sign_ins
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can create sign ins" ON sign_ins
  FOR INSERT WITH CHECK (auth.uid() = user_id);

-- invitations策略
CREATE POLICY "Users can view own invitations" ON invitations
  FOR SELECT USING (auth.uid() = inviter_id OR auth.uid() = invitee_id);

-- skill_coefficients策略
CREATE POLICY "Anyone can view skill coefficients" ON skill_coefficients
  FOR SELECT USING (true);

-- learning_streaks策略
CREATE POLICY "Users can view own learning streaks" ON learning_streaks
  FOR SELECT USING (auth.uid() = user_id);