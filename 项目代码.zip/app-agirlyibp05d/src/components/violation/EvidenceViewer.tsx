import { useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { FileText, Image as ImageIcon, Download, ExternalLink } from 'lucide-react';

interface EvidenceViewerProps {
  evidence: string[];
}

export function EvidenceViewer({ evidence }: EvidenceViewerProps) {
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [previewOpen, setPreviewOpen] = useState(false);

  if (!evidence || evidence.length === 0) {
    return null;
  }

  const getFileType = (url: string): 'image' | 'pdf' | 'unknown' => {
    const lowerUrl = url.toLowerCase();
    if (lowerUrl.match(/\.(jpg|jpeg|png|gif|webp)$/)) {
      return 'image';
    }
    if (lowerUrl.endsWith('.pdf')) {
      return 'pdf';
    }
    return 'unknown';
  };

  const getFileName = (url: string): string => {
    try {
      const urlObj = new URL(url);
      const pathParts = urlObj.pathname.split('/');
      return pathParts[pathParts.length - 1] || '文件';
    } catch {
      return '文件';
    }
  };

  const handlePreview = (url: string) => {
    const type = getFileType(url);
    if (type === 'image') {
      setPreviewUrl(url);
      setPreviewOpen(true);
    } else {
      window.open(url, '_blank');
    }
  };

  const handleDownload = async (url: string) => {
    try {
      const response = await fetch(url);
      const blob = await response.blob();
      const downloadUrl = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = downloadUrl;
      a.download = getFileName(url);
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(downloadUrl);
    } catch (error) {
      console.error('下载文件失败:', error);
    }
  };

  return (
    <>
      <div className="space-y-2">
        <p className="text-sm font-medium">申诉证据：</p>
        <div className="grid grid-cols-1 gap-2">
          {evidence.map((url, index) => {
            const type = getFileType(url);
            const fileName = getFileName(url);

            return (
              <div
                key={index}
                className="flex items-center gap-3 p-3 border rounded-lg bg-muted/50 hover:bg-muted transition-colors"
              >
                <div className="shrink-0 text-muted-foreground">
                  {type === 'image' ? (
                    <ImageIcon className="h-4 w-4" />
                  ) : (
                    <FileText className="h-4 w-4" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{fileName}</p>
                  <p className="text-xs text-muted-foreground">
                    {type === 'image' ? '图片' : type === 'pdf' ? 'PDF文档' : '文件'}
                  </p>
                </div>
                <div className="flex gap-1 shrink-0">
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => handlePreview(url)}
                    title={type === 'image' ? '预览' : '打开'}
                  >
                    <ExternalLink className="h-4 w-4" />
                  </Button>
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => handleDownload(url)}
                    title="下载"
                  >
                    <Download className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 图片预览对话框 */}
      <Dialog open={previewOpen} onOpenChange={setPreviewOpen}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>图片预览</DialogTitle>
          </DialogHeader>
          {previewUrl && (
            <div className="flex items-center justify-center p-4">
              <img
                src={previewUrl}
                alt="证据图片"
                className="max-w-full max-h-[70vh] object-contain rounded-lg"
              />
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
