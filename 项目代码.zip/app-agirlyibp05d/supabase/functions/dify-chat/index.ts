// Dify AI 问答助手服务
// 调用Dify API实现智能对话功能

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface ChatRequest {
  query: string;
  user?: string;
}

Deno.serve(async (req) => {
  // 处理CORS预检请求
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const apiKey = Deno.env.get('DIFY_API_KEY');

    if (!apiKey) {
      throw new Error('Dify API密钥未配置,请联系管理员配置DIFY_API_KEY');
    }

    const body: ChatRequest = await req.json();
    const { query, user = 'jid-user-001' } = body;

    if (!query || !query.trim()) {
      return new Response(
        JSON.stringify({ error: '问题不能为空' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // 调用Dify API
    const difyResponse = await fetch('https://api.dify.ai/v1/chat-messages', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        inputs: {},
        query: query.trim(),
        response_mode: 'blocking',
        user,
      }),
    });

    if (!difyResponse.ok) {
      const errorText = await difyResponse.text();
      console.error('Dify API错误:', errorText);
      
      if (difyResponse.status === 429) {
        throw new Error('API调用频率超限,请稍后再试');
      } else if (difyResponse.status === 401) {
        throw new Error('API密钥无效,请联系管理员');
      } else {
        throw new Error(`API调用失败: ${difyResponse.status}`);
      }
    }

    const difyData = await difyResponse.json();

    // 提取答案
    const answer = difyData.answer || difyData.message || '抱歉,我无法回答这个问题';

    return new Response(
      JSON.stringify({
        success: true,
        answer,
        conversationId: difyData.conversation_id,
        messageId: difyData.message_id,
      }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('AI问答服务错误:', error);
    return new Response(
      JSON.stringify({ 
        success: false,
        error: error.message || '服务器错误,请稍后重试' 
      }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
