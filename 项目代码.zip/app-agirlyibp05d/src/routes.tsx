import HomePage from './pages/HomePage';
import LoginPage from './pages/LoginPage';
import OnboardingPage from './pages/OnboardingPage';
import ForumListPage from './pages/ForumListPage';
import ForumDetailPage from './pages/ForumDetailPage';
import SkillMarketPage from './pages/SkillMarketPage';
import SkillDetailPage from './pages/SkillDetailPage';
import ExchangeRequestsPage from './pages/ExchangeRequestsPage';
import ExchangeCenterPage from './pages/ExchangeCenterPage';
import ProfilePage from './pages/ProfilePage';
import MySkillsPage from './pages/MySkillsPage';
import ExchangeHistoryPage from './pages/ExchangeHistoryPage';
import FavoritesPage from './pages/FavoritesPage';
import SettingsPage from './pages/SettingsPage';
import RatePage from './pages/RatePage';
import PointsDetailPage from './pages/PointsDetailPage';
import CreditDetailPage from './pages/CreditDetailPage';
import IntegralDetailPage from './pages/IntegralDetailPage';
import FixedDepositPage from './pages/FixedDepositPage';
import AIChatPage from './pages/AIChatPage';
import FriendsPage from './pages/FriendsPage';
import FriendRequestsPage from './pages/FriendRequestsPage';
import NotificationsPage from './pages/NotificationsPage';
import MyExchangesPage from './pages/MyExchangesPage';
import ExchangeDetailPage from './pages/ExchangeDetailPage';
import PendingRatingsPage from './pages/PendingRatingsPage';
import InterestsSettingsPage from './pages/InterestsSettingsPage';
import MyTemplatesPage from './pages/MyTemplatesPage';
import ViolationRecordsPage from './pages/ViolationRecordsPage';
import AppealRecordsPage from './pages/AppealRecordsPage';
import NotFound from './pages/NotFound';
import type { ReactNode } from 'react';

interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
}

const routes: RouteConfig[] = [
  {
    name: '首页',
    path: '/',
    element: <HomePage />,
  },
  {
    name: '登录',
    path: '/login',
    element: <LoginPage />,
  },
  {
    name: '新手引导',
    path: '/onboarding',
    element: <OnboardingPage />,
  },
  {
    name: '社区论坛',
    path: '/forum',
    element: <ForumListPage />,
  },
  {
    name: '帖子详情',
    path: '/forum/:id',
    element: <ForumDetailPage />,
  },
  {
    name: '技能广场',
    path: '/skills',
    element: <SkillMarketPage />,
  },
  {
    name: '技能详情',
    path: '/skills/:id',
    element: <SkillDetailPage />,
  },
  {
    name: '交换中心',
    path: '/exchanges',
    element: <ExchangeRequestsPage />,
  },
  {
    name: '发起交换',
    path: '/exchanges/create',
    element: <ExchangeCenterPage />,
  },
  {
    name: '我的交换',
    path: '/my-exchanges',
    element: <MyExchangesPage />,
  },
  {
    name: '交换详情',
    path: '/exchanges/:id',
    element: <ExchangeDetailPage />,
  },
  {
    name: '个人中心',
    path: '/profile',
    element: <ProfilePage />,
  },
  {
    name: '我的技能',
    path: '/profile/skills',
    element: <MySkillsPage />,
  },
  {
    name: '交换记录',
    path: '/profile/exchanges',
    element: <ExchangeHistoryPage />,
  },
  {
    name: '我的收藏',
    path: '/profile/favorites',
    element: <FavoritesPage />,
  },
  {
    name: '设置',
    path: '/profile/settings',
    element: <SettingsPage />,
  },
  {
    name: '评价',
    path: '/rate/:id',
    element: <RatePage />,
  },
  {
    name: '待评价交换',
    path: '/pending-ratings',
    element: <PendingRatingsPage />,
  },
  {
    name: '兴趣设置',
    path: '/profile/interests',
    element: <InterestsSettingsPage />,
  },
  {
    name: '我的模板',
    path: '/profile/templates',
    element: <MyTemplatesPage />,
  },
  {
    name: '违规记录',
    path: '/profile/violations',
    element: <ViolationRecordsPage />,
  },
  {
    name: '申诉记录',
    path: '/profile/appeals',
    element: <AppealRecordsPage />,
  },
  {
    name: '技易点明细',
    path: '/profile/points',
    element: <PointsDetailPage />,
  },
  {
    name: '信用分明细',
    path: '/profile/credit',
    element: <CreditDetailPage />,
  },
  {
    name: '积分明细',
    path: '/profile/integral',
    element: <IntegralDetailPage />,
  },
  {
    name: '定期存款',
    path: '/profile/fixed-deposit',
    element: <FixedDepositPage />,
  },
  {
    name: '习遇',
    path: '/ai-chat',
    element: <AIChatPage />,
  },
  {
    name: '我的好友',
    path: '/friends',
    element: <FriendsPage />,
  },
  {
    name: '好友申请',
    path: '/friend-requests',
    element: <FriendRequestsPage />,
  },
  {
    name: '消息通知',
    path: '/notifications',
    element: <NotificationsPage />,
  },
  {
    name: '404',
    path: '*',
    element: <NotFound />,
  },
];

export default routes;
