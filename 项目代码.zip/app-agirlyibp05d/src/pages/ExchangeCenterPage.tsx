import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { MainLayout } from '@/components/layouts/MainLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useAuth } from '@/contexts/AuthContext';
import {
  getSkillById,
  getUserSkills,
  createDirectExchange,
  createPointExchange,
  createGroupBuy,
  joinGroupBuy,
  getGroupBuys,
  getGroupBuyParticipants,
} from '@/db/api';
import type { Skill, GroupBuy, GroupBuyParticipant } from '@/types';
import { Repeat, Coins, Users, ArrowLeft } from 'lucide-react';
import { toast } from 'sonner';
import { Link } from 'react-router-dom';
import { formatDistanceToNow } from 'date-fns';
import { zhCN } from 'date-fns/locale';

export default function ExchangeCenterPage() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const skillId = searchParams.get('skillId');
  const groupBuyId = searchParams.get('groupBuyId');
  const { profile } = useAuth();

  const [targetSkill, setTargetSkill] = useState<Skill | null>(null);
  const [mySkills, setMySkills] = useState<Skill[]>([]);
  const [groupBuys, setGroupBuys] = useState<GroupBuy[]>([]);
  const [selectedGroupBuy, setSelectedGroupBuy] = useState<GroupBuy | null>(null);
  const [groupBuyParticipants, setGroupBuyParticipants] = useState<GroupBuyParticipant[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  const [directForm, setDirectForm] = useState({
    mySkillId: '',
    note: '',
  });

  const [groupBuyForm, setGroupBuyForm] = useState({
    groupPrice: 0,
  });

  useEffect(() => {
    loadData();
  }, [skillId, groupBuyId, profile]);

  const loadData = async () => {
    if (!profile) return;

    try {
      setLoading(true);

      if (skillId) {
        const [skill, skills, gbs] = await Promise.all([
          getSkillById(skillId),
          getUserSkills(profile.id),
          getGroupBuys(skillId),
        ]);
        setTargetSkill(skill);
        setMySkills(skills.filter((s) => s.status === 'active'));
        setGroupBuys(gbs);

        if (skill) {
          setGroupBuyForm({ groupPrice: Math.floor(skill.price * 0.8) });
        }
      }

      if (groupBuyId) {
        const gbs = await getGroupBuys();
        const gb = gbs.find((g) => g.id === groupBuyId);
        if (gb) {
          setSelectedGroupBuy(gb);
          const participants = await getGroupBuyParticipants(groupBuyId);
          setGroupBuyParticipants(participants);
        }
      }
    } catch (error) {
      toast.error('加载数据失败');
    } finally {
      setLoading(false);
    }
  };

  const handleDirectExchange = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetSkill || !directForm.mySkillId) return;

    setSubmitting(true);
    try {
      await createDirectExchange({
        receiver_id: targetSkill.user_id,
        initiator_skill_id: directForm.mySkillId,
        receiver_skill_id: targetSkill.id,
        note: directForm.note || undefined,
      });

      toast.success('交换申请已发送');
      navigate('/profile/exchanges');
    } catch (error) {
      toast.error('发送失败');
    } finally {
      setSubmitting(false);
    }
  };

  const handlePointExchange = async () => {
    if (!targetSkill || !profile) return;

    if (profile.points < targetSkill.price) {
      toast.error('技易点余额不足');
      return;
    }

    setSubmitting(true);
    try {
      await createPointExchange({
        receiver_id: targetSkill.user_id,
        receiver_skill_id: targetSkill.id,
        points_amount: targetSkill.price,
      });

      toast.success('兑换成功!双方各获得10技易点奖励');
      navigate('/profile/exchanges');
    } catch (error) {
      toast.error('兑换失败');
    } finally {
      setSubmitting(false);
    }
  };

  const handleCreateGroupBuy = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetSkill) return;

    if (groupBuyForm.groupPrice >= targetSkill.price) {
      toast.error('团购价必须低于原价');
      return;
    }

    setSubmitting(true);
    try {
      await createGroupBuy({
        skill_id: targetSkill.id,
        original_price: targetSkill.price,
        group_price: groupBuyForm.groupPrice,
      });

      toast.success('团购创建成功,你已自动参团');
      navigate('/profile/exchanges');
    } catch (error) {
      toast.error('创建失败');
    } finally {
      setSubmitting(false);
    }
  };

  const handleJoinGroupBuy = async () => {
    if (!selectedGroupBuy || !profile) return;

    if (profile.points < selectedGroupBuy.group_price) {
      toast.error('技易点余额不足');
      return;
    }

    setSubmitting(true);
    try {
      await joinGroupBuy(selectedGroupBuy.id);
      toast.success('参团成功!');
      navigate('/profile/exchanges');
    } catch (error: any) {
      toast.error(error.message || '参团失败');
    } finally {
      setSubmitting(false);
    }
  };

  if (!profile) {
    return (
      <MainLayout>
        <Card>
          <CardContent className="py-12 text-center text-muted-foreground">
            请先登录
          </CardContent>
        </Card>
      </MainLayout>
    );
  }

  if (loading) {
    return (
      <MainLayout>
        <div className="max-w-4xl mx-auto">
          <Card>
            <CardContent className="py-12 text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
            </CardContent>
          </Card>
        </div>
      </MainLayout>
    );
  }

  // 如果是参与团购
  if (groupBuyId && selectedGroupBuy) {
    return (
      <MainLayout>
        <div className="max-w-2xl mx-auto space-y-6">
          <Button asChild variant="ghost" size="sm" className="gap-2">
            <Link to={`/skills/${selectedGroupBuy.skill_id}`}>
              <ArrowLeft className="h-4 w-4" />
              返回技能详情
            </Link>
          </Button>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                参与团购
              </CardTitle>
              <CardDescription>
                {selectedGroupBuy.skills?.name}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">原价</p>
                  <p className="text-2xl font-bold line-through text-muted-foreground">
                    {selectedGroupBuy.original_price}
                  </p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">团购价</p>
                  <p className="text-2xl font-bold text-secondary">
                    {selectedGroupBuy.group_price}
                  </p>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">当前参团人数</span>
                  <span className="font-medium">{selectedGroupBuy.participant_count} / 3</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">还需人数</span>
                  <span className="font-medium">
                    {Math.max(0, 3 - selectedGroupBuy.participant_count)} 人
                  </span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">到期时间</span>
                  <span className="font-medium">
                    {formatDistanceToNow(new Date(selectedGroupBuy.expires_at), {
                      addSuffix: true,
                      locale: zhCN,
                    })}
                  </span>
                </div>
              </div>

              {groupBuyParticipants.length > 0 && (
                <div className="space-y-2">
                  <p className="text-sm font-medium">已参团用户</p>
                  <div className="space-y-2">
                    {groupBuyParticipants.map((p) => (
                      <div key={p.id} className="flex items-center space-x-2 text-sm">
                        <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                          <span className="text-xs">{p.profiles?.nickname?.[0] || '用'}</span>
                        </div>
                        <span>{p.profiles?.nickname || '未知用户'}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="p-4 rounded-lg bg-muted/50">
                <p className="text-sm text-muted-foreground">
                  你的技易点余额: <span className="font-medium">{profile.points}</span>
                </p>
              </div>

              <Button
                onClick={handleJoinGroupBuy}
                disabled={submitting || profile.points < selectedGroupBuy.group_price}
                className="w-full"
              >
                {submitting ? '参团中...' : `支付 ${selectedGroupBuy.group_price} 技易点参团`}
              </Button>
            </CardContent>
          </Card>
        </div>
      </MainLayout>
    );
  }

  // 如果没有指定技能
  if (!targetSkill) {
    return (
      <MainLayout>
        <Card>
          <CardContent className="py-12 text-center text-muted-foreground">
            请先选择要交换的技能
          </CardContent>
        </Card>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="max-w-4xl mx-auto space-y-6">
        <Button asChild variant="ghost" size="sm" className="gap-2">
          <Link to={`/skills/${targetSkill.id}`}>
            <ArrowLeft className="h-4 w-4" />
            返回技能详情
          </Link>
        </Button>

        <div>
          <h1 className="text-3xl font-bold">交换中心</h1>
          <p className="text-muted-foreground mt-1">选择交换方式</p>
        </div>

        {/* Target Skill Info */}
        <Card>
          <CardHeader>
            <CardTitle>目标技能</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <p className="text-lg font-medium">{targetSkill.name}</p>
              <p className="text-sm text-muted-foreground">{targetSkill.description}</p>
              <div className="flex items-center space-x-2">
                <Coins className="h-4 w-4 text-secondary" />
                <span className="text-sm font-medium">{targetSkill.price} 技易点</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Exchange Methods */}
        <Tabs defaultValue="direct" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="direct">直接交换</TabsTrigger>
            <TabsTrigger value="point">技易点兑换</TabsTrigger>
            <TabsTrigger value="group">发起团购</TabsTrigger>
          </TabsList>

          {/* Direct Exchange */}
          <TabsContent value="direct">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Repeat className="h-5 w-5" />
                  直接交换
                </CardTitle>
                <CardDescription>
                  用你的技能直接交换对方技能,需要对方同意
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleDirectExchange} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="my-skill">选择你的技能</Label>
                    <Select
                      value={directForm.mySkillId}
                      onValueChange={(value) => setDirectForm({ ...directForm, mySkillId: value })}
                    >
                      <SelectTrigger id="my-skill">
                        <SelectValue placeholder="选择一个技能" />
                      </SelectTrigger>
                      <SelectContent>
                        {mySkills.length > 0 ? (
                          mySkills.map((skill) => (
                            <SelectItem key={skill.id} value={skill.id}>
                              {skill.name} ({skill.price} 技易点)
                            </SelectItem>
                          ))
                        ) : (
                          <SelectItem value="none" disabled>
                            你还没有发布技能
                          </SelectItem>
                        )}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="note">交换说明 (可选)</Label>
                    <Textarea
                      id="note"
                      placeholder="向对方说明你的交换意向..."
                      value={directForm.note}
                      onChange={(e) => setDirectForm({ ...directForm, note: e.target.value })}
                      rows={4}
                    />
                  </div>

                  <Button type="submit" disabled={submitting || !directForm.mySkillId} className="w-full">
                    {submitting ? '发送中...' : '发送交换申请'}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Point Exchange */}
          <TabsContent value="point">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Coins className="h-5 w-5" />
                  技易点兑换
                </CardTitle>
                <CardDescription>
                  使用技易点直接购买技能,立即完成交换
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 rounded-lg bg-muted/50">
                    <span className="text-sm text-muted-foreground">需要支付</span>
                    <span className="text-2xl font-bold text-secondary">{targetSkill.price}</span>
                  </div>

                  <div className="flex items-center justify-between p-4 rounded-lg bg-muted/50">
                    <span className="text-sm text-muted-foreground">你的余额</span>
                    <span className="text-2xl font-bold">{profile.points}</span>
                  </div>

                  {profile.points < targetSkill.price && (
                    <p className="text-sm text-destructive">技易点余额不足</p>
                  )}
                </div>

                <div className="p-4 rounded-lg bg-accent/50 border border-border">
                  <p className="text-sm text-muted-foreground">
                    ✨ 完成交换后,你和对方各获得10技易点奖励
                  </p>
                </div>

                <Button
                  onClick={handlePointExchange}
                  disabled={submitting || profile.points < targetSkill.price}
                  className="w-full"
                >
                  {submitting ? '兑换中...' : `支付 ${targetSkill.price} 技易点兑换`}
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Group Buy */}
          <TabsContent value="group">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  发起团购
                </CardTitle>
                <CardDescription>
                  发起团购,满3人即可成团,享受优惠价格
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleCreateGroupBuy} className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="group-price">团购价格</Label>
                    <Input
                      id="group-price"
                      type="number"
                      min="1"
                      max={targetSkill.price - 1}
                      value={groupBuyForm.groupPrice}
                      onChange={(e) =>
                        setGroupBuyForm({ groupPrice: Number.parseInt(e.target.value) })
                      }
                      required
                    />
                    <p className="text-xs text-muted-foreground">
                      原价 {targetSkill.price} 技易点,团购价必须低于原价
                    </p>
                  </div>

                  <div className="p-4 rounded-lg bg-accent/50 border border-border space-y-2">
                    <p className="text-sm font-medium">团购规则</p>
                    <ul className="text-xs text-muted-foreground space-y-1">
                      <li>• 最低3人成团,72小时内未成团自动失效</li>
                      <li>• 发起后你将自动参团</li>
                      <li>• 成团后所有参团者扣除团购价技易点</li>
                      <li>• 完成后每人获得10技易点奖励</li>
                    </ul>
                  </div>

                  <Button type="submit" disabled={submitting} className="w-full">
                    {submitting ? '创建中...' : '创建团购'}
                  </Button>
                </form>

                {/* Existing Group Buys */}
                {groupBuys.length > 0 && (
                  <div className="mt-6 space-y-3">
                    <p className="text-sm font-medium">进行中的团购</p>
                    {groupBuys.map((gb) => (
                      <div
                        key={gb.id}
                        className="p-4 rounded-lg border border-border space-y-2"
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium">团购价: {gb.group_price} 技易点</span>
                          <span className="text-xs text-muted-foreground">
                            {gb.participant_count} / 3 人
                          </span>
                        </div>
                        <Button asChild size="sm" variant="outline" className="w-full">
                          <Link to={`/exchanges?groupBuyId=${gb.id}`}>参与团购</Link>
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  );
}
