-- 创建申诉状态枚举
DO $$ BEGIN
  CREATE TYPE appeal_status AS ENUM ('pending', 'approved', 'rejected');
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

COMMENT ON TYPE appeal_status IS '申诉状态：pending待处理、approved申诉成功、rejected申诉失败';

-- 为violation_records表添加申诉状态字段
ALTER TABLE violation_records ADD COLUMN IF NOT EXISTS appeal_status text;
ALTER TABLE violation_records ADD COLUMN IF NOT EXISTS can_appeal boolean DEFAULT true;

COMMENT ON COLUMN violation_records.appeal_status IS '申诉状态：not_appealed未申诉、appealing申诉中、appeal_approved申诉成功、appeal_rejected申诉失败';
COMMENT ON COLUMN violation_records.can_appeal IS '是否可以申诉';

-- 创建申诉记录表
CREATE TABLE IF NOT EXISTS appeals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  violation_record_id uuid NOT NULL REFERENCES violation_records(id) ON DELETE CASCADE,
  appellant_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  reason text NOT NULL,
  evidence jsonb DEFAULT '[]',
  status appeal_status DEFAULT 'pending',
  handler_id uuid REFERENCES profiles(id) ON DELETE SET NULL,
  handler_note text,
  result text,
  handled_at timestamp with time zone,
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now(),
  UNIQUE(violation_record_id)
);

COMMENT ON TABLE appeals IS '申诉记录表';
COMMENT ON COLUMN appeals.violation_record_id IS '违规记录ID';
COMMENT ON COLUMN appeals.appellant_id IS '申诉人ID';
COMMENT ON COLUMN appeals.reason IS '申诉理由';
COMMENT ON COLUMN appeals.evidence IS '申诉证据（截图、链接等）';
COMMENT ON COLUMN appeals.status IS '申诉状态';
COMMENT ON COLUMN appeals.handler_id IS '处理人ID';
COMMENT ON COLUMN appeals.handler_note IS '处理备注';
COMMENT ON COLUMN appeals.result IS '处理结果（approved恢复信用分、rejected维持原判）';
COMMENT ON COLUMN appeals.handled_at IS '处理时间';

-- 创建索引
CREATE INDEX IF NOT EXISTS idx_appeals_violation_record ON appeals(violation_record_id);
CREATE INDEX IF NOT EXISTS idx_appeals_appellant ON appeals(appellant_id);
CREATE INDEX IF NOT EXISTS idx_appeals_status ON appeals(status);
CREATE INDEX IF NOT EXISTS idx_appeals_created ON appeals(created_at DESC);

-- 创建RLS策略
ALTER TABLE appeals ENABLE ROW LEVEL SECURITY;

-- 用户可以查看自己的申诉记录
CREATE POLICY appeals_select ON appeals
  FOR SELECT
  USING (appellant_id = auth.uid());

-- 用户可以创建申诉记录
CREATE POLICY appeals_insert ON appeals
  FOR INSERT
  WITH CHECK (appellant_id = auth.uid());

-- 创建RPC函数：提交申诉
CREATE OR REPLACE FUNCTION submit_appeal(
  p_violation_record_id uuid,
  p_reason text,
  p_evidence jsonb DEFAULT '[]'
) RETURNS jsonb AS $$
DECLARE
  v_appeal_id uuid;
  v_appellant_id uuid;
  v_violation_record record;
  v_appeal_deadline timestamp with time zone;
BEGIN
  -- 获取当前用户ID
  v_appellant_id := auth.uid();
  
  IF v_appellant_id IS NULL THEN
    RETURN jsonb_build_object(
      'success', false,
      'message', '未登录'
    );
  END IF;
  
  -- 获取违规记录
  SELECT * INTO v_violation_record
  FROM violation_records
  WHERE id = p_violation_record_id;
  
  IF v_violation_record IS NULL THEN
    RETURN jsonb_build_object(
      'success', false,
      'message', '违规记录不存在'
    );
  END IF;
  
  -- 检查是否是违规者本人
  IF v_violation_record.violator_id != v_appellant_id THEN
    RETURN jsonb_build_object(
      'success', false,
      'message', '只能对自己的违规记录申诉'
    );
  END IF;
  
  -- 检查违规记录状态（只能对已处理的记录申诉）
  IF v_violation_record.status != 'resolved' THEN
    RETURN jsonb_build_object(
      'success', false,
      'message', '只能对已处理的违规记录申诉'
    );
  END IF;
  
  -- 检查是否可以申诉
  IF v_violation_record.can_appeal = false THEN
    RETURN jsonb_build_object(
      'success', false,
      'message', '该违规记录不可申诉'
    );
  END IF;
  
  -- 检查申诉时限（处理后7天内）
  v_appeal_deadline := v_violation_record.handled_at + interval '7 days';
  IF now() > v_appeal_deadline THEN
    RETURN jsonb_build_object(
      'success', false,
      'message', '申诉时限已过（违规处理后7天内可申诉）'
    );
  END IF;
  
  -- 检查是否已经申诉过
  IF EXISTS (SELECT 1 FROM appeals WHERE violation_record_id = p_violation_record_id) THEN
    RETURN jsonb_build_object(
      'success', false,
      'message', '该违规记录已申诉，不可重复申诉'
    );
  END IF;
  
  -- 创建申诉记录
  INSERT INTO appeals (
    violation_record_id,
    appellant_id,
    reason,
    evidence,
    status
  ) VALUES (
    p_violation_record_id,
    v_appellant_id,
    p_reason,
    p_evidence,
    'pending'
  ) RETURNING id INTO v_appeal_id;
  
  -- 更新违规记录的申诉状态
  UPDATE violation_records
  SET appeal_status = 'appealing',
      updated_at = now()
  WHERE id = p_violation_record_id;
  
  RETURN jsonb_build_object(
    'success', true,
    'message', '申诉提交成功，我们会在3个工作日内处理',
    'appeal_id', v_appeal_id
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

COMMENT ON FUNCTION submit_appeal IS '提交申诉';

-- 创建RPC函数：处理申诉
CREATE OR REPLACE FUNCTION handle_appeal(
  p_appeal_id uuid,
  p_action text, -- 'approve'批准、'reject'驳回
  p_handler_note text DEFAULT NULL
) RETURNS jsonb AS $$
DECLARE
  v_handler_id uuid;
  v_appeal record;
  v_violation_record record;
  v_credit_to_restore integer;
  v_violation_count integer;
  v_new_status account_status;
BEGIN
  -- 获取当前用户ID
  v_handler_id := auth.uid();
  
  IF v_handler_id IS NULL THEN
    RETURN jsonb_build_object(
      'success', false,
      'message', '未登录'
    );
  END IF;
  
  -- 获取申诉记录
  SELECT * INTO v_appeal
  FROM appeals
  WHERE id = p_appeal_id;
  
  IF v_appeal IS NULL THEN
    RETURN jsonb_build_object(
      'success', false,
      'message', '申诉记录不存在'
    );
  END IF;
  
  IF v_appeal.status != 'pending' THEN
    RETURN jsonb_build_object(
      'success', false,
      'message', '该申诉已处理'
    );
  END IF;
  
  -- 获取违规记录
  SELECT * INTO v_violation_record
  FROM violation_records
  WHERE id = v_appeal.violation_record_id;
  
  -- 驳回申诉
  IF p_action = 'reject' THEN
    -- 更新申诉记录
    UPDATE appeals
    SET status = 'rejected',
        handler_id = v_handler_id,
        handler_note = p_handler_note,
        result = 'rejected',
        handled_at = now(),
        updated_at = now()
    WHERE id = p_appeal_id;
    
    -- 更新违规记录的申诉状态
    UPDATE violation_records
    SET appeal_status = 'appeal_rejected',
        can_appeal = false,
        updated_at = now()
    WHERE id = v_appeal.violation_record_id;
    
    RETURN jsonb_build_object(
      'success', true,
      'message', '已驳回申诉，维持原判'
    );
  END IF;
  
  -- 批准申诉
  v_credit_to_restore := v_violation_record.credit_deducted;
  
  -- 恢复信用分
  UPDATE user_credit
  SET score = LEAST(100, score + v_credit_to_restore),
      updated_at = now()
  WHERE user_id = v_violation_record.violator_id;
  
  -- 记录信用分变动
  INSERT INTO credit_logs (
    user_id,
    change_amount,
    change_type,
    reason,
    related_id,
    operator_id
  ) VALUES (
    v_violation_record.violator_id,
    v_credit_to_restore,
    'appeal_approved',
    '申诉成功，恢复信用分',
    p_appeal_id,
    v_handler_id
  );
  
  -- 重新统计该用户的有效违规次数（排除申诉成功的）
  SELECT COUNT(*) INTO v_violation_count
  FROM violation_records vr
  LEFT JOIN appeals a ON vr.id = a.violation_record_id
  WHERE vr.violator_id = v_violation_record.violator_id
    AND vr.status = 'resolved'
    AND (a.status IS NULL OR a.status != 'approved');
  
  -- 重新计算账号状态
  v_new_status := 'normal';
  
  -- 根据剩余违规次数决定账号状态
  IF v_violation_count >= 10 THEN
    v_new_status := 'banned';
  ELSIF v_violation_count >= 5 THEN
    v_new_status := 'warned';
  ELSIF v_violation_count >= 3 THEN
    v_new_status := 'warned';
  END IF;
  
  -- 更新账号状态
  UPDATE profiles
  SET account_status = v_new_status,
      suspended_until = NULL,
      ban_reason = CASE 
        WHEN v_new_status = 'banned' THEN '累计违规' || v_violation_count || '次'
        ELSE NULL
      END
  WHERE id = v_violation_record.violator_id;
  
  -- 更新申诉记录
  UPDATE appeals
  SET status = 'approved',
      handler_id = v_handler_id,
      handler_note = p_handler_note,
      result = 'approved',
      handled_at = now(),
      updated_at = now()
  WHERE id = p_appeal_id;
  
  -- 更新违规记录的申诉状态
  UPDATE violation_records
  SET appeal_status = 'appeal_approved',
      can_appeal = false,
      updated_at = now()
  WHERE id = v_appeal.violation_record_id;
  
  RETURN jsonb_build_object(
    'success', true,
    'message', '申诉成功，已恢复信用分',
    'credit_restored', v_credit_to_restore,
    'new_status', v_new_status,
    'violation_count', v_violation_count
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

COMMENT ON FUNCTION handle_appeal IS '处理申诉';

-- 创建RPC函数：获取申诉统计
CREATE OR REPLACE FUNCTION get_appeal_stats(p_user_id uuid)
RETURNS jsonb AS $$
DECLARE
  v_result jsonb;
BEGIN
  SELECT jsonb_build_object(
    'total_appeals', COUNT(*),
    'pending_appeals', COUNT(*) FILTER (WHERE status = 'pending'),
    'approved_appeals', COUNT(*) FILTER (WHERE status = 'approved'),
    'rejected_appeals', COUNT(*) FILTER (WHERE status = 'rejected'),
    'total_credit_restored', COALESCE(
      (SELECT SUM(vr.credit_deducted)
       FROM appeals a
       JOIN violation_records vr ON a.violation_record_id = vr.id
       WHERE a.appellant_id = p_user_id AND a.status = 'approved'),
      0
    )
  ) INTO v_result
  FROM appeals
  WHERE appellant_id = p_user_id;
  
  RETURN v_result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

COMMENT ON FUNCTION get_appeal_stats IS '获取用户申诉统计';
