import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { MainLayout } from '@/components/layouts/MainLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Skeleton } from '@/components/ui/skeleton';
import { useAuth } from '@/contexts/AuthContext';
import { getUserExchanges, checkExchangeRated } from '@/db/api';
import type { Exchange } from '@/types';
import { EXCHANGE_TYPE_LABELS, EXCHANGE_STATUS_LABELS } from '@/types';
import { ArrowLeft, Star } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { zhCN } from 'date-fns/locale';
import { toast } from 'sonner';

export default function ExchangeHistoryPage() {
  const { profile } = useAuth();
  const navigate = useNavigate();
  const [exchanges, setExchanges] = useState<Exchange[]>([]);
  const [loading, setLoading] = useState(true);
  const [ratedMap, setRatedMap] = useState<Record<string, boolean>>({});

  useEffect(() => {
    if (profile) {
      loadExchanges();
    }
  }, [profile]);

  const loadExchanges = async () => {
    if (!profile) return;

    try {
      setLoading(true);
      const data = await getUserExchanges(profile.id);
      setExchanges(data);

      // 检查哪些交换已评价
      const ratedStatus: Record<string, boolean> = {};
      for (const exchange of data.filter((e) => e.status === 'completed')) {
        ratedStatus[exchange.id] = await checkExchangeRated(exchange.id);
      }
      setRatedMap(ratedStatus);
    } catch (error) {
      toast.error('加载交换记录失败');
    } finally {
      setLoading(false);
    }
  };

  const handleRate = (exchangeId: string, otherUserId: string) => {
    navigate(`/rate?exchangeId=${exchangeId}&ratedId=${otherUserId}`);
  };

  if (!profile) {
    return (
      <MainLayout>
        <Card>
          <CardContent className="py-12 text-center text-muted-foreground">
            请先登录
          </CardContent>
        </Card>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div>
          <Button asChild variant="ghost" size="sm" className="gap-2 mb-2">
            <Link to="/profile">
              <ArrowLeft className="h-4 w-4" />
              返回个人中心
            </Link>
          </Button>
          <h1 className="text-3xl font-bold">交换记录</h1>
          <p className="text-muted-foreground mt-1">查看所有交换历史记录</p>
        </div>

        {/* Exchanges List */}
        {loading ? (
          <div className="space-y-4">
            {Array.from({ length: 5 }).map((_, i) => (
              <Card key={i}>
                <CardContent className="p-6">
                  <Skeleton className="h-6 w-3/4 mb-2 bg-muted" />
                  <Skeleton className="h-4 w-full bg-muted" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : exchanges.length > 0 ? (
          <div className="space-y-4">
            {exchanges.map((exchange) => {
              const isInitiator = exchange.initiator_id === profile.id;
              const otherUser = isInitiator ? exchange.receiver : exchange.initiator;
              const canRate =
                exchange.status === 'completed' && !ratedMap[exchange.id];

              return (
                <Card key={exchange.id}>
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <CardTitle className="text-lg">
                            {EXCHANGE_TYPE_LABELS[exchange.type]}
                          </CardTitle>
                          <Badge
                            variant={
                              exchange.status === 'completed'
                                ? 'default'
                                : exchange.status === 'rejected' || exchange.status === 'cancelled'
                                  ? 'destructive'
                                  : 'secondary'
                            }
                          >
                            {EXCHANGE_STATUS_LABELS[exchange.status]}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          {formatDistanceToNow(new Date(exchange.created_at), {
                            addSuffix: true,
                            locale: zhCN,
                          })}
                        </p>
                      </div>
                      {canRate && (
                        <Button
                          size="sm"
                          className="gap-2"
                          onClick={() => handleRate(exchange.id, otherUser!.id)}
                        >
                          <Star className="h-4 w-4" />
                          评价
                        </Button>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Other User Info */}
                    {otherUser && (
                      <div className="flex items-center space-x-3">
                        <Avatar>
                          <AvatarImage src={otherUser.avatar_url || undefined} />
                          <AvatarFallback>{otherUser.nickname?.[0] || '用'}</AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="text-sm font-medium">
                            {isInitiator ? '交换对象' : '发起人'}: {otherUser.nickname || '未知用户'}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            信用分 {otherUser.credit_score}
                          </p>
                        </div>
                      </div>
                    )}

                    {/* Skill Info */}
                    {exchange.receiver_skill && (
                      <div className="p-3 rounded-lg bg-muted/50">
                        <p className="text-sm font-medium mb-1">交换技能</p>
                        <p className="text-sm text-muted-foreground">
                          {exchange.receiver_skill.name}
                        </p>
                      </div>
                    )}

                    {/* Points Info */}
                    {exchange.points_amount && (
                      <div className="text-sm text-muted-foreground">
                        交换金额: <span className="font-medium">{exchange.points_amount}</span> 技易点
                      </div>
                    )}

                    {/* Note */}
                    {exchange.note && (
                      <div className="text-sm text-muted-foreground">
                        备注: {exchange.note}
                      </div>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        ) : (
          <Card>
            <CardContent className="py-12 text-center text-muted-foreground">
              还没有交换记录
            </CardContent>
          </Card>
        )}
      </div>
    </MainLayout>
  );
}
