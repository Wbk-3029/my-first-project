-- 修复get_recommended_skills函数中的字段引用错误
CREATE OR REPLACE FUNCTION get_recommended_skills(
  p_user_id uuid DEFAULT NULL,
  p_limit int DEFAULT 10
) RETURNS TABLE (
  skill_id uuid,
  skill_name text,
  skill_description text,
  skill_type text,
  skill_price numeric,
  provider_id uuid,
  provider_nickname text,
  provider_avatar text,
  provider_credit int,
  exchange_count bigint,
  match_score numeric
) AS $$
DECLARE
  v_user_profile record;
  v_user_id uuid;
BEGIN
  -- 如果未传入用户ID，使用当前登录用户
  v_user_id := COALESCE(p_user_id, auth.uid());

  -- 如果用户未登录，返回热门技能
  IF v_user_id IS NULL THEN
    RETURN QUERY
    SELECT 
      s.id AS skill_id,
      s.name AS skill_name,
      s.description AS skill_description,
      s.type::text AS skill_type,
      s.price::numeric AS skill_price,
      p.id AS provider_id,
      p.nickname AS provider_nickname,
      p.avatar_url AS provider_avatar,
      p.credit_score AS provider_credit,
      COUNT(DISTINCT e.id) AS exchange_count,
      50.0 AS match_score
    FROM skills s
    JOIN profiles p ON s.user_id = p.id
    LEFT JOIN exchanges e ON (s.id = e.initiator_skill_id OR s.id = e.receiver_skill_id) AND e.status = 'completed'
    WHERE s.status = 'active'
    GROUP BY s.id, s.name, s.description, s.type, s.price, p.id, p.nickname, p.avatar_url, p.credit_score
    ORDER BY COUNT(DISTINCT e.id) DESC, p.credit_score DESC
    LIMIT p_limit;
    RETURN;
  END IF;

  -- 获取用户信息
  SELECT * INTO v_user_profile
  FROM profiles
  WHERE id = v_user_id;

  -- 如果用户不存在，返回空
  IF v_user_profile IS NULL THEN
    RETURN;
  END IF;

  -- 推荐算法
  RETURN QUERY
  WITH user_exchanges AS (
    -- 用户历史交换的技能
    SELECT DISTINCT s.type, s.name
    FROM exchanges e
    JOIN skills s ON (e.initiator_skill_id = s.id OR e.receiver_skill_id = s.id)
    WHERE (e.initiator_id = v_user_id OR e.receiver_id = v_user_id)
      AND e.status = 'completed'
  ),
  skill_scores AS (
    SELECT 
      s.id AS skill_id,
      s.name AS skill_name,
      s.description AS skill_description,
      s.type::text AS skill_type,
      s.price::numeric AS skill_price,
      p.id AS provider_id,
      p.nickname AS provider_nickname,
      p.avatar_url AS provider_avatar,
      p.credit_score AS provider_credit,
      COUNT(DISTINCT e.id) AS exchange_count,
      -- 计算匹配分数
      (
        -- 基础分数
        50.0 +
        -- 兴趣标签匹配（最高30分）
        CASE 
          WHEN v_user_profile.interest_tags && ARRAY[s.type::text] THEN 15.0
          ELSE 0.0
        END +
        CASE 
          WHEN v_user_profile.want_to_learn && ARRAY[s.name] THEN 15.0
          ELSE 0.0
        END +
        -- 历史交换类型匹配（10分）
        CASE 
          WHEN EXISTS (SELECT 1 FROM user_exchanges ue WHERE ue.type = s.type) THEN 10.0
          ELSE 0.0
        END +
        -- 信用分加成（最高10分）
        (p.credit_score / 10.0) +
        -- 热度加成（最高10分）
        LEAST(COUNT(DISTINCT e.id)::numeric, 10.0)
      ) AS match_score
    FROM skills s
    JOIN profiles p ON s.user_id = p.id
    LEFT JOIN exchanges e ON (s.id = e.initiator_skill_id OR s.id = e.receiver_skill_id) AND e.status = 'completed'
    WHERE s.status = 'active'
      AND s.user_id != v_user_id  -- 排除自己的技能
    GROUP BY s.id, s.name, s.description, s.type, s.price, p.id, p.nickname, p.avatar_url, p.credit_score
  )
  SELECT *
  FROM skill_scores
  ORDER BY match_score DESC, exchange_count DESC, provider_credit DESC
  LIMIT p_limit;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 添加注释
COMMENT ON FUNCTION get_recommended_skills IS '获取推荐技能列表，基于用户兴趣标签、历史交换记录和技能热度';
