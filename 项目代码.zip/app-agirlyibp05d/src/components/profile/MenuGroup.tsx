import { Link } from 'react-router-dom';
import { ChevronRight, LucideIcon } from 'lucide-react';

interface MenuItem {
  label: string;
  icon: LucideIcon;
  path: string;
  badge?: string | number;
}

interface MenuGroupProps {
  title: string;
  items: MenuItem[];
}

export function MenuGroup({ title, items }: MenuGroupProps) {
  return (
    <div className="space-y-2">
      <h3 className="text-sm font-medium text-muted-foreground px-1">{title}</h3>
      <div className="bg-card rounded-2xl overflow-hidden border border-border">
        {items.map((item, index) => {
          const Icon = item.icon;
          return (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center justify-between px-4 py-4 hover:bg-muted/50 transition-colors min-h-14 ${
                index !== items.length - 1 ? 'border-b border-border' : ''
              }`}
            >
              <div className="flex items-center gap-3">
                <div className="flex items-center justify-center w-9 h-9 rounded-full bg-primary/10">
                  <Icon className="h-4 w-4 text-primary" />
                </div>
                <span className="font-medium">{item.label}</span>
              </div>
              <div className="flex items-center gap-2">
                {item.badge && (
                  <span className="text-xs px-2 py-0.5 rounded-full bg-destructive text-destructive-foreground">
                    {item.badge}
                  </span>
                )}
                <ChevronRight className="h-4 w-4 text-muted-foreground" />
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
