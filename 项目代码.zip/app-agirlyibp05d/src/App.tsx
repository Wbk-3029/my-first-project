import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import IntersectObserver from '@/components/common/IntersectObserver';
import { Toaster } from '@/components/ui/sonner';
import { Navbar } from '@/components/layouts/Navbar';
import { BottomNav } from '@/components/layouts/BottomNav';
import LoginDialog from '@/components/LoginDialog';

import routes from './routes';

import { AuthProvider } from '@/contexts/AuthContext';
import { LoginDialogProvider } from '@/contexts/LoginDialogContext';
import { RouteGuard } from '@/components/common/RouteGuard';

const App: React.FC = () => {
  return (
    <Router>
      <AuthProvider>
        <LoginDialogProvider>
          <RouteGuard>
            <IntersectObserver />
            <div className="flex flex-col min-h-screen">
              <Navbar />
              <main className="flex-grow pb-16 md:pb-0">
                <Routes>
                  {routes.map((route, index) => (
                    <Route key={index} path={route.path} element={route.element} />
                  ))}
                  <Route path="*" element={<Navigate to="/" replace />} />
                </Routes>
              </main>
              <BottomNav />
            </div>
            <LoginDialog />
            <Toaster />
          </RouteGuard>
        </LoginDialogProvider>
      </AuthProvider>
    </Router>
  );
};

export default App;
