import { supabase } from './supabase';
import type {
  Profile,
  Skill,
  SkillPriceHistory,
  Post,
  PostLike,
  PostReply,
  Exchange,
  GroupBuy,
  GroupBuyParticipant,
  Rating,
  Favorite,
  SkillType,
  ExchangeType,
  ExchangeStatus,
} from '@/types';

// ==================== Profile APIs ====================

export async function updateProfile(userId: string, updates: Partial<Profile>) {
  const { data, error } = await supabase
    .from('profiles')
    .update(updates)
    .eq('id', userId)
    .select()
    .maybeSingle();

  if (error) throw error;
  return data;
}

export async function updateAvatar(userId: string, avatarUrl: string) {
  const { data, error } = await supabase
    .from('profiles')
    .update({ avatar_url: avatarUrl })
    .eq('id', userId)
    .select()
    .maybeSingle();

  if (error) throw error;
  return data;
}

export async function getProfileById(userId: string) {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .maybeSingle();

  if (error) throw error;
  return data;
}

// ==================== Skill APIs ====================

export async function getSkills(filters?: {
  type?: SkillType;
  search?: string;
  sortBy?: 'price_asc' | 'price_desc' | 'hot';
  limit?: number;
  offset?: number;
}) {
  let query = supabase
    .from('skills')
    .select('*, profiles!skills_user_id_fkey(*)')
    .eq('status', 'active');

  if (filters?.type) {
    query = query.eq('type', filters.type);
  }

  if (filters?.search) {
    query = query.ilike('name', `%${filters.search}%`);
  }

  if (filters?.sortBy === 'price_asc') {
    query = query.order('price', { ascending: true });
  } else if (filters?.sortBy === 'price_desc') {
    query = query.order('price', { ascending: false });
  } else if (filters?.sortBy === 'hot') {
    query = query.order('exchange_count', { ascending: false });
  } else {
    query = query.order('created_at', { ascending: false });
  }

  if (filters?.limit) {
    query = query.limit(filters.limit);
  }

  if (filters?.offset) {
    query = query.range(filters.offset, filters.offset + (filters.limit || 10) - 1);
  }

  const { data, error } = await query;

  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function getSkillById(skillId: string) {
  const { data, error } = await supabase
    .from('skills')
    .select('*, profiles!skills_user_id_fkey(*)')
    .eq('id', skillId)
    .maybeSingle();

  if (error) throw error;
  return data;
}

export async function createSkill(skill: {
  name: string;
  type: SkillType;
  description: string;
  price: number;
  required_skills?: string | null;
}) {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error('未登录');

  const { data, error } = await supabase
    .from('skills')
    .insert({
      user_id: user.id,
      ...skill,
    })
    .select()
    .maybeSingle();

  if (error) throw error;

  // 发布技能奖励5技易点
  await updatePoints(user.id, 5);

  return data?.id;
}

export async function updateSkill(skillId: string, updates: Partial<Skill>) {
  const { data, error } = await supabase
    .from('skills')
    .update(updates)
    .eq('id', skillId)
    .select()
    .maybeSingle();

  if (error) throw error;
  return data;
}

export async function updateSkillMedia(skillId: string, mediaUrls: string[]) {
  const { data, error } = await supabase
    .from('skills')
    .update({ media: mediaUrls })
    .eq('id', skillId)
    .select()
    .maybeSingle();

  if (error) throw error;
  return data;
}

export async function updateSkillPrice(skillId: string, newPrice: number, reason: string) {
  const skill = await getSkillById(skillId);
  if (!skill) throw new Error('技能不存在');

  // 记录价格历史
  await supabase.from('skill_price_history').insert({
    skill_id: skillId,
    old_price: skill.price,
    new_price: newPrice,
    reason,
  });

  // 更新技能价格
  return updateSkill(skillId, { price: newPrice });
}

export async function getSkillPriceHistory(skillId: string) {
  const { data, error } = await supabase
    .from('skill_price_history')
    .select('*')
    .eq('skill_id', skillId)
    .order('created_at', { ascending: false });

  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function getUserSkills(userId: string) {
  const { data, error } = await supabase
    .from('skills')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });

  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

// ==================== Post APIs ====================

export async function getPosts(filters?: {
  type?: SkillType;
  sortBy?: 'time' | 'hot' | 'featured';
  search?: string;
  limit?: number;
  offset?: number;
}) {
  const {
    data: { user },
  } = await supabase.auth.getUser();

  let query = supabase
    .from('posts')
    .select('*, profiles!posts_user_id_fkey(*)')
    .eq('is_deleted', false);

  if (filters?.type) {
    query = query.eq('skill_type', filters.type);
  }

  if (filters?.search) {
    query = query.or(`title.ilike.%${filters.search}%,content.ilike.%${filters.search}%`);
  }

  if (filters?.sortBy === 'featured') {
    query = query.eq('is_featured', true).order('created_at', { ascending: false });
  } else if (filters?.sortBy === 'hot') {
    // 按热度排序：点赞×2 + 评论×1 + 浏览×0.5
    query = query.order('like_count', { ascending: false });
  } else {
    query = query.order('created_at', { ascending: false });
  }

  if (filters?.limit) {
    query = query.limit(filters.limit);
  }

  if (filters?.offset) {
    query = query.range(filters.offset, filters.offset + (filters.limit || 10) - 1);
  }

  const { data, error } = await query;

  if (error) throw error;

  // 如果用户已登录，获取点赞和收藏状态
  if (user && data) {
    const postIds = data.map((p) => p.id);
    
    const [likes, favorites] = await Promise.all([
      supabase.from('post_likes').select('post_id').eq('user_id', user.id).in('post_id', postIds),
      supabase.from('post_favorites').select('post_id').eq('user_id', user.id).in('post_id', postIds),
    ]);

    const likedPostIds = new Set(likes.data?.map((l) => l.post_id) || []);
    const favoritedPostIds = new Set(favorites.data?.map((f) => f.post_id) || []);

    return data.map((post) => ({
      ...post,
      user_liked: likedPostIds.has(post.id),
      user_favorited: favoritedPostIds.has(post.id),
    }));
  }

  return Array.isArray(data) ? data : [];
}

export async function getPostById(postId: string) {
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const { data, error } = await supabase
    .from('posts')
    .select('*, profiles!posts_user_id_fkey(*)')
    .eq('id', postId)
    .eq('is_deleted', false)
    .maybeSingle();

  if (error) throw error;
  if (!data) return null;

  // 增加浏览数
  await supabase.rpc('increment_post_view', { post_id: postId });

  // 如果用户已登录，获取点赞和收藏状态
  if (user) {
    const [likeResult, favoriteResult] = await Promise.all([
      supabase.from('post_likes').select('id').eq('post_id', postId).eq('user_id', user.id).maybeSingle(),
      supabase.from('post_favorites').select('id').eq('post_id', postId).eq('user_id', user.id).maybeSingle(),
    ]);

    return {
      ...data,
      user_liked: !!likeResult.data,
      user_favorited: !!favoriteResult.data,
    };
  }

  return data;
}

export async function createPost(post: {
  title: string;
  content: string;
  skill_type?: SkillType;
  exchange_need?: string;
  images?: string[];
}) {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error('未登录');

  const { data, error } = await supabase
    .from('posts')
    .insert({
      user_id: user.id,
      ...post,
    })
    .select()
    .maybeSingle();

  if (error) throw error;
  return data;
}

export async function togglePostLike(postId: string) {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error('未登录');

  // 检查是否已点赞
  const { data: existing } = await supabase
    .from('post_likes')
    .select('id')
    .eq('post_id', postId)
    .eq('user_id', user.id)
    .maybeSingle();

  if (existing) {
    // 取消点赞
    await supabase.from('post_likes').delete().eq('id', existing.id);
    await supabase.rpc('decrement_post_likes', { post_id: postId });
    return false;
  } else {
    // 添加点赞
    await supabase.from('post_likes').insert({ post_id: postId, user_id: user.id });
    await supabase.rpc('increment_post_likes', { post_id: postId });
    return true;
  }
}

export async function togglePostFavorite(postId: string) {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error('未登录');

  // 检查是否已收藏
  const { data: existing } = await supabase
    .from('post_favorites')
    .select('id')
    .eq('post_id', postId)
    .eq('user_id', user.id)
    .maybeSingle();

  if (existing) {
    // 取消收藏
    await supabase.from('post_favorites').delete().eq('id', existing.id);
    return false;
  } else {
    // 添加收藏
    await supabase.from('post_favorites').insert({ post_id: postId, user_id: user.id });
    return true;
  }
}

export async function getPostReplies(postId: string) {
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const { data, error } = await supabase
    .from('post_replies')
    .select('*, profiles!post_replies_user_id_fkey(*)')
    .eq('post_id', postId)
    .eq('is_deleted', false)
    .order('created_at', { ascending: true });

  if (error) throw error;
  
  const replies = Array.isArray(data) ? data : [];

  // 如果用户已登录，获取点赞状态
  if (user && replies.length > 0) {
    const replyIds = replies.map((r) => r.id);
    const { data: likes } = await supabase
      .from('reply_likes')
      .select('reply_id')
      .eq('user_id', user.id)
      .in('reply_id', replyIds);

    const likedReplyIds = new Set(likes?.map((l) => l.reply_id) || []);

    // 构建嵌套结构
    const repliesWithLikes = replies.map((reply) => ({
      ...reply,
      user_liked: likedReplyIds.has(reply.id),
      replies: [],
    }));

    // 构建父子关系
    const replyMap = new Map<string, any>();
    const topLevelReplies: any[] = [];

    repliesWithLikes.forEach((reply) => {
      replyMap.set(reply.id, reply);
    });

    repliesWithLikes.forEach((reply) => {
      if (reply.parent_id) {
        const parent = replyMap.get(reply.parent_id);
        if (parent) {
          parent.replies.push(reply);
        } else {
          topLevelReplies.push(reply);
        }
      } else {
        topLevelReplies.push(reply);
      }
    });

    return topLevelReplies;
  }

  // 未登录用户也构建嵌套结构
  const repliesWithStructure = replies.map((reply) => ({
    ...reply,
    user_liked: false,
    replies: [],
  }));

  const replyMap = new Map<string, any>();
  const topLevelReplies: any[] = [];

  repliesWithStructure.forEach((reply) => {
    replyMap.set(reply.id, reply);
  });

  repliesWithStructure.forEach((reply) => {
    if (reply.parent_id) {
      const parent = replyMap.get(reply.parent_id);
      if (parent) {
        parent.replies.push(reply);
      } else {
        topLevelReplies.push(reply);
      }
    } else {
      topLevelReplies.push(reply);
    }
  });

  return topLevelReplies;
}

export async function createPostReply(postId: string, content: string, parentId?: string) {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error('未登录');

  const { data, error } = await supabase
    .from('post_replies')
    .insert({
      post_id: postId,
      user_id: user.id,
      content,
      parent_id: parentId || null,
    })
    .select()
    .maybeSingle();

  if (error) throw error;

  // 更新帖子回复数
  await supabase.rpc('increment_post_reply_count', { post_id: postId });

  return data;
}

export async function toggleReplyLike(replyId: string) {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error('未登录');

  // 检查是否已点赞
  const { data: existing } = await supabase
    .from('reply_likes')
    .select('id')
    .eq('reply_id', replyId)
    .eq('user_id', user.id)
    .maybeSingle();

  if (existing) {
    // 取消点赞
    await supabase.from('reply_likes').delete().eq('id', existing.id);
    await supabase.rpc('decrement_reply_likes', { reply_id: replyId });
    return false;
  } else {
    // 添加点赞
    await supabase.from('reply_likes').insert({ reply_id: replyId, user_id: user.id });
    await supabase.rpc('increment_reply_likes', { reply_id: replyId });
    return true;
  }
}

export async function reportContent(targetType: 'post' | 'reply', targetId: string, reason: string) {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error('未登录');

  const { data, error } = await supabase
    .from('reports')
    .insert({
      reporter_id: user.id,
      target_type: targetType,
      target_id: targetId,
      reason,
    })
    .select()
    .maybeSingle();

  if (error) throw error;
  return data;
}


export async function checkPostLiked(postId: string) {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return false;

  const { data } = await supabase
    .from('post_likes')
    .select('id')
    .eq('post_id', postId)
    .eq('user_id', user.id)
    .maybeSingle();

  return !!data;
}

// ==================== Exchange APIs ====================

export async function createDirectExchange(data: {
  receiver_id: string;
  initiator_skill_id: string;
  receiver_skill_id: string;
  note?: string;
}) {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error('未登录');

  const { data: exchange, error } = await supabase
    .from('exchanges')
    .insert({
      type: 'direct',
      initiator_id: user.id,
      ...data,
    })
    .select()
    .maybeSingle();

  if (error) throw error;
  return exchange;
}

export async function createPointExchange(data: {
  receiver_id: string;
  receiver_skill_id: string;
  points_amount: number;
}) {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error('未登录');

  // 检查余额
  const profile = await getProfileById(user.id);
  if (!profile || profile.points < data.points_amount) {
    throw new Error('技易点余额不足');
  }

  // 创建交换记录
  const { data: exchange, error } = await supabase
    .from('exchanges')
    .insert({
      type: 'point',
      initiator_id: user.id,
      status: 'completed',
      ...data,
    })
    .select()
    .maybeSingle();

  if (error) throw error;

  // 扣除买方技易点
  await updatePoints(user.id, -data.points_amount);

  // 增加卖方技易点
  await updatePoints(data.receiver_id, data.points_amount);

  // 增加交换次数
  await supabase.rpc('increment_skill_exchange_count', { skill_id: data.receiver_skill_id });

  // 双方各获得完成交换奖励
  await updatePoints(user.id, 10);
  await updatePoints(data.receiver_id, 10);

  return exchange;
}

export async function updateExchangeStatus(exchangeId: string, status: ExchangeStatus) {
  const { data, error } = await supabase
    .from('exchanges')
    .update({ status, updated_at: new Date().toISOString() })
    .eq('id', exchangeId)
    .select()
    .maybeSingle();

  if (error) throw error;

  // 如果交换完成,双方各获得10技易点
  if (status === 'completed' && data) {
    await updatePoints(data.initiator_id, 10);
    await updatePoints(data.receiver_id, 10);

    // 增加技能交换次数
    if (data.receiver_skill_id) {
      await supabase.rpc('increment_skill_exchange_count', { skill_id: data.receiver_skill_id });
    }
  }

  return data;
}

export async function getExchangeById(exchangeId: string) {
  const { data, error } = await supabase
    .from('exchanges')
    .select(`
      *,
      initiator:profiles!exchanges_initiator_id_fkey(*),
      receiver:profiles!exchanges_receiver_id_fkey(*),
      initiator_skill:skills!exchanges_initiator_skill_id_fkey(*),
      receiver_skill:skills!exchanges_receiver_skill_id_fkey(*)
    `)
    .eq('id', exchangeId)
    .maybeSingle();

  if (error) throw error;
  return data;
}

export async function getUserExchanges(userId: string) {
  const { data, error } = await supabase
    .from('exchanges')
    .select(`
      *,
      initiator:profiles!exchanges_initiator_id_fkey(*),
      receiver:profiles!exchanges_receiver_id_fkey(*),
      receiver_skill:skills!exchanges_receiver_skill_id_fkey(*)
    `)
    .or(`initiator_id.eq.${userId},receiver_id.eq.${userId}`)
    .order('created_at', { ascending: false });

  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

// ==================== Group Buy APIs ====================

export async function createGroupBuy(data: {
  skill_id: string;
  original_price: number;
  group_price: number;
}) {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error('未登录');

  const expiresAt = new Date();
  expiresAt.setHours(expiresAt.getHours() + 72);

  const { data: groupBuy, error } = await supabase
    .from('group_buys')
    .insert({
      initiator_id: user.id,
      expires_at: expiresAt.toISOString(),
      ...data,
    })
    .select()
    .maybeSingle();

  if (error) throw error;

  // 发起人自动参团
  await supabase.from('group_buy_participants').insert({
    group_buy_id: groupBuy!.id,
    user_id: user.id,
  });

  return groupBuy;
}

export async function joinGroupBuy(groupBuyId: string) {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error('未登录');

  // 检查团购是否存在且有效
  const { data: groupBuy } = await supabase
    .from('group_buys')
    .select('*, skills!group_buys_skill_id_fkey(*)')
    .eq('id', groupBuyId)
    .eq('status', 'active')
    .maybeSingle();

  if (!groupBuy) throw new Error('团购不存在或已结束');

  // 检查是否已参团
  const { data: existing } = await supabase
    .from('group_buy_participants')
    .select('id')
    .eq('group_buy_id', groupBuyId)
    .eq('user_id', user.id)
    .maybeSingle();

  if (existing) throw new Error('已参加该团购');

  // 检查余额
  const profile = await getProfileById(user.id);
  if (!profile || profile.points < groupBuy.group_price) {
    throw new Error('技易点余额不足');
  }

  // 参团
  await supabase.from('group_buy_participants').insert({
    group_buy_id: groupBuyId,
    user_id: user.id,
  });

  // 更新参团人数
  const newCount = groupBuy.participant_count + 1;
  await supabase
    .from('group_buys')
    .update({ participant_count: newCount })
    .eq('id', groupBuyId);

  // 如果达到3人,团购成功
  if (newCount >= 3) {
    await completeGroupBuy(groupBuyId);
  }

  return true;
}

async function completeGroupBuy(groupBuyId: string) {
  const { data: groupBuy } = await supabase
    .from('group_buys')
    .select('*, skills!group_buys_skill_id_fkey(*)')
    .eq('id', groupBuyId)
    .maybeSingle();

  if (!groupBuy) return;

  // 获取所有参团者
  const { data: participants } = await supabase
    .from('group_buy_participants')
    .select('user_id')
    .eq('group_buy_id', groupBuyId);

  if (!participants || participants.length < 3) return;

  // 扣除所有参团者的技易点
  for (const p of participants) {
    await updatePoints(p.user_id, -groupBuy.group_price);
    // 完成交换奖励
    await updatePoints(p.user_id, 10);

    // 创建交换记录
    await supabase.from('exchanges').insert({
      type: 'group',
      initiator_id: p.user_id,
      receiver_id: groupBuy.skills!.user_id,
      receiver_skill_id: groupBuy.skill_id,
      points_amount: groupBuy.group_price,
      status: 'completed',
    });
  }

  // 增加技能发布者的技易点
  const totalEarned = groupBuy.group_price * participants.length;
  await updatePoints(groupBuy.skills!.user_id, totalEarned);

  // 增加技能交换次数
  await supabase.rpc('increment_skill_exchange_count', { skill_id: groupBuy.skill_id });

  // 更新团购状态
  await supabase
    .from('group_buys')
    .update({ status: 'completed' })
    .eq('id', groupBuyId);
}

export async function getGroupBuys(skillId?: string) {
  let query = supabase
    .from('group_buys')
    .select('*, skills!group_buys_skill_id_fkey(*, profiles!skills_user_id_fkey(*)), profiles!group_buys_initiator_id_fkey(*)')
    .eq('status', 'active')
    .order('created_at', { ascending: false });

  if (skillId) {
    query = query.eq('skill_id', skillId);
  }

  const { data, error } = await query;

  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function getGroupBuyParticipants(groupBuyId: string) {
  const { data, error } = await supabase
    .from('group_buy_participants')
    .select('*, profiles!group_buy_participants_user_id_fkey(*)')
    .eq('group_buy_id', groupBuyId)
    .order('created_at', { ascending: true });

  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

// ==================== Rating APIs ====================

export async function createRating(data: {
  exchange_id: string;
  rated_id: string;
  rating_type: 'positive' | 'negative';
  comment?: string;
}) {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error('未登录');

  const { data: rating, error } = await supabase
    .from('ratings')
    .insert({
      rater_id: user.id,
      ...data,
    })
    .select()
    .maybeSingle();

  if (error) throw error;

  // 更新被评价人的信用分
  const profile = await getProfileById(data.rated_id);
  if (profile) {
    let newScore = profile.credit_score;
    if (data.rating_type === 'positive') {
      newScore = Math.min(100, newScore + 2);
      // 好评奖励3技易点
      await updatePoints(data.rated_id, 3);
    } else {
      newScore = Math.max(0, newScore - 5);
    }
    await updateProfile(data.rated_id, { credit_score: newScore });
  }

  return rating;
}

export async function getSkillRatings(skillId: string) {
  // 获取该技能的所有交换记录
  const { data: exchanges } = await supabase
    .from('exchanges')
    .select('id')
    .eq('receiver_skill_id', skillId)
    .eq('status', 'completed');

  if (!exchanges || exchanges.length === 0) return [];

  const exchangeIds = exchanges.map(e => e.id);

  const { data, error } = await supabase
    .from('ratings')
    .select('*, rater:profiles!ratings_rater_id_fkey(*)')
    .in('exchange_id', exchangeIds)
    .order('created_at', { ascending: false });

  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function checkExchangeRated(exchangeId: string) {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return false;

  const { data } = await supabase
    .from('ratings')
    .select('id')
    .eq('exchange_id', exchangeId)
    .eq('rater_id', user.id)
    .maybeSingle();

  return !!data;
}

// ==================== Favorite APIs ====================

export async function toggleFavorite(itemType: 'skill' | 'post', itemId: string) {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error('未登录');

  // 检查是否已收藏
  const { data: existing } = await supabase
    .from('favorites')
    .select('id')
    .eq('user_id', user.id)
    .eq('item_type', itemType)
    .eq('item_id', itemId)
    .maybeSingle();

  if (existing) {
    // 取消收藏
    await supabase.from('favorites').delete().eq('id', existing.id);
    return false;
  }

  // 添加收藏
  await supabase.from('favorites').insert({
    user_id: user.id,
    item_type: itemType,
    item_id: itemId,
  });
  return true;
}

export async function checkFavorited(itemType: 'skill' | 'post', itemId: string) {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return false;

  const { data } = await supabase
    .from('favorites')
    .select('id')
    .eq('user_id', user.id)
    .eq('item_type', itemType)
    .eq('item_id', itemId)
    .maybeSingle();

  return !!data;
}

export async function getUserFavorites(userId: string) {
  const { data, error } = await supabase
    .from('favorites')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });

  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

// ==================== Helper Functions ====================

export async function updatePoints(userId: string, amount: number, type?: string, description?: string) {
  const profile = await getProfileById(userId);
  if (!profile) return;

  const newPoints = Math.max(0, profile.points + amount);
  await updateProfile(userId, { points: newPoints });

  // 记录积分变动
  if (type) {
    await supabase.from('point_records').insert({
      user_id: userId,
      amount,
      type,
      description: description || null,
    });
  }
}

// ==================== Chat Functions ====================

export async function getOrCreateConversation(otherUserId: string, exchangeId?: string) {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error('未登录');

  // 查找现有对话
  const { data: existing } = await supabase
    .from('conversations')
    .select('*')
    .or(`and(user1_id.eq.${user.id},user2_id.eq.${otherUserId}),and(user1_id.eq.${otherUserId},user2_id.eq.${user.id})`)
    .maybeSingle();

  if (existing) return existing;

  // 创建新对话
  const { data, error } = await supabase
    .from('conversations')
    .insert({
      user1_id: user.id,
      user2_id: otherUserId,
      exchange_id: exchangeId || null,
    })
    .select()
    .maybeSingle();

  if (error) throw error;
  return data;
}

export async function getConversationMessages(conversationId: string) {
  const { data, error } = await supabase
    .from('messages')
    .select('*, sender:profiles!messages_sender_id_fkey(*)')
    .eq('conversation_id', conversationId)
    .order('created_at', { ascending: true });

  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function sendMessage(conversationId: string, content: string) {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error('未登录');

  const { data, error } = await supabase
    .from('messages')
    .insert({
      conversation_id: conversationId,
      sender_id: user.id,
      content,
    })
    .select()
    .maybeSingle();

  if (error) throw error;

  // 更新对话的最后消息时间
  await supabase
    .from('conversations')
    .update({ last_message_at: new Date().toISOString() })
    .eq('id', conversationId);

  return data;
}

export async function getUserConversations() {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error('未登录');

  const { data, error } = await supabase
    .from('conversations')
    .select(
      `
      *,
      user1:profiles!conversations_user1_id_fkey(*),
      user2:profiles!conversations_user2_id_fkey(*)
    `
    )
    .or(`user1_id.eq.${user.id},user2_id.eq.${user.id}`)
    .order('last_message_at', { ascending: false });

  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function markMessagesAsRead(conversationId: string) {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error('未登录');

  await supabase
    .from('messages')
    .update({ is_read: true })
    .eq('conversation_id', conversationId)
    .neq('sender_id', user.id)
    .eq('is_read', false);
}

// ==================== Point & Credit Records ====================

export async function getPointRecords(userId: string) {
  const { data, error } = await supabase
    .from('point_records')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });

  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function getCreditRecords(userId: string) {
  const { data, error } = await supabase
    .from('credit_records')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });

  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

// ==================== Hot Videos & Recommendations ====================

export async function getHotVideos(limit = 8) {
  const { data, error } = await supabase
    .from('hot_videos')
    .select('*, profiles(*)')
    .order('view_count', { ascending: false })
    .order('like_count', { ascending: false })
    .limit(limit);

  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function getRecommendations(limit = 3) {
  const { data, error } = await supabase
    .from('recommendations')
    .select('*')
    .order('is_paid', { ascending: false })
    .order('sort_weight', { ascending: false })
    .limit(limit);

  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function incrementVideoView(videoId: string) {
  const { error } = await supabase.rpc('increment_video_view', { video_id: videoId });
  if (error) console.error('增加视频观看数失败:', error);
}

// ==================== Friend System ====================

export async function sendFriendRequest(friendId: string, message?: string) {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error('未登录');

  // 检查是否已经是好友或已发送申请
  const { data: existing } = await supabase
    .from('friend_relations')
    .select('*')
    .or(`and(user_id.eq.${user.id},friend_id.eq.${friendId}),and(user_id.eq.${friendId},friend_id.eq.${user.id})`)
    .maybeSingle();

  if (existing) {
    if (existing.status === 1) {
      throw new Error('已经是好友');
    } else if (existing.status === 0) {
      throw new Error('已发送好友申请，请等待对方回应');
    }
  }

  // 创建好友申请
  const { data: relation, error: relationError } = await supabase
    .from('friend_relations')
    .insert({
      user_id: user.id,
      friend_id: friendId,
      status: 0,
      message: message || '我想和你成为好友',
    })
    .select()
    .maybeSingle();

  if (relationError) throw relationError;

  // 创建通知
  const { data: profile } = await supabase
    .from('profiles')
    .select('nickname')
    .eq('id', user.id)
    .maybeSingle();

  await supabase.from('notifications').insert({
    user_id: friendId,
    type: 'friend_request',
    title: '新的好友申请',
    content: `${profile?.nickname || '用户'} 想要添加你为好友`,
    related_id: relation?.id,
  });

  return relation;
}

export async function respondFriendRequest(relationId: string, accept: boolean) {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error('未登录');

  const { data: relation } = await supabase
    .from('friend_relations')
    .select('*')
    .eq('id', relationId)
    .eq('friend_id', user.id)
    .maybeSingle();

  if (!relation) throw new Error('好友申请不存在');

  if (accept) {
    // 同意好友申请
    await supabase
      .from('friend_relations')
      .update({ status: 1, agreed_at: new Date().toISOString() })
      .eq('id', relationId);

    // 通知申请人
    const { data: profile } = await supabase
      .from('profiles')
      .select('nickname')
      .eq('id', user.id)
      .maybeSingle();

    await supabase.from('notifications').insert({
      user_id: relation.user_id,
      type: 'system',
      title: '好友申请已通过',
      content: `${profile?.nickname || '用户'} 同意了你的好友申请`,
    });
  } else {
    // 拒绝好友申请
    await supabase.from('friend_relations').update({ status: 2 }).eq('id', relationId);
  }
}

export async function getFriendRequests() {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error('未登录');

  const { data, error } = await supabase
    .from('friend_relations')
    .select('*, user_profile:profiles!friend_relations_user_id_fkey(*)')
    .eq('friend_id', user.id)
    .eq('status', 0)
    .order('created_at', { ascending: false });

  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function getFriends() {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error('未登录');

  const { data, error } = await supabase.rpc('get_friends', { p_user_id: user.id });

  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function deleteFriend(friendId: string) {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error('未登录');

  await supabase
    .from('friend_relations')
    .delete()
    .or(`and(user_id.eq.${user.id},friend_id.eq.${friendId}),and(user_id.eq.${friendId},friend_id.eq.${user.id})`);
}

export async function checkFriendStatus(friendId: string): Promise<'none' | 'pending' | 'friend'> {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return 'none';

  const { data } = await supabase
    .from('friend_relations')
    .select('status')
    .or(`and(user_id.eq.${user.id},friend_id.eq.${friendId}),and(user_id.eq.${friendId},friend_id.eq.${user.id})`)
    .maybeSingle();

  if (!data) return 'none';
  if (data.status === 1) return 'friend';
  if (data.status === 0) return 'pending';
  return 'none';
}

// ==================== Notifications ====================

export async function getNotifications(limit = 20) {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error('未登录');

  const { data, error } = await supabase
    .from('notifications')
    .select('*')
    .eq('user_id', user.id)
    .order('created_at', { ascending: false })
    .limit(limit);

  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function getUnreadNotificationCount() {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return 0;

  const { data, error } = await supabase.rpc('get_unread_notification_count');

  if (error) {
    console.error('获取未读通知数失败:', error);
    return 0;
  }
  return data || 0;
}

export async function markNotificationAsRead(notificationId: string) {
  await supabase.from('notifications').update({ is_read: true }).eq('id', notificationId);
}

export async function markAllNotificationsAsRead() {
  const { data, error } = await supabase.rpc('mark_all_notifications_as_read');
  
  if (error) throw error;
  return {
    success: data.success,
    count: data.count,
    message: data.message,
  };
}

// ==================== Sign In APIs ====================

export interface SignInInfo {
  already_signed: boolean;
  continuous_days: number;
  total_days: number;
}

export interface SignInResult {
  success: boolean;
  message: string;
  continuous_days: number;
  integral_earned?: number;
}

export async function getSignInInfo(): Promise<SignInInfo> {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error('未登录');

  const { data, error } = await supabase.rpc('get_sign_in_info', {
    p_user_id: user.id,
  });

  if (error) throw error;
  return data as SignInInfo;
}

export async function dailySignIn(): Promise<SignInResult> {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error('未登录');

  const { data, error } = await supabase.rpc('daily_sign_in', {
    p_user_id: user.id,
  });

  if (error) throw error;
  return data as SignInResult;
}

// ==================== Integral APIs ====================

export interface IntegralTransaction {
  id: string;
  user_id: string;
  type: 'income' | 'expense';
  amount: number;
  balance: number;
  reason: string;
  related_id: string | null;
  expire_date: string | null;
  created_at: string;
}

export interface IntegralAccount {
  balance: number;
  total_earned: number;
  total_spent: number;
}

export async function getIntegralAccount(): Promise<IntegralAccount | null> {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error('未登录');

  const { data, error } = await supabase
    .from('user_integral')
    .select('balance, total_earned, total_spent')
    .eq('user_id', user.id)
    .maybeSingle();

  if (error) throw error;
  return data;
}

export async function getIntegralTransactions(
  page: number = 1,
  pageSize: number = 20,
  type?: 'income' | 'expense'
): Promise<IntegralTransaction[]> {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error('未登录');

  let query = supabase
    .from('integral_transactions')
    .select('*')
    .eq('user_id', user.id)
    .order('created_at', { ascending: false })
    .range((page - 1) * pageSize, page * pageSize - 1);

  if (type) {
    query = query.eq('type', type);
  }

  const { data, error } = await query;

  if (error) throw error;
  return (data || []) as IntegralTransaction[];
}

// ==================== Credit APIs ====================

export interface CreditLog {
  id: string;
  user_id: string;
  change_amount: number;
  new_score: number;
  reason: string;
  related_id: string | null;
  created_at: string;
}

export interface CreditInfo {
  score: number;
  level: string;
  completed_exchanges: number;
  total_exchanges: number;
  total_rating: number;
  rating_count: number;
  timely_count: number;
  activity_score: number;
}

export async function getCreditInfo(): Promise<CreditInfo | null> {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error('未登录');

  const { data, error } = await supabase
    .from('user_credit')
    .select('*')
    .eq('user_id', user.id)
    .maybeSingle();

  if (error) throw error;
  return data;
}

export async function getCreditLogs(page: number = 1, pageSize: number = 20): Promise<CreditLog[]> {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error('未登录');

  const { data, error } = await supabase
    .from('credit_logs')
    .select('*')
    .eq('user_id', user.id)
    .order('created_at', { ascending: false })
    .range((page - 1) * pageSize, page * pageSize - 1);

  if (error) throw error;
  return (data || []) as CreditLog[];
}

// ==================== Fixed Deposit APIs ====================

export interface FixedDeposit {
  id: string;
  user_id: string;
  amount: number;
  period_days: number;
  interest_rate: number;
  start_date: string;
  end_date: string;
  status: 'active' | 'completed' | 'cancelled';
  created_at: string;
}

export async function createFixedDeposit(amount: number, periodDays: 7 | 30): Promise<FixedDeposit> {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error('未登录');

  // 检查余额
  const { data: account } = await supabase
    .from('user_integral')
    .select('balance, frozen_amount')
    .eq('user_id', user.id)
    .maybeSingle();

  if (!account || account.balance < amount) {
    throw new Error('余额不足');
  }

  // 计算利率和到期日期
  const interestRate = periodDays === 7 ? 0.003 : 0.005;
  const startDate = new Date();
  const endDate = new Date(startDate);
  endDate.setDate(endDate.getDate() + periodDays);

  // 扣除余额
  const { error: updateError } = await supabase.rpc('deduct_integral', {
    p_user_id: user.id,
    p_amount: amount,
    p_reason: `定期存款（${periodDays}天）`,
  });

  if (updateError) throw updateError;

  // 增加冻结金额
  const { error: frozenError } = await supabase
    .from('user_integral')
    .update({
      frozen_amount: account.frozen_amount ? account.frozen_amount + amount : amount,
    })
    .eq('user_id', user.id);

  if (frozenError) throw frozenError;

  // 创建定期存款记录
  const { data, error } = await supabase
    .from('fixed_deposits')
    .insert({
      user_id: user.id,
      amount,
      period_days: periodDays,
      interest_rate: interestRate,
      start_date: startDate.toISOString(),
      end_date: endDate.toISOString(),
      status: 'active',
    })
    .select()
    .single();

  if (error) throw error;
  return data as FixedDeposit;
}

export async function getFixedDeposits(status?: 'active' | 'completed'): Promise<FixedDeposit[]> {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error('未登录');

  let query = supabase
    .from('fixed_deposits')
    .select('*')
    .eq('user_id', user.id)
    .order('created_at', { ascending: false });

  if (status) {
    query = query.eq('status', status);
  }

  const { data, error } = await query;

  if (error) throw error;
  return (data || []) as FixedDeposit[];
}

// ==================== Exchange Request APIs ====================

export interface ExchangeRequest {
  id: string;
  from_user_id: string;
  to_user_id: string;
  skill_id: string;
  mode: 'direct' | 'integral' | 'group';
  duration: number;
  start_time: string;
  end_time: string;
  message: string | null;
  status: 'pending' | 'accepted' | 'rejected' | 'cancelled';
  points_amount: number | null;
  created_at: string;
  updated_at: string;
  from_user?: Profile;
  to_user?: Profile;
  skill?: Skill;
}

/**
 * 创建交换申请
 */
export async function createExchangeRequest(params: {
  toUserId: string;
  skillId: string;
  mode: 'direct' | 'integral' | 'group';
  duration: number;
  startTime: string;
  message?: string;
}): Promise<{ success: boolean; requestId: string; message: string }> {
  const { data, error } = await supabase.rpc('create_exchange_request', {
    p_to_user_id: params.toUserId,
    p_skill_id: params.skillId,
    p_mode: params.mode,
    p_duration: params.duration,
    p_start_time: params.startTime,
    p_message: params.message || null,
  });

  if (error) throw error;
  return {
    success: data.success,
    requestId: data.request_id,
    message: data.message,
  };
}

/**
 * 获取我发起的交换申请
 */
export async function getMyExchangeRequests(
  status?: 'pending' | 'accepted' | 'rejected' | 'cancelled'
): Promise<ExchangeRequest[]> {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error('未登录');

  let query = supabase
    .from('exchange_requests')
    .select(
      `
      *,
      from_user:profiles!exchange_requests_from_user_id_fkey(*),
      to_user:profiles!exchange_requests_to_user_id_fkey(*),
      skill:skills(*)
    `
    )
    .eq('from_user_id', user.id)
    .order('created_at', { ascending: false });

  if (status) {
    query = query.eq('status', status);
  }

  const { data, error } = await query;

  if (error) throw error;
  return (data || []) as ExchangeRequest[];
}

/**
 * 获取我收到的交换申请
 */
export async function getReceivedExchangeRequests(
  status?: 'pending' | 'accepted' | 'rejected' | 'cancelled'
): Promise<ExchangeRequest[]> {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error('未登录');

  let query = supabase
    .from('exchange_requests')
    .select(
      `
      *,
      from_user:profiles!exchange_requests_from_user_id_fkey(*),
      to_user:profiles!exchange_requests_to_user_id_fkey(*),
      skill:skills(*)
    `
    )
    .eq('to_user_id', user.id)
    .order('created_at', { ascending: false });

  if (status) {
    query = query.eq('status', status);
  }

  const { data, error } = await query;

  if (error) throw error;
  return (data || []) as ExchangeRequest[];
}

/**
 * 获取交换申请详情
 */
export async function getExchangeRequestById(
  requestId: string
): Promise<ExchangeRequest | null> {
  const { data, error } = await supabase
    .from('exchange_requests')
    .select(
      `
      *,
      from_user:profiles!exchange_requests_from_user_id_fkey(*),
      to_user:profiles!exchange_requests_to_user_id_fkey(*),
      skill:skills(*)
    `
    )
    .eq('id', requestId)
    .maybeSingle();

  if (error) throw error;
  return data as ExchangeRequest | null;
}

/**
 * 处理交换申请（同意/拒绝）
 */
export async function handleExchangeRequest(
  requestId: string,
  action: 'accept' | 'reject'
): Promise<{ success: boolean; exchangeId?: string; message: string }> {
  const { data, error } = await supabase.rpc('handle_exchange_request', {
    p_request_id: requestId,
    p_action: action,
  });

  if (error) throw error;
  return {
    success: data.success,
    exchangeId: data.exchange_id,
    message: data.message,
  };
}

/**
 * 取消交换申请
 */
export async function cancelExchangeRequest(
  requestId: string
): Promise<{ success: boolean; message: string }> {
  const { data, error } = await supabase.rpc('cancel_exchange_request', {
    p_request_id: requestId,
  });

  if (error) throw error;
  return {
    success: data.success,
    message: data.message,
  };
}

/**
 * 获取待处理的交换申请数量
 */
export async function getPendingExchangeRequestsCount(): Promise<number> {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return 0;

  const { count, error } = await supabase
    .from('exchange_requests')
    .select('*', { count: 'exact', head: true })
    .eq('to_user_id', user.id)
    .eq('status', 'pending');

  if (error) throw error;
  return count || 0;
}

// ==================== Exchange Tracking APIs ====================

export interface ExchangeWithDetails extends Exchange {
  initiator?: Profile;
  receiver?: Profile;
  initiator_skill?: Skill;
  receiver_skill?: Skill;
  request?: ExchangeRequest;
}

/**
 * 获取我的交换列表（按状态）
 */
export async function getMyExchanges(
  status?: 'pending' | 'in_progress' | 'completed'
): Promise<ExchangeWithDetails[]> {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error('未登录');

  let query = supabase
    .from('exchanges')
    .select(
      `
      *,
      initiator:profiles!exchanges_initiator_id_fkey(*),
      receiver:profiles!exchanges_receiver_id_fkey(*),
      initiator_skill:skills!exchanges_initiator_skill_id_fkey(*),
      receiver_skill:skills!exchanges_receiver_skill_id_fkey(*)
    `
    )
    .or(`initiator_id.eq.${user.id},receiver_id.eq.${user.id}`)
    .order('created_at', { ascending: false });

  if (status) {
    query = query.eq('status', status);
  }

  const { data, error } = await query;

  if (error) throw error;
  return (data || []) as ExchangeWithDetails[];
}

/**
 * 获取交换详情
 */
export async function getExchangeDetail(
  exchangeId: string
): Promise<ExchangeWithDetails | null> {
  const { data, error } = await supabase
    .from('exchanges')
    .select(
      `
      *,
      initiator:profiles!exchanges_initiator_id_fkey(*),
      receiver:profiles!exchanges_receiver_id_fkey(*),
      initiator_skill:skills!exchanges_initiator_skill_id_fkey(*),
      receiver_skill:skills!exchanges_receiver_skill_id_fkey(*)
    `
    )
    .eq('id', exchangeId)
    .maybeSingle();

  if (error) throw error;
  return data as ExchangeWithDetails | null;
}

/**
 * 完成交换
 */
export async function completeExchange(
  exchangeId: string
): Promise<{ success: boolean; message: string }> {
  const { data, error } = await supabase.rpc('complete_exchange', {
    p_exchange_id: exchangeId,
  });

  if (error) throw error;
  return {
    success: data.success,
    message: data.message,
  };
}

/**
 * 获取交换统计
 */
export async function getExchangeStats(): Promise<{
  pending: number;
  in_progress: number;
  completed: number;
}> {
  const { data, error } = await supabase.rpc('get_exchange_stats');

  if (error) throw error;
  return {
    pending: data.pending || 0,
    in_progress: data.in_progress || 0,
    completed: data.completed || 0,
  };
}

// ==================== Rating System APIs ====================

export interface RatingSubmission {
  exchangeId: string;
  ratedId: string;
  skillRating: number;
  attitudeRating: number;
  punctualityRating: number;
  comment?: string;
}

export interface PendingRatingExchange {
  exchange_id: string;
  other_user_id: string;
  other_user_nickname: string;
  other_user_avatar: string;
  skill_name: string;
  completed_at: string;
  hours_since_completion: number;
}

export interface CreditScoreChange {
  id: string;
  user_id: string;
  change_amount: number;
  reason: string;
  related_id: string | null;
  old_score: number;
  new_score: number;
  created_at: string;
}

/**
 * 提交评价
 */
export async function submitRating(
  params: RatingSubmission
): Promise<{
  success: boolean;
  ratingId: string;
  creditChange: number;
  newCredit: number;
  message: string;
}> {
  const { data, error } = await supabase.rpc('submit_rating', {
    p_exchange_id: params.exchangeId,
    p_rated_id: params.ratedId,
    p_skill_rating: params.skillRating,
    p_attitude_rating: params.attitudeRating,
    p_punctuality_rating: params.punctualityRating,
    p_comment: params.comment || null,
  });

  if (error) throw error;
  return {
    success: data.success,
    ratingId: data.rating_id,
    creditChange: data.credit_change,
    newCredit: data.new_credit,
    message: data.message,
  };
}

/**
 * 检查待评价数量
 */
export async function checkPendingRatings(): Promise<number> {
  const { data, error } = await supabase.rpc('check_pending_ratings');

  if (error) throw error;
  return data.pending_count || 0;
}

/**
 * 获取待评价的交换列表
 */
export async function getPendingRatingExchanges(): Promise<PendingRatingExchange[]> {
  const { data, error } = await supabase.rpc('get_pending_rating_exchanges');

  if (error) throw error;
  return (data || []) as PendingRatingExchange[];
}

/**
 * 获取信用分变化记录
 */
export async function getCreditScoreChanges(
  userId?: string
): Promise<CreditScoreChange[]> {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error('未登录');

  const targetUserId = userId || user.id;

  const { data, error } = await supabase
    .from('credit_score_changes')
    .select('*')
    .eq('user_id', targetUserId)
    .order('created_at', { ascending: false })
    .limit(50);

  if (error) throw error;
  return (data || []) as CreditScoreChange[];
}

// ==================== Time Management APIs ====================

export interface RescheduleRequest {
  id: string;
  exchange_id: string;
  requester_id: string;
  old_start_time: string;
  new_start_time: string;
  reason: string;
  status: 'pending' | 'approved' | 'rejected';
  created_at: string;
  updated_at: string;
}

export interface BreachReport {
  id: string;
  exchange_id: string;
  reporter_id: string;
  reported_id: string;
  evidence: string;
  status: 'pending' | 'processing' | 'resolved' | 'rejected';
  resolution: string | null;
  created_at: string;
  updated_at: string;
}

/**
 * 检查时间冲突
 */
export async function checkTimeConflict(
  userId: string,
  startTime: string,
  duration: number
): Promise<{ hasConflict: boolean; conflictCount: number }> {
  const { data, error } = await supabase.rpc('check_time_conflict', {
    p_user_id: userId,
    p_start_time: startTime,
    p_duration: duration,
  });

  if (error) throw error;
  return {
    hasConflict: data.has_conflict,
    conflictCount: data.conflict_count,
  };
}

/**
 * 创建改期申请
 */
export async function createRescheduleRequest(params: {
  exchangeId: string;
  newStartTime: string;
  reason: string;
}): Promise<{ success: boolean; requestId: string; message: string }> {
  const { data, error } = await supabase.rpc('create_reschedule_request', {
    p_exchange_id: params.exchangeId,
    p_new_start_time: params.newStartTime,
    p_reason: params.reason,
  });

  if (error) throw error;
  return {
    success: data.success,
    requestId: data.request_id,
    message: data.message,
  };
}

/**
 * 处理改期申请
 */
export async function handleRescheduleRequest(
  requestId: string,
  action: 'approve' | 'reject'
): Promise<{ success: boolean; message: string }> {
  const { data, error } = await supabase.rpc('handle_reschedule_request', {
    p_request_id: requestId,
    p_action: action,
  });

  if (error) throw error;
  return {
    success: data.success,
    message: data.message,
  };
}

/**
 * 获取改期申请列表
 */
export async function getRescheduleRequests(
  exchangeId: string
): Promise<RescheduleRequest[]> {
  const { data, error } = await supabase
    .from('reschedule_requests')
    .select('*')
    .eq('exchange_id', exchangeId)
    .order('created_at', { ascending: false });

  if (error) throw error;
  return (data || []) as RescheduleRequest[];
}

/**
 * 创建未履约举报
 */
export async function createBreachReport(params: {
  exchangeId: string;
  reportedId: string;
  evidence: string;
}): Promise<{ success: boolean; reportId: string; message: string }> {
  const { data, error } = await supabase.rpc('create_breach_report', {
    p_exchange_id: params.exchangeId,
    p_reported_id: params.reportedId,
    p_evidence: params.evidence,
  });

  if (error) throw error;
  return {
    success: data.success,
    reportId: data.report_id,
    message: data.message,
  };
}

/**
 * 获取举报列表
 */
export async function getBreachReports(
  exchangeId: string
): Promise<BreachReport[]> {
  const { data, error } = await supabase
    .from('breach_reports')
    .select('*')
    .eq('exchange_id', exchangeId)
    .order('created_at', { ascending: false });

  if (error) throw error;
  return (data || []) as BreachReport[];
}

// ==================== Skill Recommendation APIs ====================

export interface RecommendedSkill {
  skill_id: string;
  skill_name: string;
  skill_description: string;
  skill_type: string;
  skill_price: number;
  provider_id: string;
  provider_nickname: string;
  provider_avatar: string | null;
  provider_credit: number;
  exchange_count: number;
  match_score: number;
}

/**
 * 获取推荐技能
 */
export async function getRecommendedSkills(
  userId?: string,
  limit: number = 10
): Promise<RecommendedSkill[]> {
  const { data, error } = await supabase.rpc('get_recommended_skills', {
    p_user_id: userId || null,
    p_limit: limit,
  });

  if (error) throw error;
  return (data || []) as RecommendedSkill[];
}

/**
 * 更新用户兴趣标签
 */
export async function updateUserInterests(params: {
  interestTags: string[];
  wantToLearn: string[];
  canTeach: string[];
}): Promise<{ success: boolean; message: string }> {
  const { data, error } = await supabase.rpc('update_user_interests', {
    p_interest_tags: params.interestTags,
    p_want_to_learn: params.wantToLearn,
    p_can_teach: params.canTeach,
  });

  if (error) throw error;
  return {
    success: data.success,
    message: data.message,
  };
}

// ==================== Exchange Template APIs ====================

export async function getExchangeTemplates(
  category?: string,
  includeSystem = true,
  includeUser = true
) {
  const { data, error } = await supabase.rpc('get_exchange_templates', {
    p_category: category || null,
    p_include_system: includeSystem,
    p_include_user: includeUser,
  });

  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

export async function createExchangeTemplate(
  title: string,
  content: string,
  category: string = 'custom'
) {
  const { data, error } = await supabase.rpc('create_exchange_template', {
    p_title: title,
    p_content: content,
    p_category: category,
  });

  if (error) throw error;
  return {
    success: data.success,
    templateId: data.template_id,
    message: data.message,
  };
}

export async function updateExchangeTemplate(
  templateId: string,
  title: string,
  content: string,
  category?: string
) {
  const { data, error } = await supabase.rpc('update_exchange_template', {
    p_template_id: templateId,
    p_title: title,
    p_content: content,
    p_category: category || null,
  });

  if (error) throw error;
  return {
    success: data.success,
    message: data.message,
  };
}

export async function deleteExchangeTemplate(templateId: string) {
  const { data, error } = await supabase.rpc('delete_exchange_template', {
    p_template_id: templateId,
  });

  if (error) throw error;
  return {
    success: data.success,
    message: data.message,
  };
}

export async function incrementTemplateUsage(templateId: string) {
  const { error } = await supabase.rpc('increment_template_usage', {
    p_template_id: templateId,
  });

  if (error) {
    console.error('增加模板使用次数失败:', error);
  }
}

// ==================== Violation System APIs ====================

/**
 * 举报违规行为
 */
export async function reportViolation(params: {
  violatorId: string;
  type: string;
  description: string;
  evidence?: string[];
  relatedId?: string;
  relatedType?: string;
}): Promise<{ success: boolean; message: string; recordId?: string }> {
  const { data, error } = await supabase.rpc('report_violation', {
    p_violator_id: params.violatorId,
    p_type: params.type,
    p_description: params.description,
    p_evidence: params.evidence || [],
    p_related_id: params.relatedId || null,
    p_related_type: params.relatedType || null,
  });

  if (error) throw error;
  return {
    success: data.success,
    message: data.message,
    recordId: data.record_id,
  };
}

/**
 * 获取违规记录列表
 */
export async function getViolationRecords(params?: {
  violatorId?: string;
  reporterId?: string;
  status?: string;
  type?: string;
  limit?: number;
  offset?: number;
}) {
  let query = supabase
    .from('violation_records')
    .select('*, violator:profiles!violation_records_violator_id_fkey(*), reporter:profiles!violation_records_reporter_id_fkey(*), handler:profiles!violation_records_handler_id_fkey(*)')
    .order('created_at', { ascending: false });

  if (params?.violatorId) {
    query = query.eq('violator_id', params.violatorId);
  }

  if (params?.reporterId) {
    query = query.eq('reporter_id', params.reporterId);
  }

  if (params?.status) {
    query = query.eq('status', params.status);
  }

  if (params?.type) {
    query = query.eq('type', params.type);
  }

  if (params?.limit) {
    query = query.limit(params.limit);
  }

  if (params?.offset) {
    query = query.range(params.offset, params.offset + (params.limit || 20) - 1);
  }

  const { data, error } = await query;

  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

/**
 * 获取违规统计
 */
export async function getViolationStats(userId: string) {
  const { data, error } = await supabase.rpc('get_violation_stats', {
    p_user_id: userId,
  });

  if (error) throw error;
  return data;
}

/**
 * 处理违规记录（管理员功能）
 */
export async function handleViolation(params: {
  recordId: string;
  action: 'approve' | 'reject';
  handlerNote?: string;
}): Promise<{
  success: boolean;
  message: string;
  creditDeducted?: number;
  newStatus?: string;
  violationCount?: number;
}> {
  const { data, error } = await supabase.rpc('handle_violation', {
    p_record_id: params.recordId,
    p_action: params.action,
    p_handler_note: params.handlerNote || null,
  });

  if (error) throw error;
  return {
    success: data.success,
    message: data.message,
    creditDeducted: data.credit_deducted,
    newStatus: data.new_status,
    violationCount: data.violation_count,
  };
}

// ==================== Appeal System APIs ====================

/**
 * 提交申诉
 */
export async function submitAppeal(params: {
  violationRecordId: string;
  reason: string;
  evidence?: string[];
}): Promise<{ success: boolean; message: string; appealId?: string }> {
  const { data, error } = await supabase.rpc('submit_appeal', {
    p_violation_record_id: params.violationRecordId,
    p_reason: params.reason,
    p_evidence: params.evidence || [],
  });

  if (error) throw error;
  return {
    success: data.success,
    message: data.message,
    appealId: data.appeal_id,
  };
}

/**
 * 获取申诉记录列表
 */
export async function getAppeals(params?: {
  appellantId?: string;
  status?: string;
  limit?: number;
  offset?: number;
}) {
  let query = supabase
    .from('appeals')
    .select('*, appellant:profiles!appeals_appellant_id_fkey(*), handler:profiles!appeals_handler_id_fkey(*), violation_record:violation_records(*)')
    .order('created_at', { ascending: false });

  if (params?.appellantId) {
    query = query.eq('appellant_id', params.appellantId);
  }

  if (params?.status) {
    query = query.eq('status', params.status);
  }

  if (params?.limit) {
    query = query.limit(params.limit);
  }

  if (params?.offset) {
    query = query.range(params.offset, params.offset + (params.limit || 20) - 1);
  }

  const { data, error } = await query;

  if (error) throw error;
  return Array.isArray(data) ? data : [];
}

/**
 * 获取申诉统计
 */
export async function getAppealStats(userId: string) {
  const { data, error } = await supabase.rpc('get_appeal_stats', {
    p_user_id: userId,
  });

  if (error) throw error;
  return data;
}

/**
 * 处理申诉（管理员功能）
 */
export async function handleAppealRequest(params: {
  appealId: string;
  action: 'approve' | 'reject';
  handlerNote?: string;
}): Promise<{
  success: boolean;
  message: string;
  creditRestored?: number;
  newStatus?: string;
  violationCount?: number;
}> {
  const { data, error } = await supabase.rpc('handle_appeal', {
    p_appeal_id: params.appealId,
    p_action: params.action,
    p_handler_note: params.handlerNote || null,
  });

  if (error) throw error;
  return {
    success: data.success,
    message: data.message,
    creditRestored: data.credit_restored,
    newStatus: data.new_status,
    violationCount: data.violation_count,
  };
}
