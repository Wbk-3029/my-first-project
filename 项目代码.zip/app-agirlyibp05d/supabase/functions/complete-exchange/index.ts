import { createClient } from 'jsr:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface ExchangeCompletionRequest {
  exchange_id: string;
  teacher_id: string;
  student_id: string;
  skill_id: string;
  duration_hours: number;
  teacher_rating: number;
  student_rating: number;
  is_timely: boolean;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get('Authorization')!;
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      { global: { headers: { Authorization: authHeader } } }
    );

    const serviceClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const data = await req.json() as ExchangeCompletionRequest;

    // 1. 获取技能信息
    const { data: skill } = await supabaseClient
      .from('skills')
      .select('price, type')
      .eq('id', data.skill_id)
      .single();

    if (!skill) {
      throw new Error('技能不存在');
    }

    // 2. 获取技能系数（默认1.0）
    const { data: coefficient } = await supabaseClient
      .from('skill_coefficients')
      .select('coefficient')
      .eq('skill_id', data.skill_id)
      .single();

    const skillCoefficient = coefficient?.coefficient || 1.0;

    // 3. 获取教师信用等级
    const { data: teacherCredit } = await serviceClient
      .from('user_credit')
      .select('level')
      .eq('user_id', data.teacher_id)
      .single();

    const creditLevel = teacherCredit?.level || 'trusted';

    // 4. 计算信用系数
    const creditCoeffMap: Record<string, number> = {
      'newbie': 0.9,
      'trusted': 1.0,
      'excellent': 1.1,
      'master': 1.2
    };
    const creditCoeff = creditCoeffMap[creditLevel] || 1.0;

    // 5. 检查连续学习奖励
    const { data: streak } = await serviceClient
      .from('learning_streaks')
      .select('*')
      .eq('user_id', data.teacher_id)
      .single();

    let streakBonus = 1.0;
    if (streak && streak.current_streak >= 6) {
      streakBonus = 1.2; // 连续7天，第7天增加20%
    }

    // 6. 计算积分
    const baseIntegral = skill.price * data.duration_hours;
    const finalIntegral = Math.floor(baseIntegral * skillCoefficient * creditCoeff * streakBonus);

    // 7. 检查每日上限（100积分）
    const today = new Date().toISOString().split('T')[0];
    const { data: todayEarned } = await serviceClient
      .from('integral_transactions')
      .select('amount')
      .eq('user_id', data.teacher_id)
      .eq('type', 'income')
      .gte('created_at', today)
      .like('reason', '%完成技能教学%');

    let todayTotal = 0;
    if (todayEarned) {
      todayTotal = todayEarned.reduce((sum, tx) => sum + parseFloat(tx.amount), 0);
    }

    const actualIntegral = Math.min(finalIntegral, 100 - todayTotal);

    if (actualIntegral > 0) {
      // 8. 添加积分
      await serviceClient.rpc('add_integral', {
        p_user_id: data.teacher_id,
        p_amount: actualIntegral,
        p_reason: `完成技能教学（${data.duration_hours}小时）`,
        p_related_id: data.exchange_id,
        p_expire_days: 365
      });
    }

    // 9. 更新连续学习记录
    const exchangeDate = new Date().toISOString().split('T')[0];
    if (streak) {
      const lastDate = streak.last_exchange_date;
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      const yesterdayStr = yesterday.toISOString().split('T')[0];

      let newStreak = 1;
      if (lastDate === yesterdayStr) {
        newStreak = streak.current_streak + 1;
      } else if (lastDate === exchangeDate) {
        newStreak = streak.current_streak;
      }

      await serviceClient
        .from('learning_streaks')
        .update({
          current_streak: newStreak,
          last_exchange_date: exchangeDate,
          updated_at: new Date().toISOString()
        })
        .eq('user_id', data.teacher_id);
    }

    // 10. 更新双方信用分
    // 教师信用分
    let teacherCreditChange = 0;
    if (data.student_rating >= 4) {
      teacherCreditChange = 0.5;
      
      // 更新连续好评计数
      await serviceClient
        .from('user_credit')
        .update({
          consecutive_good_ratings: serviceClient.raw('consecutive_good_ratings + 1')
        })
        .eq('user_id', data.teacher_id);

      // 检查是否达到10次连续好评
      const { data: updatedCredit } = await serviceClient
        .from('user_credit')
        .select('consecutive_good_ratings')
        .eq('user_id', data.teacher_id)
        .single();

      if (updatedCredit && updatedCredit.consecutive_good_ratings >= 10) {
        teacherCreditChange += 2;
        await serviceClient
          .from('user_credit')
          .update({ consecutive_good_ratings: 0 })
          .eq('user_id', data.teacher_id);
      }
    } else if (data.student_rating <= 2) {
      teacherCreditChange = -1;
      await serviceClient
        .from('user_credit')
        .update({ consecutive_good_ratings: 0 })
        .eq('user_id', data.teacher_id);
    }

    // 学生信用分
    let studentCreditChange = 0;
    if (data.teacher_rating >= 4) {
      studentCreditChange = 0.5;
    } else if (data.teacher_rating <= 2) {
      studentCreditChange = -1;
    }

    // 更新信用分数据
    await serviceClient
      .from('user_credit')
      .update({
        completed_exchanges: serviceClient.raw('completed_exchanges + 1'),
        total_exchanges: serviceClient.raw('total_exchanges + 1'),
        total_rating: serviceClient.raw(`total_rating + ${data.student_rating}`),
        rating_count: serviceClient.raw('rating_count + 1'),
        timely_count: data.is_timely ? serviceClient.raw('timely_count + 1') : serviceClient.raw('timely_count'),
        updated_at: new Date().toISOString()
      })
      .eq('user_id', data.teacher_id);

    await serviceClient
      .from('user_credit')
      .update({
        completed_exchanges: serviceClient.raw('completed_exchanges + 1'),
        total_exchanges: serviceClient.raw('total_exchanges + 1'),
        total_rating: serviceClient.raw(`total_rating + ${data.teacher_rating}`),
        rating_count: serviceClient.raw('rating_count + 1'),
        updated_at: new Date().toISOString()
      })
      .eq('user_id', data.student_id);

    // 重新计算信用分
    await serviceClient.rpc('calculate_credit_score', { p_user_id: data.teacher_id });
    await serviceClient.rpc('calculate_credit_score', { p_user_id: data.student_id });

    // 应用信用分变化
    if (teacherCreditChange !== 0) {
      await serviceClient.rpc('update_credit_score', {
        p_user_id: data.teacher_id,
        p_change: teacherCreditChange,
        p_reason: `交换评价（${data.student_rating}星）`,
        p_related_id: data.exchange_id
      });
    }

    if (studentCreditChange !== 0) {
      await serviceClient.rpc('update_credit_score', {
        p_user_id: data.student_id,
        p_change: studentCreditChange,
        p_reason: `交换评价（${data.teacher_rating}星）`,
        p_related_id: data.exchange_id
      });
    }

    return new Response(
      JSON.stringify({
        success: true,
        integral_earned: actualIntegral,
        teacher_credit_change: teacherCreditChange,
        student_credit_change: studentCreditChange
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
