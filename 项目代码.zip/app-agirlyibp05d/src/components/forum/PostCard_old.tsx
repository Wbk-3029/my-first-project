import { Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { UserProfileDialog } from '@/components/user/UserProfileDialog';
import type { Post } from '@/types';
import { Heart, MessageCircle } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { zhCN } from 'date-fns/locale';

interface PostCardProps {
  post: Post;
}

export function PostCard({ post }: PostCardProps) {
  return (
    <Link to={`/forum/${post.id}`}>
      <Card className="hover:shadow-lg transition-all duration-300 hover:border-primary/50 cursor-pointer">
        <CardHeader className="space-y-2">
          <CardTitle className="text-lg line-clamp-1">{post.title}</CardTitle>
          <CardDescription className="line-clamp-2">{post.content}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {post.images && post.images.length > 0 && (
            <div className="grid grid-cols-3 gap-2">
              {post.images.slice(0, 3).map((url, index) => (
                <div key={index} className="aspect-square">
                  <img
                    src={url}
                    alt={`图片 ${index + 1}`}
                    className="w-full h-full object-cover rounded-lg border border-border"
                  />
                </div>
              ))}
            </div>
          )}

          {post.exchange_need && (
            <div className="text-sm text-muted-foreground">
              <span className="font-medium text-foreground">交换需求:</span> {post.exchange_need}
            </div>
          )}

          <div className="flex items-center justify-between pt-2 border-t border-border">
            <div 
              className="flex items-center space-x-2"
              onClick={(e) => e.preventDefault()}
            >
              {post.profiles && (
                <>
                  <UserProfileDialog
                    userId={post.user_id}
                    userName={post.profiles.nickname || '未知用户'}
                    userAvatar={post.profiles.avatar_url}
                    userCreditScore={post.profiles.credit_score}
                    trigger={
                      <Avatar className="h-6 w-6 cursor-pointer hover:ring-2 hover:ring-primary transition-all">
                        <AvatarImage src={post.profiles.avatar_url || undefined} />
                        <AvatarFallback className="text-xs">
                          {post.profiles.nickname?.[0] || '用'}
                        </AvatarFallback>
                      </Avatar>
                    }
                  />
                  <span className="text-xs text-muted-foreground">
                    {post.profiles.nickname || '未知用户'}
                  </span>
                  <span className="text-xs text-muted-foreground">·</span>
                </>
              )}
              <span className="text-xs text-muted-foreground">
                {formatDistanceToNow(new Date(post.created_at), {
                  addSuffix: true,
                  locale: zhCN,
                })}
              </span>
            </div>

            <div className="flex items-center space-x-3 text-xs text-muted-foreground">
              <div className="flex items-center space-x-1">
                <Heart className="h-3.5 w-3.5" />
                <span>{post.like_count}</span>
              </div>
              <div className="flex items-center space-x-1">
                <MessageCircle className="h-3.5 w-3.5" />
                <span>{post.reply_count}</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
