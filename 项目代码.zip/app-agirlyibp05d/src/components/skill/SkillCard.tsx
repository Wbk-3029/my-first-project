import { Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { UserProfileDialog } from '@/components/user/UserProfileDialog';
import type { Skill } from '@/types';
import { SKILL_TYPE_LABELS } from '@/types';
import { Coins, TrendingUp, User, Repeat, Image as ImageIcon, Video } from 'lucide-react';

interface SkillCardProps {
  skill: Skill;
}

export function SkillCard({ skill }: SkillCardProps) {
  const hasDirectExchange = !!skill.required_skills;
  const hasMedia = skill.media && skill.media.length > 0;
  const firstMedia = hasMedia ? skill.media[0] : null;
  const isVideo = firstMedia?.match(/\.(mp4|webm|ogg)$/i);

  return (
    <Link to={`/skills/${skill.id}`}>
      <Card className="h-full hover:shadow-lg transition-all duration-300 hover:border-primary/50 cursor-pointer overflow-hidden">
        {/* 媒体缩略图 */}
        {hasMedia && firstMedia && (
          <div className="relative w-full h-48 bg-muted overflow-hidden">
            {isVideo ? (
              <>
                <video
                  src={firstMedia}
                  className="w-full h-full object-cover"
                  muted
                />
                <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                  <div className="w-12 h-12 rounded-full bg-white/90 flex items-center justify-center">
                    <Video className="h-6 w-6 text-primary" />
                  </div>
                </div>
              </>
            ) : (
              <img
                src={firstMedia}
                alt={skill.name}
                className="w-full h-full object-cover"
              />
            )}
            {skill.media.length > 1 && (
              <div className="absolute top-2 right-2 px-2 py-1 bg-black/60 text-white text-xs rounded-full flex items-center gap-1">
                <ImageIcon className="h-3 w-3" />
                {skill.media.length}
              </div>
            )}
          </div>
        )}

        <CardHeader className="space-y-2">
          <div className="flex items-start justify-between gap-2">
            <CardTitle className="text-lg line-clamp-1">{skill.name}</CardTitle>
            <Badge variant="secondary" className="shrink-0">
              {SKILL_TYPE_LABELS[skill.type]}
            </Badge>
          </div>
          <CardDescription className="line-clamp-2">
            {skill.description || '暂无描述'}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center space-x-1 text-secondary font-semibold">
              <Coins className="h-4 w-4" />
              <span>{skill.price} 技易点</span>
            </div>
            <div className="flex items-center space-x-1 text-muted-foreground">
              <TrendingUp className="h-4 w-4" />
              <span>{skill.exchange_count} 次交换</span>
            </div>
          </div>

          {/* Exchange Methods */}
          <div className="flex gap-2">
            {hasDirectExchange && (
              <Badge variant="outline" className="text-xs gap-1">
                <Repeat className="h-3 w-3" />
                直接交换
              </Badge>
            )}
            <Badge variant="outline" className="text-xs gap-1">
              <Coins className="h-3 w-3" />
              技易点
            </Badge>
          </div>

          {skill.profiles && (
            <div 
              className="flex items-center space-x-2 pt-2 border-t border-border"
              onClick={(e) => e.preventDefault()}
            >
              <UserProfileDialog
                userId={skill.user_id}
                userName={skill.profiles.nickname || '未知用户'}
                userAvatar={skill.profiles.avatar_url}
                userCreditScore={skill.profiles.credit_score}
                trigger={
                  <Avatar className="h-6 w-6 cursor-pointer hover:ring-2 hover:ring-primary transition-all">
                    <AvatarImage src={skill.profiles.avatar_url || undefined} />
                    <AvatarFallback className="text-xs">
                      {skill.profiles.nickname?.[0] || '用'}
                    </AvatarFallback>
                  </Avatar>
                }
              />
              <span className="text-xs text-muted-foreground">
                {skill.profiles.nickname || '未知用户'}
              </span>
              <span className="text-xs text-muted-foreground">·</span>
              <span className="text-xs text-muted-foreground">
                信用分 {skill.profiles.credit_score}
              </span>
            </div>
          )}
        </CardContent>
      </Card>
    </Link>
  );
}
