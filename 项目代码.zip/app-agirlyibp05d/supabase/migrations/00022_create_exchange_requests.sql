-- 创建交换申请表
CREATE TABLE IF NOT EXISTS exchange_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  from_user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  to_user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  skill_id uuid NOT NULL REFERENCES skills(id) ON DELETE CASCADE,
  mode text NOT NULL CHECK (mode IN ('direct', 'integral', 'group')),
  duration numeric NOT NULL CHECK (duration > 0), -- 交换时长（小时）
  start_time timestamptz NOT NULL, -- 期望开始时间
  end_time timestamptz, -- 期望结束时间
  message text, -- 附加留言
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'rejected', 'cancelled')),
  points_amount int, -- 积分金额（积分交换模式）
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 创建索引
CREATE INDEX idx_exchange_requests_from_user ON exchange_requests(from_user_id);
CREATE INDEX idx_exchange_requests_to_user ON exchange_requests(to_user_id);
CREATE INDEX idx_exchange_requests_skill ON exchange_requests(skill_id);
CREATE INDEX idx_exchange_requests_status ON exchange_requests(status);

-- 添加注释
COMMENT ON TABLE exchange_requests IS '交换申请表';
COMMENT ON COLUMN exchange_requests.mode IS '交换模式：direct-直接交换, integral-积分交换, group-团购交换';
COMMENT ON COLUMN exchange_requests.duration IS '交换时长（小时）';
COMMENT ON COLUMN exchange_requests.start_time IS '期望开始时间';
COMMENT ON COLUMN exchange_requests.end_time IS '期望结束时间（自动计算）';
COMMENT ON COLUMN exchange_requests.status IS '状态：pending-待确认, accepted-已同意, rejected-已拒绝, cancelled-已取消';

-- 启用RLS
ALTER TABLE exchange_requests ENABLE ROW LEVEL SECURITY;

-- RLS策略：用户可以查看自己发起或接收的申请
CREATE POLICY "Users can view their own exchange requests"
  ON exchange_requests
  FOR SELECT
  USING (auth.uid() = from_user_id OR auth.uid() = to_user_id);

-- RLS策略：用户可以创建交换申请
CREATE POLICY "Users can create exchange requests"
  ON exchange_requests
  FOR INSERT
  WITH CHECK (auth.uid() = from_user_id);

-- RLS策略：用户可以更新自己接收的申请（同意/拒绝）
CREATE POLICY "Users can update received requests"
  ON exchange_requests
  FOR UPDATE
  USING (auth.uid() = to_user_id)
  WITH CHECK (auth.uid() = to_user_id);

-- RLS策略：用户可以取消自己发起的申请
CREATE POLICY "Users can cancel their own requests"
  ON exchange_requests
  FOR UPDATE
  USING (auth.uid() = from_user_id AND status = 'pending')
  WITH CHECK (auth.uid() = from_user_id AND status = 'cancelled');

-- 创建RPC函数：创建交换申请
CREATE OR REPLACE FUNCTION create_exchange_request(
  p_to_user_id uuid,
  p_skill_id uuid,
  p_mode text,
  p_duration numeric,
  p_start_time timestamptz,
  p_message text DEFAULT NULL
) RETURNS json AS $$
DECLARE
  v_request_id uuid;
  v_skill_price int;
  v_user_balance int;
  v_result json;
BEGIN
  -- 检查是否是自己
  IF auth.uid() = p_to_user_id THEN
    RAISE EXCEPTION '不能向自己发起交换申请';
  END IF;

  -- 如果是积分交换，检查技能价格和用户余额
  IF p_mode = 'integral' THEN
    -- 获取技能价格
    SELECT price INTO v_skill_price
    FROM skills
    WHERE id = p_skill_id AND is_deleted = false;

    IF v_skill_price IS NULL THEN
      RAISE EXCEPTION '技能不存在或已删除';
    END IF;

    -- 获取用户积分余额
    SELECT balance INTO v_user_balance
    FROM integral_accounts
    WHERE user_id = auth.uid();

    IF v_user_balance IS NULL THEN
      v_user_balance := 0;
    END IF;

    -- 检查余额是否足够
    IF v_user_balance < v_skill_price THEN
      RAISE EXCEPTION '积分余额不足';
    END IF;
  ELSE
    v_skill_price := NULL;
  END IF;

  -- 创建交换申请
  INSERT INTO exchange_requests (
    from_user_id,
    to_user_id,
    skill_id,
    mode,
    duration,
    start_time,
    end_time,
    message,
    points_amount
  ) VALUES (
    auth.uid(),
    p_to_user_id,
    p_skill_id,
    p_mode,
    p_duration,
    p_start_time,
    p_start_time + (p_duration || ' hours')::interval,
    p_message,
    v_skill_price
  ) RETURNING id INTO v_request_id;

  -- 返回结果
  SELECT json_build_object(
    'success', true,
    'request_id', v_request_id,
    'message', '交换申请已发送'
  ) INTO v_result;

  RETURN v_result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 创建RPC函数：处理交换申请（同意/拒绝）
CREATE OR REPLACE FUNCTION handle_exchange_request(
  p_request_id uuid,
  p_action text -- 'accept' 或 'reject'
) RETURNS json AS $$
DECLARE
  v_request record;
  v_exchange_id uuid;
  v_result json;
BEGIN
  -- 检查action参数
  IF p_action NOT IN ('accept', 'reject') THEN
    RAISE EXCEPTION '无效的操作';
  END IF;

  -- 获取申请信息
  SELECT * INTO v_request
  FROM exchange_requests
  WHERE id = p_request_id
    AND to_user_id = auth.uid()
    AND status = 'pending';

  IF v_request IS NULL THEN
    RAISE EXCEPTION '申请不存在或无权操作';
  END IF;

  -- 更新申请状态
  IF p_action = 'accept' THEN
    UPDATE exchange_requests
    SET status = 'accepted', updated_at = now()
    WHERE id = p_request_id;

    -- 如果是积分交换，扣除申请方积分，增加接收方积分
    IF v_request.mode = 'integral' AND v_request.points_amount IS NOT NULL THEN
      -- 扣除申请方积分
      UPDATE integral_accounts
      SET balance = balance - v_request.points_amount,
          total_spent = total_spent + v_request.points_amount,
          updated_at = now()
      WHERE user_id = v_request.from_user_id;

      -- 增加接收方积分
      UPDATE integral_accounts
      SET balance = balance + v_request.points_amount,
          total_earned = total_earned + v_request.points_amount,
          updated_at = now()
      WHERE user_id = v_request.to_user_id;

      -- 记录积分交易
      INSERT INTO integral_transactions (user_id, amount, type, reason, related_id)
      VALUES
        (v_request.from_user_id, -v_request.points_amount, 'expense', '积分交换支付', p_request_id),
        (v_request.to_user_id, v_request.points_amount, 'income', '积分交换收入', p_request_id);
    END IF;

    -- 创建交换记录
    INSERT INTO exchanges (
      type,
      initiator_id,
      receiver_id,
      initiator_skill_id,
      receiver_skill_id,
      points_amount,
      status,
      note
    ) VALUES (
      CASE v_request.mode
        WHEN 'direct' THEN 'direct'::exchange_type
        WHEN 'integral' THEN 'point'::exchange_type
        WHEN 'group' THEN 'group'::exchange_type
      END,
      v_request.from_user_id,
      v_request.to_user_id,
      NULL, -- 申请方技能ID（直接交换时需要）
      v_request.skill_id,
      v_request.points_amount,
      'in_progress'::exchange_status,
      v_request.message
    ) RETURNING id INTO v_exchange_id;

    SELECT json_build_object(
      'success', true,
      'exchange_id', v_exchange_id,
      'message', '已同意交换申请'
    ) INTO v_result;
  ELSE
    -- 拒绝申请
    UPDATE exchange_requests
    SET status = 'rejected', updated_at = now()
    WHERE id = p_request_id;

    SELECT json_build_object(
      'success', true,
      'message', '已拒绝交换申请'
    ) INTO v_result;
  END IF;

  RETURN v_result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 创建RPC函数：取消交换申请
CREATE OR REPLACE FUNCTION cancel_exchange_request(
  p_request_id uuid
) RETURNS json AS $$
DECLARE
  v_result json;
BEGIN
  -- 更新申请状态
  UPDATE exchange_requests
  SET status = 'cancelled', updated_at = now()
  WHERE id = p_request_id
    AND from_user_id = auth.uid()
    AND status = 'pending';

  IF NOT FOUND THEN
    RAISE EXCEPTION '申请不存在或无权操作';
  END IF;

  SELECT json_build_object(
    'success', true,
    'message', '已取消交换申请'
  ) INTO v_result;

  RETURN v_result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
