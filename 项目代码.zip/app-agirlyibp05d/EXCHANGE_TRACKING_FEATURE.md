# 交换进度跟踪功能说明

## 功能概述
交换进度跟踪功能为用户提供完整的交换管理体验，包括待处理申请、进行中交换和已完成交换的查看和管理，以及详细的交换状态时间线展示。

---

## 1. 数据库设计

### 1.1 exchanges表新增字段
在原有exchanges表基础上新增以下字段：

| 字段名 | 类型 | 说明 |
|--------|------|------|
| start_time | timestamptz | 交换开始时间（约定时间） |
| completed_at | timestamptz | 交换完成时间 |

### 1.2 RPC函数

#### complete_exchange
完成交换

**参数**:
- `p_exchange_id`: 交换ID

**返回**:
```json
{
  "success": true,
  "message": "交换已完成，获得10积分奖励"
}
```

**业务逻辑**:
1. 检查交换是否存在且状态为in_progress
2. 更新交换状态为completed
3. 设置完成时间
4. 增加双方的交换次数
5. 奖励双方10积分
6. 记录积分交易

#### get_exchange_stats
获取交换统计

**返回**:
```json
{
  "pending": 5,
  "in_progress": 3,
  "completed": 20
}
```

**统计内容**:
- pending: 待处理数量（收到的申请）
- in_progress: 进行中数量
- completed: 已完成数量

---

## 2. API函数

### 2.1 ExchangeWithDetails接口
扩展Exchange接口，包含关联数据：

```typescript
export interface ExchangeWithDetails extends Exchange {
  initiator?: Profile;
  receiver?: Profile;
  initiator_skill?: Skill;
  receiver_skill?: Skill;
  request?: ExchangeRequest;
}
```

### 2.2 getMyExchanges
获取我的交换列表

```typescript
getMyExchanges(
  status?: 'pending' | 'in_progress' | 'completed'
): Promise<ExchangeWithDetails[]>
```

**功能**:
- 获取我发起或参与的交换
- 支持按状态筛选
- 按创建时间倒序排列
- 包含关联的用户和技能信息

### 2.3 getExchangeDetail
获取交换详情

```typescript
getExchangeDetail(
  exchangeId: string
): Promise<ExchangeWithDetails | null>
```

**功能**:
- 获取单个交换的完整信息
- 包含双方用户信息
- 包含双方技能信息

### 2.4 completeExchange
完成交换

```typescript
completeExchange(
  exchangeId: string
): Promise<{ success: boolean; message: string }>
```

**功能**:
- 标记交换为已完成
- 奖励双方积分
- 增加交换次数

### 2.5 getExchangeStats
获取交换统计

```typescript
getExchangeStats(): Promise<{
  pending: number;
  in_progress: number;
  completed: number;
}>
```

**功能**:
- 统计待处理申请数量
- 统计进行中交换数量
- 统计已完成交换数量

---

## 3. 前端页面

### 3.1 MyExchangesPage
我的交换页面

**路由**: `/my-exchanges`

**功能**:
- 三个标签页：待处理、进行中、已完成
- 显示交换列表
- 显示统计徽章
- 点击卡片进入详情页

**标签页说明**:
1. **待处理**:
   - 显示收到的待确认申请
   - 显示申请数量徽章
   - 点击跳转到交换申请页面

2. **进行中**:
   - 显示状态为in_progress的交换
   - 显示交换数量徽章
   - 点击进入交换详情页

3. **已完成**:
   - 显示状态为completed的交换
   - 显示完成时间
   - 点击进入交换详情页

**交换卡片信息**:
- 对方头像和昵称
- 交换状态徽章
- 技能名称
- 约定时间（进行中）
- 完成时间（已完成）
- 查看详情链接

**状态徽章**:
- 待确认: 黄色
- 进行中: 蓝色
- 已完成: 灰色

### 3.2 ExchangeDetailPage
交换详情页面

**路由**: `/exchanges/:id`

**功能**:
- 显示交换详情
- 显示状态时间线
- 完成交换按钮（进行中）
- 评价按钮（已完成）

**详情卡片**:
1. **对方信息**:
   - 头像和昵称
   - 信用分
   - 查看主页按钮

2. **交换信息**:
   - 交换类型（直接/积分/团购）
   - 积分金额（如有）
   - 约定时间

3. **技能信息**:
   - 我的技能（名称、描述）
   - 对方技能（名称、描述）

4. **备注**:
   - 显示交换备注（如有）

**状态时间线**:
- 发起申请: 显示创建时间
- 对方同意: 显示更新时间
- 进行中: 显示开始时间
- 已完成: 显示完成时间
- 待完成: 灰色显示

**操作按钮**:
1. **进行中状态**:
   - 确认完成按钮
   - 点击后标记为已完成
   - 奖励双方积分

2. **已完成状态**:
   - 评价按钮（未评价）
   - 已评价提示（已评价）

---

## 4. 业务流程

### 4.1 查看我的交换流程
1. 用户在个人中心点击"我的交换"
2. 进入MyExchangesPage页面
3. 系统加载交换统计和列表
4. 用户切换标签页查看不同状态的交换
5. 用户点击交换卡片进入详情页

### 4.2 查看交换详情流程
1. 用户在交换列表点击卡片
2. 进入ExchangeDetailPage页面
3. 系统加载交换详情
4. 显示对方信息、交换信息、技能信息
5. 显示状态时间线
6. 根据状态显示操作按钮

### 4.3 完成交换流程
1. 用户在交换详情页点击"确认完成"按钮
2. 调用completeExchange API
3. 系统更新交换状态为completed
4. 设置完成时间
5. 增加双方交换次数
6. 奖励双方10积分
7. 记录积分交易
8. 显示成功提示
9. 刷新页面显示最新状态

### 4.4 评价交换流程
1. 用户在交换详情页点击"评价对方"按钮
2. 跳转到评价页面
3. 用户填写评价内容和评分
4. 提交评价
5. 更新对方信用分
6. 返回交换详情页

---

## 5. 状态说明

### 5.1 交换状态
- **pending**: 待确认 - 申请已发送，等待对方确认
- **accepted**: 已同意 - 对方已同意申请（过渡状态）
- **in_progress**: 进行中 - 交换正在进行
- **completed**: 已完成 - 交换已完成
- **rejected**: 已拒绝 - 对方已拒绝申请
- **cancelled**: 已取消 - 申请已取消

### 5.2 状态转换
```
pending → accepted → in_progress → completed
pending → rejected
pending → cancelled
```

### 5.3 状态时间线
1. **发起申请**: 显示created_at
2. **对方同意**: 显示updated_at（accepted状态）
3. **进行中**: 显示start_time（in_progress状态）
4. **已完成**: 显示completed_at（completed状态）

---

## 6. 积分奖励

### 6.1 完成交换奖励
- 奖励金额: 10积分
- 奖励对象: 交换双方
- 奖励时机: 交换完成时

### 6.2 积分交易记录
```sql
INSERT INTO integral_transactions (user_id, amount, type, reason, related_id)
VALUES
  (initiator_id, 10, 'income', '完成交换奖励', exchange_id),
  (receiver_id, 10, 'income', '完成交换奖励', exchange_id);
```

### 6.3 积分账户更新
- balance: +10
- total_earned: +10

---

## 7. 用户界面

### 7.1 我的交换页面
- 标题: "我的交换"
- 三个标签页: 待处理、进行中、已完成
- 统计徽章: 显示待处理和进行中数量
- 交换卡片: 头像、昵称、状态、技能、时间
- 空状态: 居中显示提示文字
- 加载状态: 骨架屏

### 7.2 交换详情页面
- 返回按钮: 返回我的交换页面
- 详情卡片: 对方信息、交换信息、技能信息、备注
- 时间线卡片: 状态时间线
- 操作按钮: 确认完成、评价对方
- 加载状态: 骨架屏
- 空状态: 交换不存在提示

### 7.3 个人中心入口
- 菜单组: "我的交换"
- 菜单项1: "我的交换" → /my-exchanges
- 菜单项2: "交换申请" → /exchange-requests

---

## 8. 错误处理

### 8.1 前端验证
- 检查交换是否存在
- 检查用户权限
- 检查交换状态

### 8.2 后端验证
- 检查交换是否存在
- 检查用户是否为交换参与方
- 检查交换状态是否为in_progress

### 8.3 错误提示
- "交换不存在或无权操作"
- "加载失败"
- "操作失败"

---

## 9. 性能优化

### 9.1 数据库优化
- 使用索引加速查询
- 使用RLS策略限制数据访问
- 使用RPC函数封装业务逻辑

### 9.2 前端优化
- 使用骨架屏提升加载体验
- 并行加载统计和列表数据
- 操作后刷新页面

---

## 10. 安全性

### 10.1 RLS策略
- 用户只能查看自己参与的交换
- 用户只能完成自己参与的交换

### 10.2 业务逻辑
- 检查用户权限
- 检查交换状态
- 使用SECURITY DEFINER确保权限

---

## 11. 扩展功能

### 11.1 交换提醒（待实现）
- 交换前1小时提醒
- 使用Edge Function定时任务
- 发送应用内通知

**实现方案**:
1. 创建Edge Function定时任务
2. 每小时查询即将开始的交换
3. 发送通知给交换双方
4. 记录通知历史

### 11.2 自动评价（待实现）
- 交换完成后24小时内评价
- 逾期未评价则系统默认好评

**实现方案**:
1. 创建Edge Function定时任务
2. 每天查询已完成但未评价的交换
3. 检查是否超过24小时
4. 自动创建默认好评
5. 更新信用分

### 11.3 交换筛选
- 按交换类型筛选
- 按时间范围筛选
- 按对方昵称搜索

### 11.4 交换统计
- 交换总数
- 成功率
- 平均评分
- 交换时长统计

---

## 12. 测试建议

### 12.1 功能测试
1. 测试查看我的交换列表
2. 测试查看交换详情
3. 测试完成交换
4. 测试评价交换
5. 测试交换统计

### 12.2 边界测试
1. 测试无交换记录
2. 测试重复完成交换
3. 测试非参与方访问交换详情

### 12.3 性能测试
1. 测试大量交换列表加载
2. 测试并发完成交换

---

## 13. 常见问题

### Q1: 为什么需要交换进度跟踪功能？
A: 交换进度跟踪功能让用户可以清晰地了解交换的当前状态，方便管理和跟踪交换进度，提升用户体验。

### Q2: 完成交换后会获得什么奖励？
A: 完成交换后，交换双方各获得10积分奖励，同时交换次数+1。

### Q3: 如何查看交换的详细信息？
A: 在"我的交换"页面点击交换卡片，即可进入交换详情页查看完整信息。

### Q4: 交换完成后必须评价吗？
A: 建议在交换完成后及时评价对方，评价会影响对方的信用分。未来会实现24小时内未评价则自动默认好评的功能。

### Q5: 如何知道交换即将开始？
A: 未来会实现交换前1小时的应用内通知提醒功能。

---

## 14. 更新日志

### v1.0.0 (2026-03-23)
- 初始版本
- 为exchanges表添加start_time和completed_at字段
- 创建complete_exchange RPC函数
- 创建get_exchange_stats RPC函数
- 创建API函数：getMyExchanges、getExchangeDetail、completeExchange、getExchangeStats
- 创建MyExchangesPage页面（三个标签页）
- 创建ExchangeDetailPage页面（详情和时间线）
- 更新ProfilePage添加"我的交换"入口
- 更新handle_exchange_request函数，添加start_time字段
- 更新Exchange类型定义，添加start_time和completed_at字段

---

## 15. 技术实现细节

### 15.1 数据加载策略
- 使用Promise.all并行加载统计和列表数据
- 减少等待时间，提升用户体验

### 15.2 状态管理
- 使用useState管理页面状态
- 使用useEffect在组件挂载时加载数据
- 操作后重新加载数据

### 15.3 路由设计
- `/my-exchanges`: 我的交换列表
- `/exchanges/:id`: 交换详情
- `/exchange-requests`: 交换申请列表
- `/rate/:id`: 评价页面

### 15.4 组件复用
- 使用Card组件展示交换卡片
- 使用Badge组件展示状态徽章
- 使用Tabs组件实现标签页切换
- 使用Skeleton组件实现加载状态

---

## 16. 界面设计规范

### 16.1 颜色规范
- 待确认: 黄色（text-yellow-600）
- 进行中: 蓝色（text-blue-600）
- 已完成: 绿色（text-green-600）
- 已拒绝: 红色（text-red-600）
- 已取消: 灰色（text-gray-600）

### 16.2 间距规范
- 卡片间距: 12px（space-y-3）
- 卡片内边距: 16px（p-4）
- 元素间距: 12px（gap-3）

### 16.3 字体规范
- 标题: 18px（text-title-lg）
- 正文: 14px（text-sm）
- 辅助: 12px（text-xs）

### 16.4 圆角规范
- 卡片圆角: 12px（rounded-xl）
- 头像圆角: 50%（rounded-full）
- 徽章圆角: 9999px（rounded-full）

---

## 17. 数据流图

```
用户 → MyExchangesPage → getExchangeStats → 显示统计
                        → getReceivedExchangeRequests → 显示待处理
                        → getMyExchanges(in_progress) → 显示进行中
                        → getMyExchanges(completed) → 显示已完成

用户 → ExchangeDetailPage → getExchangeDetail → 显示详情
                           → checkExchangeRated → 检查评价状态
                           → completeExchange → 完成交换
```

---

**最后更新**: 2026-03-23
**版本**: v1.0.0
**维护者**: 技遇开发团队
