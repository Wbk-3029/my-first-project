import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { MainLayout } from '@/components/layouts/MainLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Skeleton } from '@/components/ui/skeleton';
import { Separator } from '@/components/ui/separator';
import {
  getExchangeDetail,
  submitRating,
  type ExchangeWithDetails,
} from '@/db/api';
import { Star, ArrowLeft, Sparkles } from 'lucide-react';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';

export default function RatePage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { profile } = useAuth();
  const [exchange, setExchange] = useState<ExchangeWithDetails | null>(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  const [formData, setFormData] = useState({
    skillRating: 5,
    attitudeRating: 5,
    punctualityRating: 5,
    comment: '',
  });

  useEffect(() => {
    if (id) {
      loadData();
    }
  }, [id]);

  const loadData = async () => {
    if (!id) return;

    try {
      setLoading(true);
      const data = await getExchangeDetail(id);
      setExchange(data);

      if (data?.status !== 'completed') {
        toast.error('交换尚未完成，无法评价');
        navigate('/my-exchanges');
      }
    } catch (error) {
      toast.error('加载失败');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!id || !exchange) return;

    const isInitiator = profile?.id === exchange.initiator_id;
    const ratedId = isInitiator ? exchange.receiver_id : exchange.initiator_id;

    try {
      setSubmitting(true);
      const result = await submitRating({
        exchangeId: id,
        ratedId,
        skillRating: formData.skillRating,
        attitudeRating: formData.attitudeRating,
        punctualityRating: formData.punctualityRating,
        comment: formData.comment || undefined,
      });

      toast.success(
        <div>
          <div className="font-medium">{result.message}</div>
          <div className="text-sm text-muted-foreground mt-1">
            对方信用分 {result.creditChange > 0 ? '+' : ''}{result.creditChange}，
            当前信用分：{result.newCredit}
          </div>
        </div>
      );

      navigate('/my-exchanges');
    } catch (error: any) {
      toast.error(error.message || '提交失败');
    } finally {
      setSubmitting(false);
    }
  };

  const StarRating = ({
    value,
    onChange,
    label,
  }: {
    value: number;
    onChange: (value: number) => void;
    label: string;
  }) => {
    return (
      <div className="space-y-2">
        <Label className="text-sm font-medium">{label}</Label>
        <div className="flex gap-2">
          {[1, 2, 3, 4, 5].map((star) => (
            <button
              key={star}
              type="button"
              onClick={() => onChange(star)}
              className="transition-transform hover:scale-110 focus:outline-none"
            >
              <Star
                className={`h-8 w-8 ${
                  star <= value
                    ? 'fill-yellow-400 text-yellow-400'
                    : 'text-gray-300 dark:text-gray-600'
                }`}
              />
            </button>
          ))}
          <span className="ml-2 text-sm text-muted-foreground self-center">
            {value} 星
          </span>
        </div>
      </div>
    );
  };

  if (loading) {
    return (
      <MainLayout>
        <div className="space-y-4">
          <Skeleton className="h-10 w-full bg-muted" />
          <Skeleton className="h-64 w-full rounded-xl bg-muted" />
        </div>
      </MainLayout>
    );
  }

  if (!exchange) {
    return (
      <MainLayout>
        <Card className="rounded-xl">
          <div className="p-12 text-center text-muted-foreground">
            交换不存在
          </div>
        </Card>
      </MainLayout>
    );
  }

  const isInitiator = profile?.id === exchange.initiator_id;
  const otherUser = isInitiator ? exchange.receiver : exchange.initiator;
  const otherSkill = isInitiator ? exchange.receiver_skill : exchange.initiator_skill;

  const averageRating =
    (formData.skillRating + formData.attitudeRating + formData.punctualityRating) / 3;

  return (
    <MainLayout>
      <div className="space-y-4">
        {/* 返回按钮 */}
        <Button
          onClick={() => navigate('/my-exchanges')}
          variant="ghost"
          size="sm"
          className="gap-2"
        >
          <ArrowLeft className="h-4 w-4" />
          返回
        </Button>

        {/* 评价卡片 */}
        <Card className="rounded-xl">
          <CardHeader>
            <div className="flex items-center gap-3">
              <Sparkles className="h-5 w-5 text-primary" />
              <CardTitle>评价对方</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* 对方信息 */}
            <div className="flex items-center gap-3 p-4 bg-muted/50 rounded-lg">
              <Avatar className="h-12 w-12">
                <AvatarImage src={otherUser?.avatar_url || undefined} />
                <AvatarFallback>{otherUser?.nickname?.[0] || '用'}</AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <div className="font-medium">{otherUser?.nickname || '匿名用户'}</div>
                <div className="text-sm text-muted-foreground">
                  {otherSkill?.name || '未知技能'}
                </div>
              </div>
            </div>

            <Separator />

            {/* 评分表单 */}
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* 技能水平 */}
              <StarRating
                value={formData.skillRating}
                onChange={(value) =>
                  setFormData((prev) => ({ ...prev, skillRating: value }))
                }
                label="技能水平"
              />

              {/* 教学态度 */}
              <StarRating
                value={formData.attitudeRating}
                onChange={(value) =>
                  setFormData((prev) => ({ ...prev, attitudeRating: value }))
                }
                label="教学态度"
              />

              {/* 准时性 */}
              <StarRating
                value={formData.punctualityRating}
                onChange={(value) =>
                  setFormData((prev) => ({ ...prev, punctualityRating: value }))
                }
                label="准时性"
              />

              <Separator />

              {/* 平均评分 */}
              <div className="p-4 bg-primary/5 rounded-lg">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">综合评分</span>
                  <div className="flex items-center gap-2">
                    <Star className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                    <span className="text-lg font-bold">
                      {averageRating.toFixed(1)}
                    </span>
                    <span className="text-sm text-muted-foreground">/ 5.0</span>
                  </div>
                </div>
                <div className="mt-2 text-xs text-muted-foreground">
                  {averageRating >= 4.0 && '好评：对方信用分 +0.5'}
                  {averageRating >= 3.0 && averageRating < 4.0 && '中评：对方信用分不变'}
                  {averageRating < 3.0 && '差评：对方信用分 -1'}
                </div>
              </div>

              {/* 文字评价 */}
              <div className="space-y-2">
                <Label htmlFor="comment">文字评价（选填）</Label>
                <Textarea
                  id="comment"
                  placeholder="分享你的交换体验..."
                  value={formData.comment}
                  onChange={(e) =>
                    setFormData((prev) => ({ ...prev, comment: e.target.value }))
                  }
                  rows={4}
                  className="resize-none"
                />
                <div className="text-xs text-muted-foreground">
                  {formData.comment.length} / 500
                </div>
              </div>

              {/* 提交按钮 */}
              <div className="flex gap-3">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => navigate('/my-exchanges')}
                  className="flex-1 min-h-[44px]"
                >
                  取消
                </Button>
                <Button
                  type="submit"
                  disabled={submitting}
                  className="flex-1 min-h-[44px] gap-2"
                >
                  <Sparkles className="h-4 w-4" />
                  {submitting ? '提交中...' : '提交评价'}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>

        {/* 提示卡片 */}
        <Card className="rounded-xl bg-muted/30">
          <CardContent className="p-4">
            <div className="text-sm text-muted-foreground space-y-1">
              <div>💡 评价规则：</div>
              <div>• 好评（≥4星）：对方信用分 +0.5</div>
              <div>• 中评（3-4星）：对方信用分不变</div>
              <div>• 差评（&lt;3星）：对方信用分 -1</div>
              <div>• 评价提交后无法修改，请谨慎评价</div>
            </div>
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}
