import { useEffect, useState } from 'react';
import { MainLayout } from '@/components/layouts/MainLayout';
import { PageHeader } from '@/components/layouts/PageHeader';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Skeleton } from '@/components/ui/skeleton';
import { getFriendRequests, respondFriendRequest } from '@/db/api';
import { Check, X } from 'lucide-react';
import { toast } from 'sonner';
import { formatDistanceToNow } from 'date-fns';
import { zhCN } from 'date-fns/locale';

interface FriendRequest {
  id: string;
  user_id: string;
  message: string | null;
  created_at: string;
  user_profile: {
    id: string;
    nickname: string;
    avatar_url: string | null;
    credit_score: number;
  };
}

export default function FriendRequestsPage() {
  const [requests, setRequests] = useState<FriendRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [processingIds, setProcessingIds] = useState<Set<string>>(new Set());

  useEffect(() => {
    loadRequests();
  }, []);

  const loadRequests = async () => {
    try {
      setLoading(true);
      const data = await getFriendRequests();
      setRequests(data);
    } catch (error) {
      console.error('加载好友申请失败:', error);
      toast.error('加载好友申请失败');
    } finally {
      setLoading(false);
    }
  };

  const handleRespond = async (requestId: string, accept: boolean) => {
    try {
      setProcessingIds((prev) => new Set(prev).add(requestId));
      await respondFriendRequest(requestId, accept);
      toast.success(accept ? '已同意好友申请' : '已拒绝好友申请');
      loadRequests();
    } catch (error) {
      console.error('处理好友申请失败:', error);
      toast.error('处理好友申请失败');
    } finally {
      setProcessingIds((prev) => {
        const newSet = new Set(prev);
        newSet.delete(requestId);
        return newSet;
      });
    }
  };

  return (
    <MainLayout>
      <PageHeader title="好友申请" />

      <div className="space-y-4">
        {loading ? (
          <>
            {[1, 2, 3].map((i) => (
              <Card key={i}>
                <CardContent className="p-4">
                  <div className="flex items-center gap-4">
                    <Skeleton className="h-12 w-12 rounded-full bg-muted" />
                    <div className="flex-1 space-y-2">
                      <Skeleton className="h-4 w-32 bg-muted" />
                      <Skeleton className="h-3 w-48 bg-muted" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </>
        ) : requests.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center text-muted-foreground">
              暂无好友申请
            </CardContent>
          </Card>
        ) : (
          <>
            {requests.map((request) => (
              <Card key={request.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-start gap-4">
                    {/* 头像 */}
                    <Avatar className="h-12 w-12 shrink-0">
                      <AvatarImage src={request.user_profile.avatar_url || undefined} />
                      <AvatarFallback>
                        {request.user_profile.nickname?.[0] || '用'}
                      </AvatarFallback>
                    </Avatar>

                    {/* 信息 */}
                    <div className="flex-1 min-w-0">
                      <div className="font-medium mb-1">
                        {request.user_profile.nickname || '未知用户'}
                      </div>
                      <div className="text-sm text-muted-foreground mb-2">
                        {request.message || '我想和你成为好友'}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {formatDistanceToNow(new Date(request.created_at), {
                          addSuffix: true,
                          locale: zhCN,
                        })}
                      </div>
                    </div>

                    {/* 操作按钮 */}
                    <div className="flex items-center gap-2 shrink-0">
                      <Button
                        size="sm"
                        variant="default"
                        className="gap-1"
                        onClick={() => handleRespond(request.id, true)}
                        disabled={processingIds.has(request.id)}
                      >
                        <Check className="h-4 w-4" />
                        同意
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="gap-1"
                        onClick={() => handleRespond(request.id, false)}
                        disabled={processingIds.has(request.id)}
                      >
                        <X className="h-4 w-4" />
                        拒绝
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </>
        )}
      </div>
    </MainLayout>
  );
}
