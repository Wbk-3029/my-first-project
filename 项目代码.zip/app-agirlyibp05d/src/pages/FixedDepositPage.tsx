import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { MainLayout } from '@/components/layouts/MainLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { getIntegralAccount, createFixedDeposit, getFixedDeposits } from '@/db/api';
import type { IntegralAccount, FixedDeposit } from '@/db/api';
import { ArrowLeft, Coins, TrendingUp, Calendar, Clock, CheckCircle2, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { formatDistanceToNow } from 'date-fns';
import { zhCN } from 'date-fns/locale';

export default function FixedDepositPage() {
  const [account, setAccount] = useState<IntegralAccount | null>(null);
  const [deposits, setDeposits] = useState<FixedDeposit[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [selectedPeriod, setSelectedPeriod] = useState<7 | 30>(7);
  const [amount, setAmount] = useState('');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const [accountData, depositsData] = await Promise.all([
        getIntegralAccount(),
        getFixedDeposits(),
      ]);

      setAccount(accountData);
      setDeposits(depositsData);
    } catch (error) {
      console.error('加载数据失败:', error);
      toast.error('加载数据失败');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateDeposit = async () => {
    const depositAmount = parseInt(amount);

    if (!depositAmount || depositAmount <= 0) {
      toast.error('请输入有效的存款金额');
      return;
    }

    if (!account || depositAmount > account.balance) {
      toast.error('余额不足');
      return;
    }

    if (depositAmount < 10) {
      toast.error('最低存款金额为10积分');
      return;
    }

    try {
      setCreating(true);
      await createFixedDeposit(depositAmount, selectedPeriod);
      toast.success('存款成功！');
      setAmount('');
      await loadData();
    } catch (error: any) {
      console.error('创建存款失败:', error);
      toast.error(error.message || '创建存款失败');
    } finally {
      setCreating(false);
    }
  };

  const calculateInterest = (deposit: FixedDeposit) => {
    return deposit.amount * deposit.interest_rate * deposit.period_days;
  };

  const calculateTotal = (deposit: FixedDeposit) => {
    return deposit.amount + calculateInterest(deposit);
  };

  const getDaysRemaining = (endDate: string) => {
    const end = new Date(endDate);
    const now = new Date();
    const diff = end.getTime() - now.getTime();
    const days = Math.ceil(diff / (1000 * 60 * 60 * 24));
    return Math.max(0, days);
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('zh-CN', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    });
  };

  const activeDeposits = deposits.filter((d) => d.status === 'active');
  const completedDeposits = deposits.filter((d) => d.status === 'completed');

  if (loading) {
    return (
      <MainLayout>
        <div className="container max-w-4xl mx-auto px-4 py-8 space-y-6">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-64 w-full" />
          <Skeleton className="h-48 w-full" />
        </div>
      </MainLayout>
    );
  }

  const interestRate7 = 0.3;
  const interestRate30 = 0.5;
  const previewAmount = parseInt(amount) || 0;
  const previewInterest =
    selectedPeriod === 7
      ? previewAmount * (interestRate7 / 100) * 7
      : previewAmount * (interestRate30 / 100) * 30;
  const previewTotal = previewAmount + previewInterest;

  return (
    <MainLayout>
      <div className="container max-w-4xl mx-auto px-4 py-8 space-y-6">
        {/* Header */}
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" asChild>
            <Link to="/profile/integral">
              <ArrowLeft className="h-5 w-5" />
            </Link>
          </Button>
          <h1 className="text-2xl font-bold">定期存款</h1>
        </div>

        {/* Balance Card */}
        <Card className="bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 dark:from-blue-950 dark:via-indigo-950 dark:to-purple-950 border-blue-200 dark:border-blue-800">
          <CardContent className="p-6">
            <div className="text-center">
              <div className="text-sm text-muted-foreground mb-2">活期余额</div>
              <div className="text-5xl font-bold text-blue-600 dark:text-blue-400 mb-2">
                {account?.balance || 0}
              </div>
              <div className="flex items-center justify-center gap-2">
                <Coins className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm text-muted-foreground">技易点</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Create Deposit Card */}
        <Card>
          <CardHeader>
            <CardTitle>创建定期存款</CardTitle>
            <CardDescription>选择存款期限，获取更高收益</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Period Selection */}
            <div className="space-y-3">
              <Label>存款期限</Label>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card
                  className={`cursor-pointer transition-all ${
                    selectedPeriod === 7
                      ? 'border-primary bg-primary/5 shadow-md'
                      : 'hover:border-primary/50'
                  }`}
                  onClick={() => setSelectedPeriod(7)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <div className="text-lg font-bold">7天定期</div>
                        <div className="text-sm text-muted-foreground">短期理财</div>
                      </div>
                      {selectedPeriod === 7 && (
                        <CheckCircle2 className="h-5 w-5 text-primary" />
                      )}
                    </div>
                    <div className="flex items-baseline gap-1">
                      <span className="text-3xl font-bold text-green-600">{interestRate7}%</span>
                      <span className="text-sm text-muted-foreground">/天</span>
                    </div>
                    <div className="text-xs text-muted-foreground mt-2">
                      预期年化收益率: {(interestRate7 * 365).toFixed(1)}%
                    </div>
                  </CardContent>
                </Card>

                <Card
                  className={`cursor-pointer transition-all ${
                    selectedPeriod === 30
                      ? 'border-primary bg-primary/5 shadow-md'
                      : 'hover:border-primary/50'
                  }`}
                  onClick={() => setSelectedPeriod(30)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <div className="text-lg font-bold">30天定期</div>
                        <div className="text-sm text-muted-foreground">高收益理财</div>
                      </div>
                      {selectedPeriod === 30 && (
                        <CheckCircle2 className="h-5 w-5 text-primary" />
                      )}
                    </div>
                    <div className="flex items-baseline gap-1">
                      <span className="text-3xl font-bold text-green-600">{interestRate30}%</span>
                      <span className="text-sm text-muted-foreground">/天</span>
                    </div>
                    <div className="text-xs text-muted-foreground mt-2">
                      预期年化收益率: {(interestRate30 * 365).toFixed(1)}%
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* Amount Input */}
            <div className="space-y-2">
              <Label htmlFor="amount">存款金额</Label>
              <Input
                id="amount"
                type="number"
                placeholder="请输入存款金额（最低10积分）"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                min="10"
                max={account?.balance || 0}
              />
              <div className="text-xs text-muted-foreground">
                可用余额: {account?.balance || 0} 积分
              </div>
            </div>

            {/* Preview */}
            {previewAmount >= 10 && (
              <Card className="bg-muted/50">
                <CardContent className="p-4 space-y-2">
                  <div className="text-sm font-medium mb-3">收益预览</div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">存款本金</span>
                    <span className="font-medium">{previewAmount} 积分</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">存款期限</span>
                    <span className="font-medium">{selectedPeriod} 天</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">预期利息</span>
                    <span className="font-medium text-green-600">
                      +{previewInterest.toFixed(1)} 积分
                    </span>
                  </div>
                  <div className="border-t border-border pt-2 mt-2">
                    <div className="flex justify-between">
                      <span className="font-medium">到期本息合计</span>
                      <span className="text-lg font-bold text-primary">
                        {previewTotal.toFixed(1)} 积分
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Submit Button */}
            <Button
              onClick={handleCreateDeposit}
              disabled={creating || !amount || parseInt(amount) < 10}
              className="w-full"
              size="lg"
            >
              {creating ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  创建中...
                </>
              ) : (
                <>
                  <TrendingUp className="h-4 w-4 mr-2" />
                  确认存款
                </>
              )}
            </Button>

            <div className="text-xs text-muted-foreground space-y-1">
              <p>💡 温馨提示：</p>
              <ul className="list-disc list-inside pl-2 space-y-1">
                <li>定期存款期间，本金将被冻结，无法提前支取</li>
                <li>利息每日计算，到期后自动转入活期余额</li>
                <li>最低存款金额为10积分</li>
              </ul>
            </div>
          </CardContent>
        </Card>

        {/* Deposits List */}
        <Card>
          <CardHeader>
            <CardTitle>我的定期存款</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="active">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="active">
                  进行中
                  <Badge variant="secondary" className="ml-2">
                    {activeDeposits.length}
                  </Badge>
                </TabsTrigger>
                <TabsTrigger value="completed">
                  已完成
                  <Badge variant="secondary" className="ml-2">
                    {completedDeposits.length}
                  </Badge>
                </TabsTrigger>
              </TabsList>

              <TabsContent value="active" className="mt-6">
                {activeDeposits.length === 0 ? (
                  <div className="text-center py-12 text-muted-foreground">
                    <Clock className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>暂无进行中的定期存款</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {activeDeposits.map((deposit) => (
                      <Card key={deposit.id} className="hover:shadow-md transition-shadow">
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between gap-4 mb-3">
                            <div>
                              <div className="font-bold text-lg mb-1">
                                {deposit.period_days}天定期
                              </div>
                              <div className="text-sm text-muted-foreground">
                                {formatDate(deposit.start_date)} - {formatDate(deposit.end_date)}
                              </div>
                            </div>
                            <Badge className="bg-blue-100 text-blue-600 dark:bg-blue-950 dark:text-blue-400">
                              <Clock className="h-3 w-3 mr-1" />
                              剩余 {getDaysRemaining(deposit.end_date)} 天
                            </Badge>
                          </div>

                          <div className="grid grid-cols-3 gap-4 text-center py-3 border-t border-b border-border">
                            <div>
                              <div className="text-xs text-muted-foreground mb-1">本金</div>
                              <div className="font-semibold">{deposit.amount}</div>
                            </div>
                            <div>
                              <div className="text-xs text-muted-foreground mb-1">预期利息</div>
                              <div className="font-semibold text-green-600">
                                +{calculateInterest(deposit).toFixed(1)}
                              </div>
                            </div>
                            <div>
                              <div className="text-xs text-muted-foreground mb-1">到期金额</div>
                              <div className="font-semibold text-primary">
                                {calculateTotal(deposit).toFixed(1)}
                              </div>
                            </div>
                          </div>

                          <div className="mt-3 text-xs text-muted-foreground">
                            日利率: {(deposit.interest_rate * 100).toFixed(2)}% · 创建于{' '}
                            {formatDistanceToNow(new Date(deposit.created_at), {
                              addSuffix: true,
                              locale: zhCN,
                            })}
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </TabsContent>

              <TabsContent value="completed" className="mt-6">
                {completedDeposits.length === 0 ? (
                  <div className="text-center py-12 text-muted-foreground">
                    <CheckCircle2 className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>暂无已完成的定期存款</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {completedDeposits.map((deposit) => (
                      <Card key={deposit.id} className="opacity-75">
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between gap-4 mb-3">
                            <div>
                              <div className="font-bold text-lg mb-1">
                                {deposit.period_days}天定期
                              </div>
                              <div className="text-sm text-muted-foreground">
                                {formatDate(deposit.start_date)} - {formatDate(deposit.end_date)}
                              </div>
                            </div>
                            <Badge className="bg-green-100 text-green-600 dark:bg-green-950 dark:text-green-400">
                              <CheckCircle2 className="h-3 w-3 mr-1" />
                              已完成
                            </Badge>
                          </div>

                          <div className="grid grid-cols-3 gap-4 text-center py-3 border-t border-b border-border">
                            <div>
                              <div className="text-xs text-muted-foreground mb-1">本金</div>
                              <div className="font-semibold">{deposit.amount}</div>
                            </div>
                            <div>
                              <div className="text-xs text-muted-foreground mb-1">利息</div>
                              <div className="font-semibold text-green-600">
                                +{calculateInterest(deposit).toFixed(1)}
                              </div>
                            </div>
                            <div>
                              <div className="text-xs text-muted-foreground mb-1">到期金额</div>
                              <div className="font-semibold text-primary">
                                {calculateTotal(deposit).toFixed(1)}
                              </div>
                            </div>
                          </div>

                          <div className="mt-3 text-xs text-muted-foreground">
                            日利率: {(deposit.interest_rate * 100).toFixed(2)}%
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}
