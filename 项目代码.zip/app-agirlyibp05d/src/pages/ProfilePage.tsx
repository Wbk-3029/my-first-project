import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { MainLayout } from '@/components/layouts/MainLayout';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Skeleton } from '@/components/ui/skeleton';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { AvatarUpload } from '@/components/profile/AvatarUpload';
import { MenuGroup } from '@/components/profile/MenuGroup';
import { TransactionPreview } from '@/components/profile/TransactionPreview';
import { useAuth } from '@/contexts/AuthContext';
import {
  getSignInInfo,
  dailySignIn,
  getIntegralAccount,
  getIntegralTransactions,
} from '@/db/api';
import { updateProfile } from '@/db/api';
import type { SignInInfo, IntegralAccount, IntegralTransaction } from '@/db/api';
import {
  Coins,
  Award,
  Package,
  Repeat,
  Star,
  Edit,
  Settings,
  Calendar,
  ChevronRight,
  Users,
  MessageSquare,
  BookOpen,
  MessageCircle,
  TrendingUp,
  History,
  FileText,
  ShieldAlert,
} from 'lucide-react';
import { toast } from 'sonner';
import confetti from 'canvas-confetti';

export default function ProfilePage() {
  const { profile, refreshProfile } = useAuth();
  const [loading, setLoading] = useState(true);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [signInInfo, setSignInInfo] = useState<SignInInfo | null>(null);
  const [signingIn, setSigningIn] = useState(false);
  const [integralAccount, setIntegralAccount] = useState<IntegralAccount | null>(null);
  const [recentTransactions, setRecentTransactions] = useState<IntegralTransaction[]>([]);
  const [editForm, setEditForm] = useState({
    nickname: '',
  });

  useEffect(() => {
    if (profile) {
      loadData();
      setEditForm({ nickname: profile.nickname || '' });
    }
  }, [profile]);

  const loadData = async () => {
    if (!profile) return;

    try {
      setLoading(true);
      const [signInData, accountData, transactionsData] = await Promise.all([
        getSignInInfo(),
        getIntegralAccount(),
        getIntegralTransactions(1, 3),
      ]);

      setSignInInfo(signInData);
      setIntegralAccount(accountData);
      setRecentTransactions(transactionsData);
    } catch (error) {
      console.error('加载数据失败:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSignIn = async () => {
    try {
      setSigningIn(true);
      await dailySignIn();

      // 庆祝动画
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
      });

      toast.success('签到成功！获得积分奖励');
      await loadData();
    } catch (error: any) {
      toast.error(error.message || '签到失败');
    } finally {
      setSigningIn(false);
    }
  };

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile) return;

    try {
      await updateProfile(profile.id, { nickname: editForm.nickname });
      await refreshProfile();
      setEditDialogOpen(false);
      toast.success('更新成功');
    } catch (error) {
      toast.error('更新失败');
    }
  };

  if (loading) {
    return (
      <MainLayout>
        <div className="space-y-4">
          <Skeleton className="h-32 w-full rounded-2xl bg-muted" />
          <Skeleton className="h-40 w-full rounded-2xl bg-muted" />
          <Skeleton className="h-60 w-full rounded-2xl bg-muted" />
        </div>
      </MainLayout>
    );
  }

  if (!profile) {
    return (
      <MainLayout>
        <Card className="rounded-2xl">
          <div className="p-12 text-center text-muted-foreground">请先登录</div>
        </Card>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="space-y-4 pb-4">
        {/* 用户信息卡片 */}
        <Card className="rounded-2xl overflow-hidden bg-gradient-to-br from-primary/10 via-secondary/10 to-accent/10">
          <div className="p-6">
            <div className="flex items-center gap-4 mb-4">
              {/* 头像 */}
              <Dialog>
                <DialogTrigger asChild>
                  <Avatar className="h-20 w-20 cursor-pointer ring-4 ring-background hover:ring-primary/20 transition-all">
                    <AvatarImage src={profile.avatar_url || undefined} />
                    <AvatarFallback className="text-2xl">{profile.nickname?.[0] || '用'}</AvatarFallback>
                  </Avatar>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>更换头像</DialogTitle>
                    <DialogDescription>上传新头像</DialogDescription>
                  </DialogHeader>
                  <AvatarUpload
                    userId={profile.id}
                    currentAvatar={profile.avatar_url || undefined}
                    onUploadSuccess={async () => {
                      await refreshProfile();
                      toast.success('头像更新成功');
                    }}
                  />
                </DialogContent>
              </Dialog>

              {/* 昵称和信用分 */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-2">
                  <h2 className="text-xl font-bold truncate">{profile.nickname || '未设置昵称'}</h2>
                  <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
                    <DialogTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-7 w-7 shrink-0">
                        <Edit className="h-3.5 w-3.5" />
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>编辑资料</DialogTitle>
                      </DialogHeader>
                      <form onSubmit={handleUpdateProfile} className="space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor="nickname">昵称</Label>
                          <Input
                            id="nickname"
                            value={editForm.nickname}
                            onChange={(e) => setEditForm({ nickname: e.target.value })}
                            placeholder="请输入昵称"
                          />
                        </div>
                        <div className="flex justify-end gap-2">
                          <Button type="button" variant="outline" onClick={() => setEditDialogOpen(false)}>
                            取消
                          </Button>
                          <Button type="submit">保存</Button>
                        </div>
                      </form>
                    </DialogContent>
                  </Dialog>
                </div>

                {/* 信用分 */}
                <Link
                  to="/profile/credit"
                  className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-background/80 hover:bg-background transition-colors"
                >
                  <Award className="h-4 w-4 text-primary" />
                  <span className="text-sm font-medium">信用分</span>
                  <span className="text-base font-bold text-primary">{profile.credit_score}</span>
                  <ChevronRight className="h-3 w-3 text-muted-foreground" />
                </Link>
              </div>
            </div>
          </div>
        </Card>

        {/* 技易点余额卡片 */}
        <Card className="rounded-2xl overflow-hidden">
          <div className="p-4">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Coins className="h-5 w-5 text-primary" />
                <span className="text-sm text-muted-foreground">技易点余额</span>
              </div>
              <div className="flex items-center gap-2">
                {/* 签到按钮 */}
                <Button
                  onClick={handleSignIn}
                  disabled={signingIn || signInInfo?.already_signed}
                  size="sm"
                  variant={signInInfo?.already_signed ? 'outline' : 'default'}
                  className="gap-1.5 rounded-full"
                >
                  <Calendar className="h-3.5 w-3.5" />
                  {signInInfo?.already_signed ? '已签到' : '签到'}
                </Button>

                {/* 明细入口 */}
                <Button variant="ghost" size="icon" className="h-9 w-9 rounded-full" asChild>
                  <Link to="/profile/integral">
                    <ChevronRight className="h-4 w-4" />
                  </Link>
                </Button>
              </div>
            </div>

            {/* 余额显示 */}
            <div className="text-center py-4">
              <div className="text-4xl font-bold text-primary mb-1">
                {integralAccount?.balance || 0}
              </div>
              <div className="text-xs text-muted-foreground">
                {signInInfo && (
                  <span>连续签到 {signInInfo.continuous_days} 天</span>
                )}
              </div>
            </div>

            {/* 统计信息 */}
            <div className="grid grid-cols-2 gap-4 pt-4 border-t border-border">
              <div className="text-center">
                <div className="text-xs text-muted-foreground mb-1">累计收入</div>
                <div className="text-lg font-bold text-green-600 dark:text-green-400">
                  +{integralAccount?.total_earned || 0}
                </div>
              </div>
              <div className="text-center">
                <div className="text-xs text-muted-foreground mb-1">累计支出</div>
                <div className="text-lg font-bold text-red-600 dark:text-red-400">
                  -{integralAccount?.total_spent || 0}
                </div>
              </div>
            </div>
          </div>
        </Card>

        {/* 最近交易记录 */}
        <TransactionPreview transactions={recentTransactions} />

        {/* 我的技能 */}
        <MenuGroup
          title="我的技能"
          items={[
            {
              label: '我发布的技能',
              icon: Package,
              path: '/profile/skills',
            },
            {
              label: '我收藏的技能',
              icon: Star,
              path: '/favorites',
            },
          ]}
        />

        {/* 我的交换 */}
        <MenuGroup
          title="我的交换"
          items={[
            {
              label: '我的交换',
              icon: TrendingUp,
              path: '/my-exchanges',
            },
            {
              label: '交换申请',
              icon: History,
              path: '/exchange-requests',
            },
            {
              label: '我的模板',
              icon: FileText,
              path: '/profile/templates',
            },
            {
              label: '违规记录',
              icon: ShieldAlert,
              path: '/profile/violations',
            },
          ]}
        />

        {/* 好友/消息 */}
        <MenuGroup
          title="好友/消息"
          items={[
            {
              label: '好友列表',
              icon: Users,
              path: '/friends',
            },
            {
              label: '私信',
              icon: MessageCircle,
              path: '/notifications',
            },
          ]}
        />

        {/* 设置/帮助 */}
        <MenuGroup
          title="设置/帮助"
          items={[
            {
              label: '平台规则',
              icon: BookOpen,
              path: '/rules',
            },
            {
              label: '意见反馈',
              icon: MessageSquare,
              path: '/feedback',
            },
            {
              label: '设置',
              icon: Settings,
              path: '/settings',
            },
          ]}
        />
      </div>
    </MainLayout>
  );
}
