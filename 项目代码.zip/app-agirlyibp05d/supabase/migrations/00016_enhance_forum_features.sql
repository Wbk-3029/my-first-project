-- 为posts表添加缺失字段
ALTER TABLE posts ADD COLUMN IF NOT EXISTS view_count INTEGER DEFAULT 0;
ALTER TABLE posts ADD COLUMN IF NOT EXISTS is_featured BOOLEAN DEFAULT FALSE;
ALTER TABLE posts ADD COLUMN IF NOT EXISTS is_deleted BOOLEAN DEFAULT FALSE;

-- 为post_replies表添加缺失字段
ALTER TABLE post_replies ADD COLUMN IF NOT EXISTS parent_id UUID REFERENCES post_replies(id) ON DELETE CASCADE;
ALTER TABLE post_replies ADD COLUMN IF NOT EXISTS like_count INTEGER DEFAULT 0;
ALTER TABLE post_replies ADD COLUMN IF NOT EXISTS is_deleted BOOLEAN DEFAULT FALSE;

-- 创建帖子点赞表
CREATE TABLE IF NOT EXISTS post_likes (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  post_id UUID NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(post_id, user_id)
);

-- 创建帖子收藏表（如果不存在）
CREATE TABLE IF NOT EXISTS post_favorites (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  post_id UUID NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(post_id, user_id)
);

-- 创建评论点赞表
CREATE TABLE IF NOT EXISTS reply_likes (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  reply_id UUID NOT NULL REFERENCES post_replies(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(reply_id, user_id)
);

-- 创建举报表
CREATE TABLE IF NOT EXISTS reports (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  reporter_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  target_type TEXT NOT NULL CHECK (target_type IN ('post', 'reply')),
  target_id UUID NOT NULL,
  reason TEXT NOT NULL,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'resolved', 'rejected')),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 添加索引
CREATE INDEX IF NOT EXISTS idx_posts_view_count ON posts(view_count DESC);
CREATE INDEX IF NOT EXISTS idx_posts_is_featured ON posts(is_featured);
CREATE INDEX IF NOT EXISTS idx_posts_is_deleted ON posts(is_deleted);
CREATE INDEX IF NOT EXISTS idx_post_replies_parent ON post_replies(parent_id);
CREATE INDEX IF NOT EXISTS idx_post_replies_post ON post_replies(post_id);
CREATE INDEX IF NOT EXISTS idx_post_likes_post ON post_likes(post_id);
CREATE INDEX IF NOT EXISTS idx_post_likes_user ON post_likes(user_id);
CREATE INDEX IF NOT EXISTS idx_reply_likes_reply ON reply_likes(reply_id);
CREATE INDEX IF NOT EXISTS idx_reply_likes_user ON reply_likes(user_id);
CREATE INDEX IF NOT EXISTS idx_reports_status ON reports(status);

-- 添加RLS策略
ALTER TABLE post_likes ENABLE ROW LEVEL SECURITY;
ALTER TABLE post_favorites ENABLE ROW LEVEL SECURITY;
ALTER TABLE reply_likes ENABLE ROW LEVEL SECURITY;
ALTER TABLE reports ENABLE ROW LEVEL SECURITY;

-- post_likes策略
CREATE POLICY "post_likes_select" ON post_likes FOR SELECT USING (true);
CREATE POLICY "post_likes_insert" ON post_likes FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "post_likes_delete" ON post_likes FOR DELETE USING (auth.uid() = user_id);

-- post_favorites策略
CREATE POLICY "post_favorites_select" ON post_favorites FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "post_favorites_insert" ON post_favorites FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "post_favorites_delete" ON post_favorites FOR DELETE USING (auth.uid() = user_id);

-- reply_likes策略
CREATE POLICY "reply_likes_select" ON reply_likes FOR SELECT USING (true);
CREATE POLICY "reply_likes_insert" ON reply_likes FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "reply_likes_delete" ON reply_likes FOR DELETE USING (auth.uid() = user_id);

-- reports策略
CREATE POLICY "reports_select" ON reports FOR SELECT USING (auth.uid() = reporter_id);
CREATE POLICY "reports_insert" ON reports FOR INSERT WITH CHECK (auth.uid() = reporter_id);

-- 创建增加浏览数的函数
CREATE OR REPLACE FUNCTION increment_post_view(post_id UUID)
RETURNS VOID AS $$
BEGIN
  UPDATE posts
  SET view_count = view_count + 1
  WHERE id = post_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 创建计算热度的函数
CREATE OR REPLACE FUNCTION calculate_post_hotness(
  p_like_count INTEGER,
  p_reply_count INTEGER,
  p_view_count INTEGER
)
RETURNS NUMERIC AS $$
BEGIN
  RETURN (p_like_count * 2.0) + (p_reply_count * 1.0) + (p_view_count * 0.5);
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- 添加注释
COMMENT ON TABLE post_likes IS '帖子点赞表';
COMMENT ON TABLE post_favorites IS '帖子收藏表';
COMMENT ON TABLE reply_likes IS '评论点赞表';
COMMENT ON TABLE reports IS '举报表';
COMMENT ON COLUMN posts.view_count IS '浏览数';
COMMENT ON COLUMN posts.is_featured IS '是否精华';
COMMENT ON COLUMN posts.is_deleted IS '是否删除';
COMMENT ON COLUMN post_replies.parent_id IS '父评论ID，NULL表示顶级评论';
COMMENT ON COLUMN post_replies.like_count IS '点赞数';
COMMENT ON COLUMN post_replies.is_deleted IS '是否删除';