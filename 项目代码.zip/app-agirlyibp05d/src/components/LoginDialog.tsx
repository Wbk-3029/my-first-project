import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useLoginDialog } from '@/contexts/LoginDialogContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import { Loader2 } from 'lucide-react';

export default function LoginDialog() {
  const {
    signInWithPhone,
    signUpWithPhone,
    signInWithEmail,
    signUpWithEmail,
    sendSmsCode,
  } = useAuth();
  const { isOpen, closeLoginDialog } = useLoginDialog();
  const [loading, setLoading] = useState(false);
  const [sendingCode, setSendingCode] = useState(false);
  const [countdown, setCountdown] = useState(0);
  const [sessionId, setSessionId] = useState('');

  useEffect(() => {
    let timer: ReturnType<typeof setInterval>;
    if (countdown > 0) {
      timer = setInterval(() => {
        setCountdown((prev) => {
          if (prev <= 1) {
            clearInterval(timer);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [countdown]);

  // 手机号登录表单
  const [phoneLoginForm, setPhoneLoginForm] = useState({
    phone: '',
    password: '',
  });

  // 手机号注册表单
  const [phoneRegisterForm, setPhoneRegisterForm] = useState({
    phone: '',
    code: '',
    password: '',
    confirmPassword: '',
    nickname: '',
  });

  // 邮箱登录表单
  const [emailLoginForm, setEmailLoginForm] = useState({
    email: '',
    password: '',
  });

  // 邮箱注册表单
  const [emailRegisterForm, setEmailRegisterForm] = useState({
    email: '',
    password: '',
    confirmPassword: '',
    nickname: '',
  });

  // 发送验证码
  const handleSendCode = async () => {
    if (!phoneRegisterForm.phone) {
      toast.error('请输入手机号');
      return;
    }

    if (!/^1[3-9]\d{9}$/.test(phoneRegisterForm.phone)) {
      toast.error('请输入正确的手机号');
      return;
    }

    setSendingCode(true);

    try {
      const { error, sessionId: newSessionId } = await sendSmsCode(phoneRegisterForm.phone);

      if (error) {
        toast.error(error.message || '发送失败');
        return;
      }

      if (newSessionId) {
        setSessionId(newSessionId);
      }

      toast.success('验证码已发送');
      setCountdown(60);
    } catch (error) {
      toast.error('发送失败,请重试');
    } finally {
      setSendingCode(false);
    }
  };

  // 手机号登录
  const handlePhoneLogin = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!phoneLoginForm.phone || !phoneLoginForm.password) {
      toast.error('请填写完整信息');
      return;
    }

    setLoading(true);

    try {
      const { error } = await signInWithPhone(phoneLoginForm.phone, phoneLoginForm.password);

      if (error) {
        toast.error(error.message || '登录失败');
        return;
      }

      toast.success('登录成功');
      closeLoginDialog();
      setPhoneLoginForm({ phone: '', password: '' });
    } catch (error) {
      toast.error('登录失败,请重试');
    } finally {
      setLoading(false);
    }
  };

  // 手机号注册
  const handlePhoneRegister = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!phoneRegisterForm.phone || !phoneRegisterForm.code || !phoneRegisterForm.password) {
      toast.error('请填写完整信息');
      return;
    }

    if (phoneRegisterForm.password !== phoneRegisterForm.confirmPassword) {
      toast.error('两次输入的密码不一致');
      return;
    }

    if (phoneRegisterForm.password.length < 6) {
      toast.error('密码长度至少为6位');
      return;
    }

    if (!sessionId) {
      toast.error('请先获取验证码');
      return;
    }

    setLoading(true);

    try {
      const { error } = await signUpWithPhone(
        phoneRegisterForm.phone,
        phoneRegisterForm.password,
        phoneRegisterForm.code,
        sessionId,
        phoneRegisterForm.nickname || undefined
      );

      if (error) {
        toast.error(error.message || '注册失败');
        return;
      }

      toast.success('注册成功');
      closeLoginDialog();
      setPhoneRegisterForm({
        phone: '',
        code: '',
        password: '',
        confirmPassword: '',
        nickname: '',
      });
      setSessionId('');
    } catch (error) {
      toast.error('注册失败,请重试');
    } finally {
      setLoading(false);
    }
  };

  // 邮箱登录
  const handleEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!emailLoginForm.email || !emailLoginForm.password) {
      toast.error('请填写完整信息');
      return;
    }

    setLoading(true);

    try {
      const { error } = await signInWithEmail(emailLoginForm.email, emailLoginForm.password);

      if (error) {
        toast.error(error.message || '登录失败');
        return;
      }

      toast.success('登录成功');
      closeLoginDialog();
      setEmailLoginForm({ email: '', password: '' });
    } catch (error) {
      toast.error('登录失败,请重试');
    } finally {
      setLoading(false);
    }
  };

  // 邮箱注册
  const handleEmailRegister = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!emailRegisterForm.email || !emailRegisterForm.password || !emailRegisterForm.nickname) {
      toast.error('请填写完整信息');
      return;
    }

    if (emailRegisterForm.password !== emailRegisterForm.confirmPassword) {
      toast.error('两次输入的密码不一致');
      return;
    }

    if (emailRegisterForm.password.length < 6) {
      toast.error('密码长度至少为6位');
      return;
    }

    setLoading(true);

    try {
      const { error } = await signUpWithEmail(
        emailRegisterForm.email,
        emailRegisterForm.password,
        emailRegisterForm.nickname
      );

      if (error) {
        toast.error(error.message || '注册失败');
        return;
      }

      toast.success('注册成功,请查收验证邮件');
      closeLoginDialog();
      setEmailRegisterForm({
        email: '',
        password: '',
        confirmPassword: '',
        nickname: '',
      });
    } catch (error) {
      toast.error('注册失败,请重试');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={closeLoginDialog}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <div className="flex justify-center mb-2">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-secondary">
              <span className="text-xl font-bold text-white">技</span>
            </div>
          </div>
          <DialogTitle className="text-center gradient-text">欢迎来到技遇</DialogTitle>
          <DialogDescription className="text-center">大学生技能交换平台</DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="phone-login" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="phone-login">手机登录</TabsTrigger>
            <TabsTrigger value="email-login">邮箱登录</TabsTrigger>
          </TabsList>

          {/* 手机号登录 */}
          <TabsContent value="phone-login">
            <Tabs defaultValue="login" className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-4">
                <TabsTrigger value="login">登录</TabsTrigger>
                <TabsTrigger value="register">注册</TabsTrigger>
              </TabsList>

              <TabsContent value="login">
                <form onSubmit={handlePhoneLogin} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="phone-login-phone">手机号</Label>
                    <Input
                      id="phone-login-phone"
                      type="tel"
                      placeholder="请输入手机号"
                      value={phoneLoginForm.phone}
                      onChange={(e) =>
                        setPhoneLoginForm({ ...phoneLoginForm, phone: e.target.value })
                      }
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone-login-password">密码</Label>
                    <Input
                      id="phone-login-password"
                      type="password"
                      placeholder="请输入密码"
                      value={phoneLoginForm.password}
                      onChange={(e) =>
                        setPhoneLoginForm({ ...phoneLoginForm, password: e.target.value })
                      }
                      required
                    />
                  </div>
                  <Button type="submit" className="w-full" disabled={loading}>
                    {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    登录
                  </Button>
                </form>
              </TabsContent>

              <TabsContent value="register">
                <form onSubmit={handlePhoneRegister} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="phone-register-phone">手机号</Label>
                    <Input
                      id="phone-register-phone"
                      type="tel"
                      placeholder="请输入手机号"
                      value={phoneRegisterForm.phone}
                      onChange={(e) =>
                        setPhoneRegisterForm({ ...phoneRegisterForm, phone: e.target.value })
                      }
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone-register-code">验证码</Label>
                    <div className="flex gap-2">
                      <Input
                        id="phone-register-code"
                        type="text"
                        placeholder="请输入验证码"
                        value={phoneRegisterForm.code}
                        onChange={(e) =>
                          setPhoneRegisterForm({ ...phoneRegisterForm, code: e.target.value })
                        }
                        required
                      />
                      <Button
                        type="button"
                        variant="outline"
                        onClick={handleSendCode}
                        disabled={sendingCode || countdown > 0}
                        className="shrink-0 w-28"
                      >
                        {sendingCode && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        {countdown > 0 ? `${countdown}秒` : '获取验证码'}
                      </Button>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone-register-nickname">昵称(可选)</Label>
                    <Input
                      id="phone-register-nickname"
                      type="text"
                      placeholder="请输入昵称"
                      value={phoneRegisterForm.nickname}
                      onChange={(e) =>
                        setPhoneRegisterForm({ ...phoneRegisterForm, nickname: e.target.value })
                      }
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone-register-password">密码</Label>
                    <Input
                      id="phone-register-password"
                      type="password"
                      placeholder="请输入密码(至少6位)"
                      value={phoneRegisterForm.password}
                      onChange={(e) =>
                        setPhoneRegisterForm({ ...phoneRegisterForm, password: e.target.value })
                      }
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone-register-confirm">确认密码</Label>
                    <Input
                      id="phone-register-confirm"
                      type="password"
                      placeholder="请再次输入密码"
                      value={phoneRegisterForm.confirmPassword}
                      onChange={(e) =>
                        setPhoneRegisterForm({
                          ...phoneRegisterForm,
                          confirmPassword: e.target.value,
                        })
                      }
                      required
                    />
                  </div>
                  <Button type="submit" className="w-full" disabled={loading}>
                    {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    注册
                  </Button>
                </form>
              </TabsContent>
            </Tabs>
          </TabsContent>

          {/* 邮箱登录 */}
          <TabsContent value="email-login">
            <Tabs defaultValue="login" className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-4">
                <TabsTrigger value="login">登录</TabsTrigger>
                <TabsTrigger value="register">注册</TabsTrigger>
              </TabsList>

              <TabsContent value="login">
                <form onSubmit={handleEmailLogin} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="email-login-email">邮箱</Label>
                    <Input
                      id="email-login-email"
                      type="email"
                      placeholder="请输入邮箱"
                      value={emailLoginForm.email}
                      onChange={(e) =>
                        setEmailLoginForm({ ...emailLoginForm, email: e.target.value })
                      }
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email-login-password">密码</Label>
                    <Input
                      id="email-login-password"
                      type="password"
                      placeholder="请输入密码"
                      value={emailLoginForm.password}
                      onChange={(e) =>
                        setEmailLoginForm({ ...emailLoginForm, password: e.target.value })
                      }
                      required
                    />
                  </div>
                  <Button type="submit" className="w-full" disabled={loading}>
                    {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    登录
                  </Button>
                </form>
              </TabsContent>

              <TabsContent value="register">
                <form onSubmit={handleEmailRegister} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="email-register-email">邮箱</Label>
                    <Input
                      id="email-register-email"
                      type="email"
                      placeholder="请输入邮箱"
                      value={emailRegisterForm.email}
                      onChange={(e) =>
                        setEmailRegisterForm({ ...emailRegisterForm, email: e.target.value })
                      }
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email-register-nickname">昵称</Label>
                    <Input
                      id="email-register-nickname"
                      type="text"
                      placeholder="请输入昵称"
                      value={emailRegisterForm.nickname}
                      onChange={(e) =>
                        setEmailRegisterForm({ ...emailRegisterForm, nickname: e.target.value })
                      }
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email-register-password">密码</Label>
                    <Input
                      id="email-register-password"
                      type="password"
                      placeholder="请输入密码(至少6位)"
                      value={emailRegisterForm.password}
                      onChange={(e) =>
                        setEmailRegisterForm({ ...emailRegisterForm, password: e.target.value })
                      }
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email-register-confirm">确认密码</Label>
                    <Input
                      id="email-register-confirm"
                      type="password"
                      placeholder="请再次输入密码"
                      value={emailRegisterForm.confirmPassword}
                      onChange={(e) =>
                        setEmailRegisterForm({
                          ...emailRegisterForm,
                          confirmPassword: e.target.value,
                        })
                      }
                      required
                    />
                  </div>
                  <Button type="submit" className="w-full" disabled={loading}>
                    {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    注册
                  </Button>
                  <p className="text-xs text-muted-foreground text-center">
                    注册后请查收验证邮件完成激活
                  </p>
                </form>
              </TabsContent>
            </Tabs>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
