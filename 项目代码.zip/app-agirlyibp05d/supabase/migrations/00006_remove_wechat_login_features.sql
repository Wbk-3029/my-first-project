-- 删除微信登录相关表和字段
DROP TABLE IF EXISTS wechat_login_states;

-- 删除profiles表的wechat_id字段
ALTER TABLE profiles DROP COLUMN IF EXISTS wechat_id;