import { Link, useLocation } from 'react-router-dom';
import { Home, MessageSquare, Bell, User } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useEffect, useState } from 'react';
import { getUnreadNotificationCount } from '@/db/api';
import { useAuth } from '@/contexts/AuthContext';

export function BottomNav() {
  const location = useLocation();
  const { user } = useAuth();
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    if (user) {
      loadUnreadCount();
      // 每30秒刷新一次未读数
      const interval = setInterval(loadUnreadCount, 30000);
      return () => clearInterval(interval);
    }
  }, [user]);

  const loadUnreadCount = async () => {
    try {
      const count = await getUnreadNotificationCount();
      setUnreadCount(count);
    } catch (error) {
      console.error('获取未读消息数失败:', error);
    }
  };

  const navItems = [
    {
      label: '技能广场',
      icon: Home,
      path: '/skills',
      activePaths: ['/skills', '/skill'],
    },
    {
      label: '社区论坛',
      icon: MessageSquare,
      path: '/forum',
      activePaths: ['/forum'],
    },
    {
      label: '消息',
      icon: Bell,
      path: '/notifications',
      activePaths: ['/notifications', '/friends', '/friend-requests'],
      badge: unreadCount,
    },
    {
      label: '我的',
      icon: User,
      path: '/profile',
      activePaths: ['/profile', '/my-skills', '/exchange-history', '/favorites', '/settings'],
    },
  ];

  const isActive = (activePaths: string[]) => {
    return activePaths.some((path) => location.pathname.startsWith(path));
  };

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-background border-t border-border md:hidden">
      <div className="flex items-center justify-around h-16 px-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const active = isActive(item.activePaths);

          return (
            <Link
              key={item.path}
              to={item.path}
              className={cn(
                'flex flex-col items-center justify-center flex-1 h-full gap-1 transition-colors relative',
                active
                  ? 'text-primary'
                  : 'text-muted-foreground hover:text-foreground'
              )}
            >
              <div className="relative">
                <Icon className={cn('h-5 w-5', active && 'stroke-[2.5]')} />
                {item.badge && item.badge > 0 && (
                  <div className="absolute -top-1 -right-1 h-4 min-w-4 px-1 bg-destructive text-white text-xs rounded-full flex items-center justify-center">
                    {item.badge > 99 ? '99+' : item.badge}
                  </div>
                )}
              </div>
              <span className={cn('text-xs', active && 'font-semibold')}>{item.label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
