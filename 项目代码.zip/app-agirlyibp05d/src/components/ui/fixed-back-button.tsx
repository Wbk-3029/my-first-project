import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';

interface FixedBackButtonProps {
  onBack?: () => void;
  className?: string;
}

export function FixedBackButton({ onBack, className = '' }: FixedBackButtonProps) {
  const navigate = useNavigate();

  const handleBack = () => {
    if (onBack) {
      onBack();
    } else {
      navigate(-1);
    }
  };

  return (
    <Button
      variant="outline"
      size="icon"
      onClick={handleBack}
      className={`fixed top-20 left-4 z-50 shadow-lg bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 ${className}`}
    >
      <ArrowLeft className="h-5 w-5" />
    </Button>
  );
}
