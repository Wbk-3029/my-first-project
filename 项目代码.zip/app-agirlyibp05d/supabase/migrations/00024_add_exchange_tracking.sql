-- 为exchanges表添加完成时间和开始时间字段
ALTER TABLE exchanges 
ADD COLUMN IF NOT EXISTS start_time timestamptz,
ADD COLUMN IF NOT EXISTS completed_at timestamptz;

-- 添加注释
COMMENT ON COLUMN exchanges.start_time IS '交换开始时间（约定时间）';
COMMENT ON COLUMN exchanges.completed_at IS '交换完成时间';

-- 创建RPC函数：完成交换
CREATE OR REPLACE FUNCTION complete_exchange(
  p_exchange_id uuid
) RETURNS json AS $$
DECLARE
  v_exchange record;
  v_result json;
BEGIN
  -- 获取交换信息
  SELECT * INTO v_exchange
  FROM exchanges
  WHERE id = p_exchange_id
    AND (initiator_id = auth.uid() OR receiver_id = auth.uid())
    AND status = 'in_progress';

  IF v_exchange IS NULL THEN
    RAISE EXCEPTION '交换不存在或无权操作';
  END IF;

  -- 更新交换状态
  UPDATE exchanges
  SET status = 'completed',
      completed_at = now(),
      updated_at = now()
  WHERE id = p_exchange_id;

  -- 增加双方的交换次数
  UPDATE profiles
  SET exchange_count = exchange_count + 1
  WHERE id IN (v_exchange.initiator_id, v_exchange.receiver_id);

  -- 奖励双方积分（完成交换奖励）
  UPDATE integral_accounts
  SET balance = balance + 10,
      total_earned = total_earned + 10,
      updated_at = now()
  WHERE user_id IN (v_exchange.initiator_id, v_exchange.receiver_id);

  -- 记录积分交易
  INSERT INTO integral_transactions (user_id, amount, type, reason, related_id)
  VALUES
    (v_exchange.initiator_id, 10, 'income', '完成交换奖励', p_exchange_id),
    (v_exchange.receiver_id, 10, 'income', '完成交换奖励', p_exchange_id);

  SELECT json_build_object(
    'success', true,
    'message', '交换已完成，获得10积分奖励'
  ) INTO v_result;

  RETURN v_result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 创建RPC函数：获取交换统计
CREATE OR REPLACE FUNCTION get_exchange_stats()
RETURNS json AS $$
DECLARE
  v_pending_count int;
  v_in_progress_count int;
  v_completed_count int;
  v_result json;
BEGIN
  -- 获取待处理数量（收到的申请）
  SELECT COUNT(*) INTO v_pending_count
  FROM exchange_requests
  WHERE to_user_id = auth.uid()
    AND status = 'pending';

  -- 获取进行中数量
  SELECT COUNT(*) INTO v_in_progress_count
  FROM exchanges
  WHERE (initiator_id = auth.uid() OR receiver_id = auth.uid())
    AND status = 'in_progress';

  -- 获取已完成数量
  SELECT COUNT(*) INTO v_completed_count
  FROM exchanges
  WHERE (initiator_id = auth.uid() OR receiver_id = auth.uid())
    AND status = 'completed';

  SELECT json_build_object(
    'pending', v_pending_count,
    'in_progress', v_in_progress_count,
    'completed', v_completed_count
  ) INTO v_result;

  RETURN v_result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
