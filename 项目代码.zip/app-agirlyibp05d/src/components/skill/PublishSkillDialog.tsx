import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/db/supabase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from 'sonner';
import { Loader2, Plus, X, Image as ImageIcon, Video } from 'lucide-react';
import { createSkill, updateSkillMedia } from '@/db/api';
import type { SkillType } from '@/types';
import { SKILL_TYPE_LABELS, SKILL_TYPE_PRICES } from '@/types';

interface MediaFile {
  file: File;
  preview: string;
  type: 'image' | 'video';
}

interface PublishSkillDialogProps {
  onPublishSuccess?: () => void;
}

export function PublishSkillDialog({ onPublishSuccess }: PublishSkillDialogProps = {}) {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [mediaFiles, setMediaFiles] = useState<MediaFile[]>([]);

  const [formData, setFormData] = useState({
    name: '',
    description: '',
    type: 'normal' as SkillType,
    price: 20,
    required_skills: '',
  });

  const handleTypeChange = (type: SkillType) => {
    setFormData({
      ...formData,
      type,
      price: SKILL_TYPE_PRICES[type],
    });
  };

  const handleMediaChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    
    files.forEach((file) => {
      // 验证文件类型
      const isImage = file.type.startsWith('image/');
      const isVideo = file.type.startsWith('video/');
      
      if (!isImage && !isVideo) {
        toast.error(`${file.name} 不是有效的图片或视频文件`);
        return;
      }

      // 验证文件大小
      const maxSize = isImage ? 1 * 1024 * 1024 : 10 * 1024 * 1024; // 图片1MB, 视频10MB
      if (file.size > maxSize) {
        toast.error(`${file.name} 文件过大,${isImage ? '图片' : '视频'}最大${isImage ? '1MB' : '10MB'}`);
        return;
      }

      // 创建预览
      const preview = URL.createObjectURL(file);
      setMediaFiles((prev) => [
        ...prev,
        {
          file,
          preview,
          type: isImage ? 'image' : 'video',
        },
      ]);
    });

    // 清空input
    e.target.value = '';
  };

  const removeMedia = (index: number) => {
    setMediaFiles((prev) => {
      const newFiles = [...prev];
      URL.revokeObjectURL(newFiles[index].preview);
      newFiles.splice(index, 1);
      return newFiles;
    });
  };

  const uploadMedia = async (skillId: string): Promise<string[]> => {
    const uploadedUrls: string[] = [];

    for (const media of mediaFiles) {
      const fileExt = media.file.name.split('.').pop();
      const fileName = `${user?.id}/${skillId}/${Date.now()}.${fileExt}`;

      const { error: uploadError } = await supabase.storage
        .from('skill-media')
        .upload(fileName, media.file, {
          cacheControl: '3600',
          upsert: false,
        });

      if (uploadError) {
        console.error('上传失败:', uploadError);
        continue;
      }

      const { data: urlData } = supabase.storage
        .from('skill-media')
        .getPublicUrl(fileName);

      uploadedUrls.push(urlData.publicUrl);
    }

    return uploadedUrls;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!user) {
      toast.error('请先登录');
      return;
    }

    if (!formData.name.trim()) {
      toast.error('请输入技能名称');
      return;
    }

    if (!formData.description.trim()) {
      toast.error('请输入技能描述');
      return;
    }

    setLoading(true);

    try {
      const skillId = await createSkill({
        name: formData.name.trim(),
        description: formData.description.trim(),
        type: formData.type,
        price: formData.price,
        required_skills: formData.required_skills.trim() || null,
      });

      // 上传媒体文件
      if (mediaFiles.length > 0) {
        const mediaUrls = await uploadMedia(skillId);
        
        // 更新技能的media字段
        if (mediaUrls.length > 0) {
          await updateSkillMedia(skillId, mediaUrls);
        }
      }

      toast.success('技能发布成功');
      setOpen(false);
      setFormData({
        name: '',
        description: '',
        type: 'normal',
        price: 20,
        required_skills: '',
      });
      setMediaFiles([]);
      
      // 调用回调函数
      if (onPublishSuccess) {
        onPublishSuccess();
      }
      // 清理媒体文件
      mediaFiles.forEach((media) => URL.revokeObjectURL(media.preview));
      setMediaFiles([]);

      // 跳转到技能详情页
      navigate(`/skills/${skillId}`);
    } catch (error) {
      toast.error('发布失败,请重试');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="gap-2">
          <Plus className="h-4 w-4" />
          发布技能
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>发布技能</DialogTitle>
          <DialogDescription>填写技能信息,让更多人发现你的技能</DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">技能名称 *</Label>
            <Input
              id="name"
              placeholder="例如: Python编程入门"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">技能描述 *</Label>
            <Textarea
              id="description"
              placeholder="详细描述你的技能内容、适合人群、能学到什么..."
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              rows={4}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="type">技能类型 *</Label>
            <Select value={formData.type} onValueChange={handleTypeChange}>
              <SelectTrigger id="type">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(SKILL_TYPE_LABELS).map(([key, label]) => (
                  <SelectItem key={key} value={key}>
                    {label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground">
              不同类型的技能有不同的默认价格
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="price">技易点价格</Label>
            <Input
              id="price"
              type="number"
              min="0"
              value={formData.price}
              onChange={(e) => setFormData({ ...formData, price: parseInt(e.target.value) || 0 })}
              required
            />
            <p className="text-xs text-muted-foreground">
              默认价格: {SKILL_TYPE_PRICES[formData.type]} 技易点,可手动调整
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="required_skills">所需技能(可选)</Label>
            <Textarea
              id="required_skills"
              placeholder="如果希望直接交换,请描述你希望换取的技能..."
              value={formData.required_skills}
              onChange={(e) => setFormData({ ...formData, required_skills: e.target.value })}
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label>图片/视频(可选)</Label>
            <div className="space-y-3">
              {/* 媒体预览 */}
              {mediaFiles.length > 0 && (
                <div className="grid grid-cols-2 gap-2">
                  {mediaFiles.map((media, index) => (
                    <div key={index} className="relative group">
                      {media.type === 'image' ? (
                        <img
                          src={media.preview}
                          alt="预览"
                          className="w-full h-32 object-cover rounded-lg border"
                        />
                      ) : (
                        <video
                          src={media.preview}
                          className="w-full h-32 object-cover rounded-lg border"
                          controls
                        />
                      )}
                      <Button
                        type="button"
                        variant="destructive"
                        size="icon"
                        className="absolute top-1 right-1 h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity"
                        onClick={() => removeMedia(index)}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                      <div className="absolute bottom-1 left-1 px-2 py-0.5 bg-black/60 text-white text-xs rounded">
                        {media.type === 'image' ? <ImageIcon className="h-3 w-3" /> : <Video className="h-3 w-3" />}
                      </div>
                    </div>
                  ))}
                </div>
              )}
              
              {/* 上传按钮 */}
              <div>
                <Input
                  id="media-upload"
                  type="file"
                  accept="image/*,video/*"
                  multiple
                  onChange={handleMediaChange}
                  className="hidden"
                />
                <Label
                  htmlFor="media-upload"
                  className="flex items-center justify-center gap-2 h-24 border-2 border-dashed rounded-lg cursor-pointer hover:bg-accent transition-colors"
                >
                  <Plus className="h-5 w-5" />
                  <span className="text-sm">添加图片或视频</span>
                </Label>
                <p className="text-xs text-muted-foreground mt-1">
                  图片最大1MB,视频最大10MB
                </p>
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              取消
            </Button>
            <Button type="submit" disabled={loading}>
              {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              发布
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
