-- 创建好友关系表
CREATE TABLE IF NOT EXISTS friend_relations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  friend_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  status INTEGER DEFAULT 0 CHECK (status IN (0, 1, 2)),
  message TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  agreed_at TIMESTAMPTZ,
  UNIQUE(user_id, friend_id),
  CHECK (user_id != friend_id)
);

-- 创建通知表
CREATE TABLE IF NOT EXISTS notifications (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  type TEXT NOT NULL CHECK (type IN ('friend_request', 'exchange_request', 'system')),
  title TEXT NOT NULL,
  content TEXT,
  related_id UUID,
  is_read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 添加索引
CREATE INDEX IF NOT EXISTS idx_friend_relations_user ON friend_relations(user_id);
CREATE INDEX IF NOT EXISTS idx_friend_relations_friend ON friend_relations(friend_id);
CREATE INDEX IF NOT EXISTS idx_friend_relations_status ON friend_relations(status);
CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_is_read ON notifications(is_read);
CREATE INDEX IF NOT EXISTS idx_notifications_created ON notifications(created_at DESC);

-- 添加RLS策略
ALTER TABLE friend_relations ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

-- friend_relations策略
CREATE POLICY "friend_relations_select" ON friend_relations 
  FOR SELECT USING (auth.uid() = user_id OR auth.uid() = friend_id);

CREATE POLICY "friend_relations_insert" ON friend_relations 
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "friend_relations_update" ON friend_relations 
  FOR UPDATE USING (auth.uid() = friend_id);

CREATE POLICY "friend_relations_delete" ON friend_relations 
  FOR DELETE USING (auth.uid() = user_id OR auth.uid() = friend_id);

-- notifications策略
CREATE POLICY "notifications_select" ON notifications 
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "notifications_insert" ON notifications 
  FOR INSERT WITH CHECK (true);

CREATE POLICY "notifications_update" ON notifications 
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "notifications_delete" ON notifications 
  FOR DELETE USING (auth.uid() = user_id);

-- 创建获取好友列表的函数
CREATE OR REPLACE FUNCTION get_friends(p_user_id UUID)
RETURNS TABLE (
  friend_profile_id UUID,
  friend_nickname TEXT,
  friend_avatar_url TEXT,
  friend_credit_score INTEGER,
  last_message_time TIMESTAMPTZ,
  unread_count BIGINT
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    p.id,
    p.nickname,
    p.avatar_url,
    p.credit_score,
    COALESCE(MAX(m.created_at), fr.agreed_at) as last_message_time,
    COUNT(CASE WHEN m.is_read = false AND m.sender_id != p_user_id THEN 1 END) as unread_count
  FROM friend_relations fr
  JOIN profiles p ON (
    CASE 
      WHEN fr.user_id = p_user_id THEN p.id = fr.friend_id
      ELSE p.id = fr.user_id
    END
  )
  LEFT JOIN messages m ON (
    (m.sender_id = p_user_id AND m.receiver_id = p.id) OR
    (m.sender_id = p.id AND m.receiver_id = p_user_id)
  )
  WHERE (fr.user_id = p_user_id OR fr.friend_id = p_user_id)
    AND fr.status = 1
  GROUP BY p.id, p.nickname, p.avatar_url, p.credit_score, fr.agreed_at
  ORDER BY last_message_time DESC NULLS LAST;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 创建获取未读通知数的函数
CREATE OR REPLACE FUNCTION get_unread_notification_count(p_user_id UUID)
RETURNS INTEGER AS $$
DECLARE
  count INTEGER;
BEGIN
  SELECT COUNT(*)::INTEGER INTO count
  FROM notifications
  WHERE user_id = p_user_id AND is_read = false;
  RETURN count;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 添加注释
COMMENT ON TABLE friend_relations IS '好友关系表';
COMMENT ON TABLE notifications IS '通知表';
COMMENT ON COLUMN friend_relations.status IS '状态: 0待审核, 1已同意, 2已拒绝';
COMMENT ON COLUMN friend_relations.message IS '好友申请附加消息';
COMMENT ON COLUMN notifications.type IS '通知类型: friend_request好友申请, exchange_request交换申请, system系统通知';