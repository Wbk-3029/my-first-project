import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { MainLayout } from '@/components/layouts/MainLayout';
import { PageHeader } from '@/components/layouts/PageHeader';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { EvidenceViewer } from '@/components/violation/EvidenceViewer';
import { getAppeals, getAppealStats } from '@/db/api';
import type { Appeal, AppealStats } from '@/types';
import { useAuth } from '@/contexts/AuthContext';
import { Scale, Clock, CheckCircle, XCircle, ArrowLeft, FileText } from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { zhCN } from 'date-fns/locale';

const VIOLATION_TYPE_LABELS: Record<string, string> = {
  no_show: '爽约',
  false_info: '虚假信息',
  malicious_review: '恶意评价',
  spam: '垃圾信息',
  harassment: '骚扰行为',
  other: '其他违规',
};

const APPEAL_STATUS_LABELS: Record<string, string> = {
  pending: '待处理',
  approved: '申诉成功',
  rejected: '申诉失败',
};

const APPEAL_STATUS_ICONS: Record<string, React.ReactNode> = {
  pending: <Clock className="h-4 w-4" />,
  approved: <CheckCircle className="h-4 w-4" />,
  rejected: <XCircle className="h-4 w-4" />,
};

export default function AppealRecordsPage() {
  const navigate = useNavigate();
  const { profile } = useAuth();
  const [appeals, setAppeals] = useState<Appeal[]>([]);
  const [stats, setStats] = useState<AppealStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('all');

  useEffect(() => {
    if (profile?.id) {
      loadData();
    }
  }, [profile?.id, activeTab]);

  const loadData = async () => {
    if (!profile?.id) return;

    try {
      setLoading(true);
      const [appealsData, statsData] = await Promise.all([
        getAppeals({
          appellantId: profile.id,
          status: activeTab === 'all' ? undefined : activeTab,
        }),
        getAppealStats(profile.id),
      ]);

      setAppeals(appealsData);
      setStats(statsData);
    } catch (error) {
      console.error('加载申诉记录失败:', error);
      toast.error('加载申诉记录失败');
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case 'pending':
        return 'secondary';
      case 'approved':
        return 'default';
      case 'rejected':
        return 'destructive';
      default:
        return 'secondary';
    }
  };

  return (
    <MainLayout>
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate('/profile/violations')}
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <PageHeader title="申诉记录" />
        </div>

        {/* 统计卡片 */}
        {stats && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="pt-6">
                <div className="text-center">
                  <div className="text-2xl font-bold">
                    {stats.total_appeals}
                  </div>
                  <div className="text-sm text-muted-foreground mt-1">
                    总申诉次数
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="text-center">
                  <div className="text-2xl font-bold text-orange-500">
                    {stats.pending_appeals}
                  </div>
                  <div className="text-sm text-muted-foreground mt-1">
                    待处理
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-500">
                    {stats.approved_appeals}
                  </div>
                  <div className="text-sm text-muted-foreground mt-1">
                    申诉成功
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-500">
                    +{stats.total_credit_restored}
                  </div>
                  <div className="text-sm text-muted-foreground mt-1">
                    恢复信用分
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* 申诉记录列表 */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">申诉记录</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="all">全部</TabsTrigger>
                <TabsTrigger value="pending">待处理</TabsTrigger>
                <TabsTrigger value="approved">申诉成功</TabsTrigger>
                <TabsTrigger value="rejected">申诉失败</TabsTrigger>
              </TabsList>

              <TabsContent value={activeTab} className="mt-6">
                {loading ? (
                  <div className="space-y-4">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="space-y-3">
                        <Skeleton className="h-4 w-1/4 bg-muted" />
                        <Skeleton className="h-32 w-full bg-muted" />
                      </div>
                    ))}
                  </div>
                ) : appeals.length === 0 ? (
                  <div className="text-center py-12">
                    <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                    <p className="text-muted-foreground">暂无申诉记录</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {appeals.map((appeal) => (
                      <div
                        key={appeal.id}
                        className="border rounded-lg p-4 space-y-4"
                      >
                        {/* 申诉状态 */}
                        <div className="flex items-center justify-between">
                          <Badge
                            variant={getStatusBadgeVariant(appeal.status)}
                            className="gap-1"
                          >
                            {APPEAL_STATUS_ICONS[appeal.status]}
                            {APPEAL_STATUS_LABELS[appeal.status]}
                          </Badge>
                          <span className="text-xs text-muted-foreground">
                            {format(
                              new Date(appeal.created_at),
                              'yyyy-MM-dd HH:mm',
                              { locale: zhCN }
                            )}
                          </span>
                        </div>

                        {/* 违规信息 */}
                        {appeal.violation_record && (
                          <div className="bg-muted p-3 rounded-lg space-y-2 text-sm">
                            <div className="flex items-center justify-between">
                              <span className="text-muted-foreground">
                                违规类型：
                              </span>
                              <span className="font-medium">
                                {VIOLATION_TYPE_LABELS[appeal.violation_record.type]}
                              </span>
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="text-muted-foreground">
                                扣除信用分：
                              </span>
                              <span className="font-medium text-destructive">
                                -{appeal.violation_record.credit_deducted}分
                              </span>
                            </div>
                            <div className="pt-2 border-t">
                              <p className="text-muted-foreground mb-1">
                                违规描述：
                              </p>
                              <p className="text-foreground">
                                {appeal.violation_record.description}
                              </p>
                            </div>
                          </div>
                        )}

                        {/* 申诉理由 */}
                        <div className="space-y-2">
                          <p className="text-sm font-medium">申诉理由：</p>
                          <p className="text-sm text-muted-foreground">
                            {appeal.reason}
                          </p>
                        </div>

                        {/* 申诉证据 */}
                        {appeal.evidence && appeal.evidence.length > 0 && (
                          <EvidenceViewer evidence={appeal.evidence} />
                        )}

                        {/* 处理结果 */}
                        {appeal.handler_note && (
                          <div className="bg-muted p-3 rounded-lg space-y-2 text-sm">
                            <p className="font-medium">处理结果：</p>
                            <p className="text-muted-foreground">
                              {appeal.handler_note}
                            </p>
                            {appeal.handled_at && (
                              <p className="text-xs text-muted-foreground pt-2 border-t">
                                处理时间：
                                {format(
                                  new Date(appeal.handled_at),
                                  'yyyy-MM-dd HH:mm',
                                  { locale: zhCN }
                                )}
                              </p>
                            )}
                          </div>
                        )}

                        {/* 申诉成功提示 */}
                        {appeal.status === 'approved' && appeal.violation_record && (
                          <div className="bg-green-50 dark:bg-green-950/20 border border-green-200 dark:border-green-800 p-3 rounded-lg text-sm">
                            <p className="text-green-900 dark:text-green-100 font-medium">
                              ✓ 申诉成功，已恢复{appeal.violation_record.credit_deducted}信用分
                            </p>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {/* 温馨提示 */}
        <Card className="border-blue-200 bg-blue-50 dark:bg-blue-950/20">
          <CardContent className="pt-6">
            <div className="flex gap-3">
              <Scale className="h-5 w-5 text-blue-500 shrink-0 mt-0.5" />
              <div className="space-y-2 text-sm">
                <p className="font-medium text-blue-900 dark:text-blue-100">
                  申诉规则
                </p>
                <ul className="space-y-1 text-blue-800 dark:text-blue-200">
                  <li>• 每条违规记录只能申诉一次</li>
                  <li>• 申诉时限：违规处理后7天内</li>
                  <li>• 申诉处理时间：3个工作日内</li>
                  <li>• 申诉成功将恢复扣除的信用分</li>
                  <li>• 虚假申诉将受到更严厉的处罚</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}
