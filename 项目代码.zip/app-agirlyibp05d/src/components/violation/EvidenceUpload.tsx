import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/db/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { Upload, X, FileText, Image as ImageIcon, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

interface EvidenceFile {
  name: string;
  url: string;
  type: string;
  size: number;
}

interface EvidenceUploadProps {
  files: EvidenceFile[];
  onChange: (files: EvidenceFile[]) => void;
  maxFiles?: number;
  maxFileSize?: number; // in bytes
}

const ALLOWED_TYPES = [
  'image/jpeg',
  'image/jpg',
  'image/png',
  'image/gif',
  'image/webp',
  'application/pdf',
];

const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB
const MAX_FILES = 5;

export function EvidenceUpload({
  files,
  onChange,
  maxFiles = MAX_FILES,
  maxFileSize = MAX_FILE_SIZE,
}: EvidenceUploadProps) {
  const { profile } = useAuth();
  const [uploading, setUploading] = useState(false);

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  const validateFile = (file: File): string | null => {
    if (!ALLOWED_TYPES.includes(file.type)) {
      return '不支持的文件格式，仅支持图片（JPG、PNG、GIF、WebP）和PDF';
    }
    if (file.size > maxFileSize) {
      return `文件大小超过限制（最大${formatFileSize(maxFileSize)}）`;
    }
    return null;
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(e.target.files || []);
    if (selectedFiles.length === 0) return;

    if (files.length + selectedFiles.length > maxFiles) {
      toast.error(`最多只能上传${maxFiles}个文件`);
      return;
    }

    setUploading(true);
    const newFiles: EvidenceFile[] = [];

    try {
      for (const file of selectedFiles) {
        // 验证文件
        const error = validateFile(file);
        if (error) {
          toast.error(`${file.name}: ${error}`);
          continue;
        }

        // 生成文件路径
        const timestamp = Date.now();
        const randomStr = Math.random().toString(36).substring(2, 8);
        const fileExt = file.name.split('.').pop();
        const fileName = `${timestamp}_${randomStr}.${fileExt}`;
        const filePath = `${profile?.id}/${fileName}`;

        // 上传文件
        const { data, error: uploadError } = await supabase.storage
          .from('appeal-evidence')
          .upload(filePath, file, {
            contentType: file.type,
            upsert: false,
          });

        if (uploadError) {
          console.error('上传文件失败:', uploadError);
          toast.error(`${file.name}: 上传失败`);
          continue;
        }

        // 获取公开URL
        const { data: urlData } = supabase.storage
          .from('appeal-evidence')
          .getPublicUrl(data.path);

        newFiles.push({
          name: file.name,
          url: urlData.publicUrl,
          type: file.type,
          size: file.size,
        });
      }

      if (newFiles.length > 0) {
        onChange([...files, ...newFiles]);
        toast.success(`成功上传${newFiles.length}个文件`);
      }
    } catch (error) {
      console.error('上传文件失败:', error);
      toast.error('上传文件失败');
    } finally {
      setUploading(false);
      // 重置input
      e.target.value = '';
    }
  };

  const handleRemoveFile = async (index: number) => {
    const file = files[index];
    
    try {
      // 从URL中提取文件路径
      const url = new URL(file.url);
      const pathParts = url.pathname.split('/');
      const filePath = pathParts.slice(-2).join('/'); // user_id/filename

      // 从Storage中删除文件
      const { error } = await supabase.storage
        .from('appeal-evidence')
        .remove([filePath]);

      if (error) {
        console.error('删除文件失败:', error);
        toast.error('删除文件失败');
        return;
      }

      // 从列表中移除
      const newFiles = files.filter((_, i) => i !== index);
      onChange(newFiles);
      toast.success('文件已删除');
    } catch (error) {
      console.error('删除文件失败:', error);
      toast.error('删除文件失败');
    }
  };

  const getFileIcon = (type: string) => {
    if (type.startsWith('image/')) {
      return <ImageIcon className="h-4 w-4" />;
    }
    return <FileText className="h-4 w-4" />;
  };

  return (
    <div className="space-y-3">
      {/* 上传按钮 */}
      <div>
        <input
          type="file"
          id="evidence-upload"
          className="hidden"
          accept={ALLOWED_TYPES.join(',')}
          multiple
          onChange={handleFileSelect}
          disabled={uploading || files.length >= maxFiles}
        />
        <label htmlFor="evidence-upload">
          <Button
            type="button"
            variant="outline"
            size="sm"
            className="gap-2 cursor-pointer"
            disabled={uploading || files.length >= maxFiles}
            asChild
          >
            <span>
              {uploading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  上传中...
                </>
              ) : (
                <>
                  <Upload className="h-4 w-4" />
                  上传证据文件
                </>
              )}
            </span>
          </Button>
        </label>
        <p className="text-xs text-muted-foreground mt-1">
          支持图片（JPG、PNG、GIF、WebP）和PDF，最多{maxFiles}个文件，每个文件不超过
          {formatFileSize(maxFileSize)}
        </p>
      </div>

      {/* 文件列表 */}
      {files.length > 0 && (
        <div className="space-y-2">
          {files.map((file, index) => (
            <div
              key={index}
              className="flex items-center gap-3 p-3 border rounded-lg bg-muted/50"
            >
              <div className="shrink-0 text-muted-foreground">
                {getFileIcon(file.type)}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{file.name}</p>
                <p className="text-xs text-muted-foreground">
                  {formatFileSize(file.size)}
                </p>
              </div>
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="shrink-0 h-8 w-8"
                onClick={() => handleRemoveFile(index)}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          ))}
        </div>
      )}

      {/* 文件数量提示 */}
      {files.length > 0 && (
        <p className="text-xs text-muted-foreground">
          已上传 {files.length}/{maxFiles} 个文件
        </p>
      )}
    </div>
  );
}
