-- 创建改期申请表
CREATE TABLE IF NOT EXISTS reschedule_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  exchange_id uuid NOT NULL REFERENCES exchanges(id) ON DELETE CASCADE,
  requester_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  old_start_time timestamptz NOT NULL,
  new_start_time timestamptz NOT NULL,
  reason text NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 创建索引
CREATE INDEX IF NOT EXISTS idx_reschedule_requests_exchange ON reschedule_requests(exchange_id);
CREATE INDEX IF NOT EXISTS idx_reschedule_requests_requester ON reschedule_requests(requester_id);
CREATE INDEX IF NOT EXISTS idx_reschedule_requests_status ON reschedule_requests(status);

-- 添加注释
COMMENT ON TABLE reschedule_requests IS '改期申请表';
COMMENT ON COLUMN reschedule_requests.old_start_time IS '原开始时间';
COMMENT ON COLUMN reschedule_requests.new_start_time IS '新开始时间';
COMMENT ON COLUMN reschedule_requests.reason IS '改期原因';
COMMENT ON COLUMN reschedule_requests.status IS '状态：pending-待处理, approved-已同意, rejected-已拒绝';

-- RLS策略
ALTER TABLE reschedule_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "用户可以查看相关的改期申请"
  ON reschedule_requests FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM exchanges e
      WHERE e.id = reschedule_requests.exchange_id
        AND (e.initiator_id = auth.uid() OR e.receiver_id = auth.uid())
    )
  );

CREATE POLICY "用户可以创建改期申请"
  ON reschedule_requests FOR INSERT
  WITH CHECK (auth.uid() = requester_id);

CREATE POLICY "用户可以更新改期申请状态"
  ON reschedule_requests FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM exchanges e
      WHERE e.id = reschedule_requests.exchange_id
        AND (e.initiator_id = auth.uid() OR e.receiver_id = auth.uid())
    )
  );

-- 创建未履约举报表
CREATE TABLE IF NOT EXISTS breach_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  exchange_id uuid NOT NULL REFERENCES exchanges(id) ON DELETE CASCADE,
  reporter_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  reported_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  evidence text NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'resolved', 'rejected')),
  resolution text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 创建索引
CREATE INDEX IF NOT EXISTS idx_breach_reports_exchange ON breach_reports(exchange_id);
CREATE INDEX IF NOT EXISTS idx_breach_reports_reporter ON breach_reports(reporter_id);
CREATE INDEX IF NOT EXISTS idx_breach_reports_reported ON breach_reports(reported_id);
CREATE INDEX IF NOT EXISTS idx_breach_reports_status ON breach_reports(status);

-- 添加注释
COMMENT ON TABLE breach_reports IS '未履约举报表';
COMMENT ON COLUMN breach_reports.evidence IS '证据（如聊天记录）';
COMMENT ON COLUMN breach_reports.status IS '状态：pending-待处理, processing-处理中, resolved-已解决, rejected-已驳回';
COMMENT ON COLUMN breach_reports.resolution IS '处理结果';

-- RLS策略
ALTER TABLE breach_reports ENABLE ROW LEVEL SECURITY;

CREATE POLICY "用户可以查看相关的举报"
  ON breach_reports FOR SELECT
  USING (auth.uid() = reporter_id OR auth.uid() = reported_id);

CREATE POLICY "用户可以创建举报"
  ON breach_reports FOR INSERT
  WITH CHECK (auth.uid() = reporter_id);

-- 创建RPC函数：检查时间冲突
CREATE OR REPLACE FUNCTION check_time_conflict(
  p_user_id uuid,
  p_start_time timestamptz,
  p_duration numeric
) RETURNS json AS $$
DECLARE
  v_end_time timestamptz;
  v_conflict_count int;
  v_result json;
BEGIN
  -- 计算结束时间
  v_end_time := p_start_time + (p_duration || ' hours')::interval;

  -- 检查是否有冲突的交换
  SELECT COUNT(*) INTO v_conflict_count
  FROM exchanges e
  WHERE (e.initiator_id = p_user_id OR e.receiver_id = p_user_id)
    AND e.status IN ('in_progress', 'accepted')
    AND e.start_time IS NOT NULL
    AND (
      -- 新时间段的开始时间在现有时间段内
      (p_start_time >= e.start_time AND p_start_time < e.start_time + (e.points_amount || ' hours')::interval)
      OR
      -- 新时间段的结束时间在现有时间段内
      (v_end_time > e.start_time AND v_end_time <= e.start_time + (e.points_amount || ' hours')::interval)
      OR
      -- 新时间段包含现有时间段
      (p_start_time <= e.start_time AND v_end_time >= e.start_time + (e.points_amount || ' hours')::interval)
    );

  SELECT json_build_object(
    'has_conflict', v_conflict_count > 0,
    'conflict_count', v_conflict_count
  ) INTO v_result;

  RETURN v_result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 创建RPC函数：创建改期申请
CREATE OR REPLACE FUNCTION create_reschedule_request(
  p_exchange_id uuid,
  p_new_start_time timestamptz,
  p_reason text
) RETURNS json AS $$
DECLARE
  v_exchange record;
  v_requester_id uuid;
  v_other_user_id uuid;
  v_request_id uuid;
  v_result json;
BEGIN
  v_requester_id := auth.uid();

  -- 获取交换信息
  SELECT * INTO v_exchange
  FROM exchanges
  WHERE id = p_exchange_id
    AND (initiator_id = v_requester_id OR receiver_id = v_requester_id)
    AND status = 'in_progress';

  IF v_exchange IS NULL THEN
    RAISE EXCEPTION '交换不存在或无权操作';
  END IF;

  -- 检查是否已有待处理的改期申请
  IF EXISTS (
    SELECT 1 FROM reschedule_requests
    WHERE exchange_id = p_exchange_id AND status = 'pending'
  ) THEN
    RAISE EXCEPTION '已有待处理的改期申请';
  END IF;

  -- 获取对方用户ID
  IF v_exchange.initiator_id = v_requester_id THEN
    v_other_user_id := v_exchange.receiver_id;
  ELSE
    v_other_user_id := v_exchange.initiator_id;
  END IF;

  -- 检查对方在新时间段是否有冲突
  DECLARE
    v_conflict_check json;
  BEGIN
    SELECT check_time_conflict(
      v_other_user_id,
      p_new_start_time,
      EXTRACT(EPOCH FROM (v_exchange.start_time + interval '1 hour' - v_exchange.start_time)) / 3600
    ) INTO v_conflict_check;

    IF (v_conflict_check->>'has_conflict')::boolean THEN
      RAISE EXCEPTION '对方在该时间段有其他交换安排';
    END IF;
  END;

  -- 创建改期申请
  INSERT INTO reschedule_requests (
    exchange_id,
    requester_id,
    old_start_time,
    new_start_time,
    reason,
    status
  ) VALUES (
    p_exchange_id,
    v_requester_id,
    v_exchange.start_time,
    p_new_start_time,
    p_reason,
    'pending'
  ) RETURNING id INTO v_request_id;

  SELECT json_build_object(
    'success', true,
    'request_id', v_request_id,
    'message', '改期申请已发送'
  ) INTO v_result;

  RETURN v_result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 创建RPC函数：处理改期申请
CREATE OR REPLACE FUNCTION handle_reschedule_request(
  p_request_id uuid,
  p_action text
) RETURNS json AS $$
DECLARE
  v_request record;
  v_exchange record;
  v_result json;
BEGIN
  -- 检查action参数
  IF p_action NOT IN ('approve', 'reject') THEN
    RAISE EXCEPTION '无效的操作';
  END IF;

  -- 获取改期申请信息
  SELECT * INTO v_request
  FROM reschedule_requests
  WHERE id = p_request_id
    AND status = 'pending';

  IF v_request IS NULL THEN
    RAISE EXCEPTION '改期申请不存在或已处理';
  END IF;

  -- 获取交换信息
  SELECT * INTO v_exchange
  FROM exchanges
  WHERE id = v_request.exchange_id
    AND (initiator_id = auth.uid() OR receiver_id = auth.uid())
    AND auth.uid() != v_request.requester_id;

  IF v_exchange IS NULL THEN
    RAISE EXCEPTION '无权处理此改期申请';
  END IF;

  IF p_action = 'approve' THEN
    -- 更新改期申请状态
    UPDATE reschedule_requests
    SET status = 'approved', updated_at = now()
    WHERE id = p_request_id;

    -- 更新交换时间
    UPDATE exchanges
    SET start_time = v_request.new_start_time, updated_at = now()
    WHERE id = v_request.exchange_id;

    SELECT json_build_object(
      'success', true,
      'message', '已同意改期申请'
    ) INTO v_result;
  ELSE
    -- 更新改期申请状态
    UPDATE reschedule_requests
    SET status = 'rejected', updated_at = now()
    WHERE id = p_request_id;

    SELECT json_build_object(
      'success', true,
      'message', '已拒绝改期申请'
    ) INTO v_result;
  END IF;

  RETURN v_result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 创建RPC函数：创建未履约举报
CREATE OR REPLACE FUNCTION create_breach_report(
  p_exchange_id uuid,
  p_reported_id uuid,
  p_evidence text
) RETURNS json AS $$
DECLARE
  v_exchange record;
  v_reporter_id uuid;
  v_report_id uuid;
  v_result json;
BEGIN
  v_reporter_id := auth.uid();

  -- 获取交换信息
  SELECT * INTO v_exchange
  FROM exchanges
  WHERE id = p_exchange_id
    AND (initiator_id = v_reporter_id OR receiver_id = v_reporter_id)
    AND status = 'in_progress';

  IF v_exchange IS NULL THEN
    RAISE EXCEPTION '交换不存在或无权操作';
  END IF;

  -- 检查是否已举报
  IF EXISTS (
    SELECT 1 FROM breach_reports
    WHERE exchange_id = p_exchange_id AND reporter_id = v_reporter_id
  ) THEN
    RAISE EXCEPTION '你已经举报过此次交换';
  END IF;

  -- 检查是否在约定时间后15分钟
  IF v_exchange.start_time IS NULL OR now() < v_exchange.start_time + interval '15 minutes' THEN
    RAISE EXCEPTION '只能在约定时间后15分钟举报未履约';
  END IF;

  -- 创建举报
  INSERT INTO breach_reports (
    exchange_id,
    reporter_id,
    reported_id,
    evidence,
    status
  ) VALUES (
    p_exchange_id,
    v_reporter_id,
    p_reported_id,
    p_evidence,
    'pending'
  ) RETURNING id INTO v_report_id;

  SELECT json_build_object(
    'success', true,
    'report_id', v_report_id,
    'message', '举报已提交，平台将尽快处理'
  ) INTO v_result;

  RETURN v_result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
