-- 为所有现有用户初始化积分账户
INSERT INTO user_integral (user_id)
SELECT id FROM auth.users
WHERE id NOT IN (SELECT user_id FROM user_integral)
ON CONFLICT (user_id) DO NOTHING;

-- 为所有现有用户初始化信用账户
INSERT INTO user_credit (user_id)
SELECT id FROM auth.users
WHERE id NOT IN (SELECT user_id FROM user_credit)
ON CONFLICT (user_id) DO NOTHING;

-- 为所有现有用户初始化连续学习记录
INSERT INTO learning_streaks (user_id)
SELECT id FROM auth.users
WHERE id NOT IN (SELECT user_id FROM learning_streaks)
ON CONFLICT (user_id) DO NOTHING;