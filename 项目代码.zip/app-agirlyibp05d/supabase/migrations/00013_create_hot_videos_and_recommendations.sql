-- 创建热门视频表
CREATE TABLE IF NOT EXISTS hot_videos (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title TEXT NOT NULL,
  cover_image TEXT NOT NULL,
  video_url TEXT NOT NULL,
  publisher_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  view_count INTEGER DEFAULT 0,
  like_count INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 创建推荐内容表
CREATE TABLE IF NOT EXISTS recommendations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title TEXT NOT NULL,
  cover_image TEXT NOT NULL,
  description TEXT,
  link TEXT NOT NULL,
  is_paid BOOLEAN DEFAULT FALSE,
  sort_weight INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 添加索引
CREATE INDEX IF NOT EXISTS idx_hot_videos_publisher ON hot_videos(publisher_id);
CREATE INDEX IF NOT EXISTS idx_hot_videos_created ON hot_videos(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_recommendations_paid ON recommendations(is_paid, sort_weight DESC);

-- 添加RLS策略
ALTER TABLE hot_videos ENABLE ROW LEVEL SECURITY;
ALTER TABLE recommendations ENABLE ROW LEVEL SECURITY;

-- 热门视频：所有人可读
CREATE POLICY "hot_videos_select" ON hot_videos FOR SELECT USING (true);

-- 热门视频：发布者可增删改
CREATE POLICY "hot_videos_insert" ON hot_videos FOR INSERT 
  WITH CHECK (auth.uid() = publisher_id);

CREATE POLICY "hot_videos_update" ON hot_videos FOR UPDATE 
  USING (auth.uid() = publisher_id);

CREATE POLICY "hot_videos_delete" ON hot_videos FOR DELETE 
  USING (auth.uid() = publisher_id);

-- 推荐内容：所有人可读
CREATE POLICY "recommendations_select" ON recommendations FOR SELECT USING (true);

-- 推荐内容：仅管理员可增删改（暂时允许所有认证用户，后续可改为管理员角色）
CREATE POLICY "recommendations_insert" ON recommendations FOR INSERT 
  WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "recommendations_update" ON recommendations FOR UPDATE 
  USING (auth.uid() IS NOT NULL);

CREATE POLICY "recommendations_delete" ON recommendations FOR DELETE 
  USING (auth.uid() IS NOT NULL);

-- 添加注释
COMMENT ON TABLE hot_videos IS '热门视频表';
COMMENT ON TABLE recommendations IS '推荐内容表';
COMMENT ON COLUMN recommendations.is_paid IS '是否为付费推荐';
COMMENT ON COLUMN recommendations.sort_weight IS '排序权重，数值越大越靠前';