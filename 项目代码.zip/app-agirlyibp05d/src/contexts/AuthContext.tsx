import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import { supabase } from '@/db/supabase';
import type { User } from '@supabase/supabase-js';
import type { Profile } from '@/types';
import { toast } from 'sonner';

export async function getProfile(userId: string): Promise<Profile | null> {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .maybeSingle();

  if (error) {
    console.error('获取用户信息失败:', error);
    return null;
  }
  return data;
}
interface AuthContextType {
  user: User | null;
  profile: Profile | null;
  loading: boolean;
  signInWithSms: (phone: string, code: string, sessionId: string) => Promise<{ error: Error | null }>;
  signInWithPhone: (phone: string, password: string) => Promise<{ error: Error | null }>;
  signUpWithPhone: (phone: string, password: string, code: string, sessionId: string, nickname?: string) => Promise<{ error: Error | null }>;
  signInWithEmail: (email: string, password: string) => Promise<{ error: Error | null }>;
  signUpWithEmail: (email: string, password: string, nickname: string) => Promise<{ error: Error | null }>;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
  sendSmsCode: (phone: string) => Promise<{ error: Error | null; sessionId?: string }>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  const refreshProfile = async () => {
    if (!user) {
      setProfile(null);
      return;
    }

    const profileData = await getProfile(user.id);
    setProfile(profileData);
  };

  // 发送短信验证码
  const sendSmsCode = async (phone: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('sms-auth', {
        body: { action: 'send', phone },
      });

      if (error) {
        const errorMsg = await error?.context?.text();
        throw new Error(errorMsg || error.message);
      }

      if (!data.success) {
        throw new Error(data.error || '发送失败');
      }

      return { error: null, sessionId: data.sessionId };
    } catch (error) {
      return { error: error as Error };
    }
  };

  // 短信验证码登录
  const signInWithSms = async (phone: string, code: string, sessionId: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('sms-auth', {
        body: { action: 'verify', phone, code, sessionId },
      });

      if (error) {
        const errorMsg = await error?.context?.text();
        throw new Error(errorMsg || error.message);
      }

      if (!data.success) {
        throw new Error(data.error || '验证失败');
      }

      // 使用OTP方式登录
      const { error: verifyError } = await supabase.auth.verifyOtp({
        token_hash: data.accessToken,
        type: 'magiclink',
      });

      if (verifyError) {
        throw verifyError;
      }

      return { error: null };
    } catch (error) {
      return { error: error as Error };
    }
  };

  // 手机号密码注册
  const signUpWithPhone = async (
    phone: string,
    password: string,
    code: string,
    sessionId: string,
    nickname?: string
  ) => {
    try {
      const { data, error } = await supabase.functions.invoke('phone-register', {
        body: { phone, password, code, sessionId, nickname },
      });

      if (error) {
        const errorMsg = await error?.context?.text();
        throw new Error(errorMsg || error.message);
      }

      if (!data.success) {
        throw new Error(data.error || '注册失败');
      }

      // 注册成功后自动登录
      const { error: signInError } = await supabase.auth.signInWithPassword({
        email: `${phone}@phone.local`,
        password,
      });

      if (signInError) {
        throw signInError;
      }

      return { error: null };
    } catch (error) {
      return { error: error as Error };
    }
  };

  // 手机号密码登录
  const signInWithPhone = async (phone: string, password: string) => {
    try {
      const { error } = await supabase.auth.signInWithPassword({
        email: `${phone}@phone.local`,
        password,
      });

      if (error) throw error;
      return { error: null };
    } catch (error) {
      return { error: error as Error };
    }
  };

  useEffect(() => {
    supabase
      .auth
      .getSession()
      .then(({ data: { session } }) => {
        setUser(session?.user ?? null);
        if (session?.user) {
          getProfile(session.user.id).then(setProfile);
        }
      })
      .catch(error => {
        toast.error(`获取用户信息失败: ${error.message}`);
      })
      .finally(() => {
        setLoading(false);
      });

    // In this function, do NOT use any await calls. Use `.then()` instead to avoid deadlocks.
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
      if (session?.user) {
        getProfile(session.user.id).then(setProfile);
      } else {
        setProfile(null);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  // 邮箱登录
  const signInWithEmail = async (email: string, password: string) => {
    try {
      const { error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) throw error;
      return { error: null };
    } catch (error) {
      return { error: error as Error };
    }
  };

  // 邮箱注册
  const signUpWithEmail = async (email: string, password: string, nickname: string) => {
    try {
      const { error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            nickname,
          },
          emailRedirectTo: window.location.origin,
        },
      });

      if (error) throw error;
      return { error: null };
    } catch (error) {
      return { error: error as Error };
    }
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    setUser(null);
    setProfile(null);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        profile,
        loading,
        signInWithSms,
        signInWithPhone,
        signUpWithPhone,
        signInWithEmail,
        signUpWithEmail,
        signOut,
        refreshProfile,
        sendSmsCode,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
