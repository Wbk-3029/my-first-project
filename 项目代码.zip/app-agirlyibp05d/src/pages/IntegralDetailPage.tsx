import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { MainLayout } from '@/components/layouts/MainLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { getIntegralAccount, getIntegralTransactions } from '@/db/api';
import type { IntegralTransaction, IntegralAccount } from '@/db/api';
import { ArrowLeft, TrendingUp, TrendingDown, Coins, Info } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { zhCN } from 'date-fns/locale';
import { toast } from 'sonner';

export default function IntegralDetailPage() {
  const [account, setAccount] = useState<IntegralAccount | null>(null);
  const [allTransactions, setAllTransactions] = useState<IntegralTransaction[]>([]);
  const [incomeTransactions, setIncomeTransactions] = useState<IntegralTransaction[]>([]);
  const [expenseTransactions, setExpenseTransactions] = useState<IntegralTransaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [activeTab, setActiveTab] = useState<'all' | 'income' | 'expense'>('all');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const [accountData, transactions] = await Promise.all([
        getIntegralAccount(),
        getIntegralTransactions(1, 20),
      ]);

      setAccount(accountData);
      setAllTransactions(transactions);
      setIncomeTransactions(transactions.filter((t) => t.type === 'income'));
      setExpenseTransactions(transactions.filter((t) => t.type === 'expense'));
      setHasMore(transactions.length === 20);
    } catch (error) {
      console.error('加载数据失败:', error);
      toast.error('加载数据失败');
    } finally {
      setLoading(false);
    }
  };

  const loadMore = async () => {
    if (loadingMore || !hasMore) return;

    try {
      setLoadingMore(true);
      const nextPage = currentPage + 1;
      const transactions = await getIntegralTransactions(nextPage, 20);

      if (transactions.length < 20) {
        setHasMore(false);
      }

      setAllTransactions((prev) => [...prev, ...transactions]);
      setIncomeTransactions((prev) => [
        ...prev,
        ...transactions.filter((t) => t.type === 'income'),
      ]);
      setExpenseTransactions((prev) => [
        ...prev,
        ...transactions.filter((t) => t.type === 'expense'),
      ]);
      setCurrentPage(nextPage);
    } catch (error) {
      console.error('加载更多失败:', error);
      toast.error('加载更多失败');
    } finally {
      setLoadingMore(false);
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('zh-CN', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const renderTransactionList = (transactions: IntegralTransaction[]) => {
    if (transactions.length === 0) {
      return (
        <div className="text-center py-12 text-muted-foreground">
          <Coins className="h-12 w-12 mx-auto mb-4 opacity-50" />
          <p>暂无记录</p>
        </div>
      );
    }

    return (
      <div className="space-y-3">
        {transactions.map((transaction) => (
          <Card key={transaction.id} className="hover:shadow-md transition-shadow">
            <CardContent className="p-4">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    {transaction.type === 'income' ? (
                      <TrendingUp className="h-4 w-4 text-green-500 shrink-0" />
                    ) : (
                      <TrendingDown className="h-4 w-4 text-red-500 shrink-0" />
                    )}
                    <span className="font-medium truncate">{transaction.reason}</span>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {formatDate(transaction.created_at)}
                    <span className="mx-2">·</span>
                    {formatDistanceToNow(new Date(transaction.created_at), {
                      addSuffix: true,
                      locale: zhCN,
                    })}
                  </div>
                  {transaction.expire_date && (
                    <div className="text-xs text-muted-foreground mt-1">
                      有效期至: {new Date(transaction.expire_date).toLocaleDateString('zh-CN')}
                    </div>
                  )}
                </div>
                <div className="text-right shrink-0">
                  <div
                    className={`text-lg font-bold ${
                      transaction.type === 'income' ? 'text-green-600' : 'text-red-600'
                    }`}
                  >
                    {transaction.type === 'income' ? '+' : '-'}
                    {transaction.amount}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    余额 {transaction.balance}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  };

  if (loading) {
    return (
      <MainLayout>
        <div className="container max-w-4xl mx-auto px-4 py-8 space-y-6">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-32 w-full" />
          <Skeleton className="h-64 w-full" />
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="container max-w-4xl mx-auto px-4 py-8 space-y-6">
        {/* Header */}
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" asChild>
            <Link to="/profile">
              <ArrowLeft className="h-5 w-5" />
            </Link>
          </Button>
          <h1 className="text-2xl font-bold">技易点明细</h1>
        </div>

        {/* Balance Card */}
        <Card className="bg-gradient-to-br from-primary/10 via-secondary/10 to-accent/10 border-primary/20">
          <CardContent className="p-6">
            <div className="space-y-4">
              <div className="text-center">
                <div className="text-sm text-muted-foreground mb-2">当前余额</div>
                <div className="text-5xl font-bold text-primary mb-4">
                  {account?.balance || 0}
                </div>
                <div className="flex items-center justify-center gap-2">
                  <Coins className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">技易点</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 pt-4 border-t border-border">
                <div className="text-center">
                  <div className="text-xs text-muted-foreground mb-1">累计收入</div>
                  <div className="text-xl font-semibold text-green-600">
                    +{account?.total_earned || 0}
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-xs text-muted-foreground mb-1">累计支出</div>
                  <div className="text-xl font-semibold text-red-600">
                    -{account?.total_spent || 0}
                  </div>
                </div>
              </div>

              {/* Fixed Deposit Button */}
              <div className="pt-4 border-t border-border">
                <Button asChild className="w-full" variant="outline">
                  <Link to="/profile/fixed-deposit" className="flex items-center justify-center gap-2">
                    <TrendingUp className="h-4 w-4" />
                    定期存款 · 获取更高收益
                  </Link>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Transactions */}
        <Card>
          <CardHeader>
            <CardTitle>交易记录</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as typeof activeTab)}>
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="all">
                  全部
                  <Badge variant="secondary" className="ml-2">
                    {allTransactions.length}
                  </Badge>
                </TabsTrigger>
                <TabsTrigger value="income">
                  收入
                  <Badge variant="secondary" className="ml-2">
                    {incomeTransactions.length}
                  </Badge>
                </TabsTrigger>
                <TabsTrigger value="expense">
                  支出
                  <Badge variant="secondary" className="ml-2">
                    {expenseTransactions.length}
                  </Badge>
                </TabsTrigger>
              </TabsList>

              <TabsContent value="all" className="mt-6">
                {renderTransactionList(allTransactions)}
              </TabsContent>

              <TabsContent value="income" className="mt-6">
                {renderTransactionList(incomeTransactions)}
              </TabsContent>

              <TabsContent value="expense" className="mt-6">
                {renderTransactionList(expenseTransactions)}
              </TabsContent>
            </Tabs>

            {hasMore && (
              <div className="mt-6 text-center">
                <Button
                  variant="outline"
                  onClick={loadMore}
                  disabled={loadingMore}
                  className="w-full md:w-auto"
                >
                  {loadingMore ? '加载中...' : '加载更多'}
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Rules Card */}
        <Card className="bg-muted/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Info className="h-4 w-4" />
              积分规则说明
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-sm text-muted-foreground">
            <div>
              <h4 className="font-medium text-foreground mb-2">获取积分</h4>
              <ul className="space-y-1 list-disc list-inside">
                <li>完成技能教学：根据技能定价、技能系数、信用系数计算</li>
                <li>每日签到：获得5积分</li>
                <li>邀请好友注册：每位好友20积分（每月上限200）</li>
                <li>发布优质帖子：被设为精华获得30积分（每周上限3次）</li>
                <li>活期利息：每天0.1%</li>
                <li>定期存款：7天0.3%/天，30天0.5%/天</li>
              </ul>
            </div>

            <div>
              <h4 className="font-medium text-foreground mb-2">消耗积分</h4>
              <ul className="space-y-1 list-disc list-inside">
                <li>购买他人技能：按技能定价扣除（按小时计费）</li>
                <li>参加团购：技能定价÷参团人数</li>
                <li>兑换平台礼品：根据积分商城设置</li>
                <li>解锁增值功能：如优先推荐9积分/周</li>
                <li>技能认证：39积分（一次性）</li>
              </ul>
            </div>

            <div>
              <h4 className="font-medium text-foreground mb-2">注意事项</h4>
              <ul className="space-y-1 list-disc list-inside">
                <li>积分有效期365天，逾期自动清零</li>
                <li>超过90天未登录，每月扣除10积分（上限100分）</li>
                <li>作弊行为将扣除全部积分并封号</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}
