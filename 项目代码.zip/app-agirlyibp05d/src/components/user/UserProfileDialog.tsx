import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { AddFriendDialog } from '@/components/friend/AddFriendDialog';
import { checkFriendStatus } from '@/db/api';
import { Award, MessageCircle, UserPlus, UserCheck } from 'lucide-react';
import { getCreditLevel } from '@/lib/credit-utils';

interface UserProfileDialogProps {
  userId: string;
  userName: string;
  userAvatar: string | null;
  userCreditScore: number;
  trigger?: React.ReactNode;
}

export function UserProfileDialog({
  userId,
  userName,
  userAvatar,
  userCreditScore,
  trigger,
}: UserProfileDialogProps) {
  const [open, setOpen] = useState(false);
  const [friendStatus, setFriendStatus] = useState<'none' | 'pending' | 'friend'>('none');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (open) {
      loadFriendStatus();
    }
  }, [open, userId]);

  const loadFriendStatus = async () => {
    try {
      setLoading(true);
      const status = await checkFriendStatus(userId);
      setFriendStatus(status);
    } catch (error) {
      console.error('检查好友状态失败:', error);
    } finally {
      setLoading(false);
    }
  };

  const creditTier = getCreditLevel(userCreditScore);

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger || (
          <Avatar className="cursor-pointer hover:ring-2 hover:ring-primary transition-all">
            <AvatarImage src={userAvatar || undefined} />
            <AvatarFallback>{userName?.[0] || '用'}</AvatarFallback>
          </Avatar>
        )}
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>用户信息</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* 用户基本信息 */}
          <div className="flex items-center gap-4">
            <Avatar className="h-16 w-16">
              <AvatarImage src={userAvatar || undefined} />
              <AvatarFallback className="text-2xl">{userName?.[0] || '用'}</AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <h3 className="text-lg font-semibold mb-1">{userName || '未知用户'}</h3>
              <div className="flex items-center gap-2">
                <Badge className={`gap-1 ${creditTier.bgColor} ${creditTier.color}`}>
                  <Award className="h-3 w-3" />
                  {creditTier.label}
                </Badge>
                <span className="text-sm text-muted-foreground">
                  信用分: {userCreditScore}
                </span>
              </div>
            </div>
          </div>

          <Separator />

          {/* 操作按钮 */}
          <div className="flex flex-col gap-3">
            {loading ? (
              <Button onClick={() => {}} disabled>加载中...</Button>
            ) : friendStatus === 'friend' ? (
              <>
                <Button asChild className="gap-2">
                  <Link to={`/messages/${userId}`}>
                    <MessageCircle className="h-4 w-4" />
                    发送消息
                  </Link>
                </Button>
                <Button variant="outline" asChild>
                  <Link to={`/profile/${userId}`}>查看主页</Link>
                </Button>
              </>
            ) : friendStatus === 'pending' ? (
              <>
                <Button onClick={() => {}} disabled className="gap-2">
                  <UserCheck className="h-4 w-4" />
                  已发送申请
                </Button>
                <Button variant="outline" asChild>
                  <Link to={`/profile/${userId}`}>查看主页</Link>
                </Button>
              </>
            ) : (
              <>
                <AddFriendDialog
                  friendId={userId}
                  friendName={userName}
                  trigger={
                    <button className="inline-flex items-center justify-center gap-2 w-full rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground hover:bg-primary/90 h-10 px-4 py-2">
                      <UserPlus className="h-4 w-4" />
                      添加好友
                    </button>
                  }
                />
                <Button variant="outline" asChild>
                  <Link to={`/profile/${userId}`}>查看主页</Link>
                </Button>
              </>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
