import { useAuth } from '@/contexts/AuthContext';
import { useLoginDialog } from '@/contexts/LoginDialogContext';

/**
 * 检查用户是否登录的Hook
 * 如果未登录,自动打开登录弹窗
 * @returns 是否已登录
 */
export function useRequireAuth() {
  const { user } = useAuth();
  const { openLoginDialog } = useLoginDialog();

  const requireAuth = (callback?: () => void) => {
    if (!user) {
      openLoginDialog();
      return false;
    }
    callback?.();
    return true;
  };

  return { isAuthenticated: !!user, requireAuth };
}
