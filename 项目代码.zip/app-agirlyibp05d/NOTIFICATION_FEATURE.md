# 消息通知功能优化说明

## 功能概述
消息通知功能为技遇平台提供完整的消息推送和管理服务，支持多种消息类型，包括交换申请、申请结果、交换提醒、评价提醒和系统通知。用户可以在消息列表页查看所有通知，点击通知跳转到相关页面，支持一键标记全部已读。底部导航栏的"消息"图标显示未读消息红点，提醒用户及时查看。

---

## 1. 数据库设计

### 1.1 notifications表扩展

**新增字段**:
| 字段名 | 类型 | 说明 |
|--------|------|------|
| action_url | text | 操作跳转URL |

**类型扩展**:
原类型：`'friend_request' | 'exchange_request' | 'system'`

新类型：
- `exchange_request`: 交换申请（待确认）
- `exchange_accepted`: 申请同意
- `exchange_rejected`: 申请拒绝
- `exchange_reminder`: 交换提醒（即将开始）
- `rating_reminder`: 评价提醒（待评价）
- `credit_change`: 信用分变化
- `points_change`: 技易点变动
- `system`: 系统通知
- `friend_request`: 好友申请

---

## 2. RPC函数

### 2.1 get_unread_notification_count
获取未读消息数量

**参数**: 无（自动获取当前登录用户）

**返回**: 
```typescript
number // 未读消息数量
```

**业务逻辑**:
1. 获取当前登录用户ID
2. 如果未登录，返回0
3. 查询用户的未读消息数量
4. 返回数量

### 2.2 mark_all_notifications_as_read
标记所有通知为已读

**参数**: 无（自动获取当前登录用户）

**返回**:
```json
{
  "success": true,
  "count": 5,
  "message": "已标记5条通知为已读"
}
```

**业务逻辑**:
1. 获取当前登录用户ID
2. 如果未登录，抛出异常
3. 更新用户的所有未读消息为已读
4. 返回更新数量和成功消息

### 2.3 create_notification
创建通知

**参数**:
- `p_user_id`: 用户ID
- `p_type`: 通知类型
- `p_title`: 通知标题
- `p_content`: 通知内容（可选）
- `p_related_id`: 关联ID（可选）
- `p_action_url`: 操作跳转URL（可选）

**返回**:
```json
{
  "success": true,
  "notification_id": "uuid"
}
```

**业务逻辑**:
1. 插入通知记录
2. 返回通知ID

---

## 3. 触发器

### 3.1 notify_exchange_request
交换申请时发送通知

**触发时机**: 创建交换申请后（AFTER INSERT ON exchanges）

**业务逻辑**:
1. 获取发起人昵称
2. 获取技能名称
3. 发送通知给接收方
4. 通知类型: `exchange_request`
5. 通知标题: "收到新的交换申请"
6. 通知内容: "{发起人昵称} 想要与你交换技能：{技能名称}"
7. 操作跳转URL: `/exchanges/{交换ID}`

### 3.2 notify_exchange_status_change
交换状态变化时发送通知

**触发时机**: 更新交换状态后（AFTER UPDATE ON exchanges）

**业务逻辑**:
1. 检查状态是否变化
2. 如果状态未变化，不发送通知
3. 获取接收方昵称
4. 获取技能名称
5. 根据状态发送不同通知:
   - **accepted**: 发送通知给发起方
     - 通知类型: `exchange_accepted`
     - 通知标题: "交换申请已同意"
     - 通知内容: "{接收方昵称} 同意了你的交换申请：{技能名称}"
     - 操作跳转URL: `/exchanges/{交换ID}`
   - **rejected**: 发送通知给发起方
     - 通知类型: `exchange_rejected`
     - 通知标题: "交换申请已拒绝"
     - 通知内容: "{接收方昵称} 拒绝了你的交换申请：{技能名称}"
     - 操作跳转URL: `/exchanges/{交换ID}`

---

## 4. API函数

### 4.1 getNotifications
获取通知列表

```typescript
getNotifications(limit: number = 20): Promise<Notification[]>
```

**参数**:
- `limit`: 返回数量（默认20）

**返回**: Notification数组

### 4.2 getUnreadNotificationCount
获取未读消息数量

```typescript
getUnreadNotificationCount(): Promise<number>
```

**返回**: 未读消息数量

### 4.3 markNotificationAsRead
标记通知为已读

```typescript
markNotificationAsRead(notificationId: string): Promise<void>
```

**参数**:
- `notificationId`: 通知ID

### 4.4 markAllNotificationsAsRead
标记所有通知为已读

```typescript
markAllNotificationsAsRead(): Promise<{
  success: boolean;
  count: number;
  message: string;
}>
```

**返回**: 成功结果

---

## 5. 前端页面

### 5.1 NotificationsPage
消息列表页

**位置**: /notifications

**功能**:
- 显示所有通知
- 分类筛选（全部、未读、交换、系统）
- 点击通知跳转到相关页面
- 一键标记全部已读

**分类标签**:
- **全部**: 显示所有通知
- **未读**: 显示未读通知（带红色徽章显示未读数量）
- **交换**: 显示交换相关通知（exchange_request, exchange_accepted, exchange_rejected, exchange_reminder）
- **系统**: 显示系统通知（credit_change, points_change, system, rating_reminder）

**通知卡片**:
- 图标: 根据通知类型显示不同颜色的图标
- 标题: 通知标题（未读消息加粗）
- 内容: 通知内容（最多显示2行）
- 类型徽章: 显示通知类型名称
- 时间: 相对时间（如"3分钟前"）
- 未读标识: 红点标识（右上角）
- 未读样式: 蓝色边框和浅蓝色背景

**操作栏**:
- 左侧: 显示未读消息数量
- 右侧: "全部已读"按钮（仅在有未读消息时显示）

**交互**:
- 点击通知卡片: 标记为已读并跳转到相关页面
- 点击"全部已读"按钮: 标记所有通知为已读

**跳转逻辑**:
1. 优先使用action_url跳转
2. 如果没有action_url，根据类型跳转:
   - `friend_request`: 跳转到好友申请页面
   - `exchange_request`, `exchange_accepted`, `exchange_rejected`: 跳转到交换详情页

### 5.2 BottomNav
底部导航栏

**功能**:
- 显示未读消息红点
- 每30秒刷新一次未读数

**未读消息红点**:
- 位置: "消息"图标右上角
- 样式: 红色圆形徽章
- 显示规则:
  - 未读数 = 0: 不显示
  - 未读数 1-99: 显示数字
  - 未读数 ≥ 100: 显示"99+"

---

## 6. 消息类型详解

### 6.1 交换申请（exchange_request）
**触发时机**: 用户发起交换申请时

**通知对象**: 接收方

**通知内容**: "{发起人昵称} 想要与你交换技能：{技能名称}"

**操作**: 点击跳转到交换详情页，可以同意或拒绝

**图标**: 紫色Repeat图标

### 6.2 申请同意（exchange_accepted）
**触发时机**: 接收方同意交换申请时

**通知对象**: 发起方

**通知内容**: "{接收方昵称} 同意了你的交换申请：{技能名称}"

**操作**: 点击跳转到交换详情页

**图标**: 绿色CheckCheck图标

### 6.3 申请拒绝（exchange_rejected）
**触发时机**: 接收方拒绝交换申请时

**通知对象**: 发起方

**通知内容**: "{接收方昵称} 拒绝了你的交换申请：{技能名称}"

**操作**: 点击跳转到交换详情页

**图标**: 红色AlertCircle图标

### 6.4 交换提醒（exchange_reminder）
**触发时机**: 约定时间前1小时或15分钟（待实现）

**通知对象**: 交换双方

**通知内容**: "你的交换即将开始：{技能名称}"

**操作**: 点击跳转到交换详情页

**图标**: 橙色Clock图标

### 6.5 评价提醒（rating_reminder）
**触发时机**: 交换完成后（待实现）

**通知对象**: 交换双方

**通知内容**: "请对本次交换进行评价：{技能名称}"

**操作**: 点击跳转到评价页面

**图标**: 黄色Star图标

### 6.6 信用分变化（credit_change）
**触发时机**: 信用分增加或减少时（待实现）

**通知对象**: 用户本人

**通知内容**: "你的信用分{增加/减少}{数量}分，当前信用分：{当前分数}"

**操作**: 点击跳转到信用分明细页

**图标**: 绿色TrendingUp图标

### 6.7 技易点变动（points_change）
**触发时机**: 技易点增加或减少时（待实现）

**通知对象**: 用户本人

**通知内容**: "你的技易点{增加/减少}{数量}点，当前技易点：{当前点数}"

**操作**: 点击跳转到技易点明细页

**图标**: 琥珀色Coins图标

### 6.8 系统通知（system）
**触发时机**: 系统管理员发送通知时

**通知对象**: 指定用户或全体用户

**通知内容**: 自定义

**操作**: 根据action_url跳转

**图标**: 主色调Bell图标

### 6.9 好友申请（friend_request）
**触发时机**: 用户发送好友申请时

**通知对象**: 接收方

**通知内容**: "{发起人昵称} 想要添加你为好友"

**操作**: 点击跳转到好友申请页面

**图标**: 蓝色UserPlus图标

---

## 7. 业务流程

### 7.1 交换申请通知流程
1. 用户A发起交换申请
2. 系统创建交换记录
3. 触发器notify_exchange_request自动执行
4. 系统发送通知给用户B
5. 用户B在消息列表看到未读通知
6. 底部导航栏"消息"图标显示红点
7. 用户B点击通知
8. 系统标记通知为已读
9. 跳转到交换详情页
10. 用户B可以同意或拒绝申请

### 7.2 申请结果通知流程
1. 用户B同意或拒绝交换申请
2. 系统更新交换状态
3. 触发器notify_exchange_status_change自动执行
4. 系统发送通知给用户A
5. 用户A在消息列表看到未读通知
6. 底部导航栏"消息"图标显示红点
7. 用户A点击通知
8. 系统标记通知为已读
9. 跳转到交换详情页
10. 用户A查看申请结果

### 7.3 一键标记全部已读流程
1. 用户点击"全部已读"按钮
2. 系统调用mark_all_notifications_as_read RPC函数
3. 系统更新所有未读消息为已读
4. 系统返回更新数量
5. 页面显示成功提示
6. 页面刷新通知列表
7. 底部导航栏红点消失

---

## 8. 用户界面

### 8.1 消息列表页
- 标题: "消息通知"
- 操作栏: 未读数量 + "全部已读"按钮
- 分类标签: 全部、未读、交换、系统
- 通知卡片: 图标、标题、内容、类型徽章、时间、未读标识
- 空状态: 显示Bell图标和"暂无通知"文字
- 骨架屏: 加载时显示5个骨架卡片

### 8.2 底部导航栏
- "消息"图标: Bell图标
- 未读消息红点: 右上角红色圆形徽章
- 显示未读数量: 1-99显示数字，≥100显示"99+"

---

## 9. 错误处理

### 9.1 前端验证
- 检查用户是否登录
- 检查通知ID是否有效

### 9.2 后端验证
- 检查用户是否登录
- 检查通知是否存在
- 检查用户权限

### 9.3 错误提示
- "加载通知失败"
- "标记已读失败"
- "操作失败"
- "未登录"
- 使用toast显示错误信息

---

## 10. 性能优化

### 10.1 数据库优化
- 使用索引加速查询（user_id, is_read, created_at）
- 使用触发器自动发送通知
- 使用RPC函数封装业务逻辑
- 使用SECURITY DEFINER确保权限

### 10.2 前端优化
- 使用骨架屏提升加载体验
- 每30秒刷新一次未读数
- 点击通知后立即标记为已读
- 使用相对时间显示（date-fns）

---

## 11. 安全性

### 11.1 RLS策略
- 用户只能查看自己的通知
- 用户只能标记自己的通知为已读

### 11.2 业务逻辑
- 检查用户权限
- 检查通知是否存在
- 使用SECURITY DEFINER确保权限

---

## 12. 扩展功能

### 12.1 交换提醒通知（待实现）
**功能**:
- 约定时间前1小时提醒
- 约定时间前15分钟提醒

**实现方案**:
1. 创建Edge Function定时任务
2. 每5分钟查询即将开始的交换
3. 检查是否已发送提醒
4. 调用create_notification RPC函数发送通知
5. 记录提醒状态

### 12.2 评价提醒通知（待实现）
**功能**:
- 交换完成后提醒评价

**实现方案**:
1. 创建触发器监听交换状态变化
2. 当状态变为completed时
3. 调用create_notification RPC函数发送通知给双方
4. 通知类型: rating_reminder

### 12.3 信用分变化通知（待实现）
**功能**:
- 信用分增加或减少时通知

**实现方案**:
1. 创建触发器监听credit_score_changes表
2. 当插入新记录时
3. 调用create_notification RPC函数发送通知
4. 通知类型: credit_change
5. 通知内容: "你的信用分{增加/减少}{数量}分，当前信用分：{当前分数}"

### 12.4 技易点变动通知（待实现）
**功能**:
- 技易点增加或减少时通知

**实现方案**:
1. 创建触发器监听points_changes表
2. 当插入新记录时
3. 调用create_notification RPC函数发送通知
4. 通知类型: points_change
5. 通知内容: "你的技易点{增加/减少}{数量}点，当前技易点：{当前点数}"

### 12.5 推送通知（待实现）
**功能**:
- 浏览器推送通知
- 移动端推送通知

**实现方案**:
1. 使用Web Push API
2. 用户授权推送通知
3. 保存推送订阅信息
4. 发送通知时同时推送
5. 点击推送通知跳转到应用

### 12.6 通知设置（待实现）
**功能**:
- 用户可以设置接收哪些类型的通知
- 用户可以设置推送通知开关

**实现方案**:
1. 创建notification_settings表
2. 保存用户的通知设置
3. 发送通知前检查用户设置
4. 如果用户关闭了该类型通知，不发送

---

## 13. 测试建议

### 13.1 功能测试
1. 测试交换申请通知
2. 测试申请结果通知
3. 测试一键标记全部已读
4. 测试未读消息红点
5. 测试通知跳转

### 13.2 边界测试
1. 测试未登录用户
2. 测试无通知用户
3. 测试大量通知
4. 测试并发标记已读

### 13.3 性能测试
1. 测试加载速度
2. 测试刷新频率
3. 测试触发器性能

---

## 14. 常见问题

### Q1: 为什么我没有收到通知？
A: 请检查：
1. 是否登录
2. 是否有相关操作（如交换申请）
3. 是否刷新页面

### Q2: 未读消息红点不更新怎么办？
A: 底部导航栏每30秒自动刷新一次未读数。如果需要立即更新，请刷新页面。

### Q3: 点击通知后没有跳转怎么办？
A: 请检查通知是否有action_url或related_id。如果都没有，可能是旧数据。

### Q4: 如何关闭某些类型的通知？
A: 目前不支持关闭通知。未来版本将添加通知设置功能。

### Q5: 通知会保留多久？
A: 通知会永久保留，除非用户手动删除（未来版本将添加删除功能）。

---

## 15. 更新日志

### v1.0.0 (2026-03-23)
- 初始版本
- 扩展notifications表的类型（9种类型）
- 添加action_url字段
- 创建get_unread_notification_count RPC函数
- 创建mark_all_notifications_as_read RPC函数
- 创建create_notification RPC函数
- 创建notify_exchange_request触发器
- 创建notify_exchange_status_change触发器
- 更新API函数：getUnreadNotificationCount、markAllNotificationsAsRead
- 重写NotificationsPage页面（支持9种消息类型、分类筛选、一键标记全部已读）
- 更新BottomNav组件（显示未读消息红点、每30秒刷新）
- 更新Notification类型定义

---

## 16. 技术实现细节

### 16.1 触发器实现
使用PostgreSQL触发器自动发送通知：
```sql
CREATE TRIGGER trigger_notify_exchange_request
  AFTER INSERT ON exchanges
  FOR EACH ROW
  EXECUTE FUNCTION notify_exchange_request();

CREATE TRIGGER trigger_notify_exchange_status_change
  AFTER UPDATE ON exchanges
  FOR EACH ROW
  EXECUTE FUNCTION notify_exchange_status_change();
```

### 16.2 未读消息红点实现
使用useEffect和setInterval定时刷新：
```typescript
useEffect(() => {
  if (user) {
    loadUnreadCount();
    const interval = setInterval(loadUnreadCount, 30000);
    return () => clearInterval(interval);
  }
}, [user]);
```

### 16.3 通知跳转实现
优先使用action_url，兼容旧数据：
```typescript
if (notification.action_url) {
  navigate(notification.action_url);
  return;
}

// 兼容旧数据
if (notification.type === 'friend_request') {
  navigate('/friend-requests');
} else if (notification.related_id) {
  navigate(`/exchanges/${notification.related_id}`);
}
```

---

## 17. 界面设计规范

### 17.1 颜色规范
- 交换申请: 紫色
- 申请同意: 绿色
- 申请拒绝: 红色
- 交换提醒: 橙色
- 评价提醒: 黄色
- 信用分变化: 绿色
- 技易点变动: 琥珀色
- 系统通知: 主色调
- 好友申请: 蓝色
- 未读消息: 蓝色边框和浅蓝色背景
- 未读标识: 红色圆点

### 17.2 间距规范
- 卡片间距: 12px（space-y-3）
- 卡片内边距: 16px（p-4）
- 元素间距: 8px（gap-2）

### 17.3 字体规范
- 标题: 14px（text-sm）
- 正文: 14px（text-sm）
- 辅助: 12px（text-xs）

### 17.4 交互规范
- 卡片hover: 阴影增强
- 未读消息: 加粗标题
- 点击卡片: 标记为已读并跳转

---

## 18. 数据流图

```
用户A发起交换申请 → 创建交换记录 → 触发器notify_exchange_request
                                    → 发送通知给用户B
                                    → 用户B看到未读通知
                                    → 底部导航栏显示红点

用户B同意/拒绝申请 → 更新交换状态 → 触发器notify_exchange_status_change
                                  → 发送通知给用户A
                                  → 用户A看到未读通知
                                  → 底部导航栏显示红点

用户点击通知 → 标记为已读 → 跳转到相关页面

用户点击"全部已读" → mark_all_notifications_as_read RPC
                   → 更新所有未读消息
                   → 返回更新数量
                   → 显示成功提示
                   → 红点消失
```

---

**最后更新**: 2026-03-23
**版本**: v1.0.0
**维护者**: 技遇开发团队
