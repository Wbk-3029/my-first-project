// 数据库类型定义

export type SkillType = 'entertainment' | 'normal' | 'hot' | 'rare' | 'master';
export type ExchangeType = 'direct' | 'point' | 'group';
export type ExchangeStatus = 'pending' | 'accepted' | 'rejected' | 'in_progress' | 'completed' | 'cancelled';
export type GroupBuyStatus = 'active' | 'completed' | 'expired';
export type RatingType = 'positive' | 'negative';
export type FavoriteType = 'skill' | 'post';
export type SkillStatus = 'active' | 'inactive';

export interface Profile {
  id: string;
  phone: string | null;
  nickname: string | null;
  avatar_url: string | null;
  credit_score: number;
  points: number;
  onboarding_completed: boolean;
  skills_want_to_learn: string[];
  skills_can_teach: string[];
  available_time: string | null;
  created_at: string;
}

export interface Skill {
  id: string;
  user_id: string;
  name: string;
  type: SkillType;
  description: string | null;
  price: number;
  required_skills: string | null;
  exchange_count: number;
  status: SkillStatus;
  media: string[];
  created_at: string;
  profiles?: Profile;
}

export interface SkillPriceHistory {
  id: string;
  skill_id: string;
  old_price: number;
  new_price: number;
  reason: string | null;
  created_at: string;
}

export interface Post {
  id: string;
  user_id: string;
  title: string;
  content: string;
  skill_type: SkillType | null;
  exchange_need: string | null;
  images: string[] | null;
  like_count: number;
  reply_count: number;
  view_count: number;
  is_featured: boolean;
  is_deleted: boolean;
  created_at: string;
  profiles?: Profile;
  user_liked?: boolean;
  user_favorited?: boolean;
}

export interface PostLike {
  id: string;
  post_id: string;
  user_id: string;
  created_at: string;
}

export interface PostReply {
  id: string;
  post_id: string;
  parent_id: string | null;
  user_id: string;
  content: string;
  like_count: number;
  is_deleted: boolean;
  created_at: string;
  profiles?: Profile;
  user_liked?: boolean;
  replies?: PostReply[];
}

export interface Exchange {
  id: string;
  type: ExchangeType;
  initiator_id: string;
  receiver_id: string;
  initiator_skill_id: string | null;
  receiver_skill_id: string;
  points_amount: number | null;
  status: ExchangeStatus;
  note: string | null;
  start_time: string | null;
  completed_at: string | null;
  created_at: string;
  updated_at: string;
  initiator?: Profile;
  receiver?: Profile;
  initiator_skill?: Skill;
  receiver_skill?: Skill;
}

export interface GroupBuy {
  id: string;
  skill_id: string;
  initiator_id: string;
  original_price: number;
  group_price: number;
  participant_count: number;
  status: GroupBuyStatus;
  expires_at: string;
  created_at: string;
  skills?: Skill;
  profiles?: Profile;
}

export interface GroupBuyParticipant {
  id: string;
  group_buy_id: string;
  user_id: string;
  created_at: string;
  profiles?: Profile;
}

export interface Rating {
  id: string;
  exchange_id: string;
  rater_id: string;
  rated_id: string;
  rating_type: RatingType;
  comment: string | null;
  created_at: string;
  rater?: Profile;
  rated?: Profile;
}

export interface Favorite {
  id: string;
  user_id: string;
  item_type: FavoriteType;
  item_id: string;
  created_at: string;
}

// 技能类型标签映射
export const SKILL_TYPE_LABELS: Record<SkillType, string> = {
  entertainment: '娱乐技能',
  normal: '普通技能',
  hot: '热门技能',
  rare: '稀缺技能',
  master: '大神技能',
};

// 技能默认价格
export const SKILL_TYPE_PRICES: Record<SkillType, number> = {
  entertainment: 10,
  normal: 20,
  hot: 30,
  rare: 50,
  master: 100,
};

// 技能默认价格(别名,保持兼容性)
export const SKILL_DEFAULT_PRICES: Record<SkillType, number> = SKILL_TYPE_PRICES;

// 交换状态标签
export const EXCHANGE_STATUS_LABELS: Record<ExchangeStatus, string> = {
  pending: '待确认',
  accepted: '已接受',
  rejected: '已拒绝',
  in_progress: '进行中',
  completed: '已完成',
  cancelled: '已取消',
};

// 交换类型标签
export const EXCHANGE_TYPE_LABELS: Record<ExchangeType, string> = {
  direct: '直接交换',
  point: '技易点交换',
  group: '团购',
};

// 对话类型
export interface Conversation {
  id: string;
  user1_id: string;
  user2_id: string;
  exchange_id: string | null;
  last_message_at: string;
  created_at: string;
  user1?: Profile;
  user2?: Profile;
  unread_count?: number;
}

// 消息类型
export interface Message {
  id: string;
  conversation_id: string;
  sender_id: string;
  content: string;
  is_read: boolean;
  created_at: string;
  sender?: Profile;
}

// 热门视频类型
export interface HotVideo {
  id: string;
  title: string;
  cover_image: string;
  video_url: string;
  publisher_id: string;
  view_count: number;
  like_count: number;
  created_at: string;
  profiles?: Profile;
}

// 推荐内容类型
export interface Recommendation {
  id: string;
  title: string;
  cover_image: string;
  description: string | null;
  link: string;
  is_paid: boolean;
  sort_weight: number;
  created_at: string;
}

// 好友关系类型
export interface FriendRelation {
  id: string;
  user_id: string;
  friend_id: string;
  status: 0 | 1 | 2; // 0待审核, 1已同意, 2已拒绝
  message: string | null;
  created_at: string;
  agreed_at: string | null;
  user_profile?: Profile;
  friend_profile?: Profile;
}

// 通知类型
export type NotificationType = 
  | 'exchange_request'      // 交换申请
  | 'exchange_accepted'     // 申请同意
  | 'exchange_rejected'     // 申请拒绝
  | 'exchange_reminder'     // 交换提醒
  | 'rating_reminder'       // 评价提醒
  | 'credit_change'         // 信用分变化
  | 'points_change'         // 技易点变动
  | 'system'                // 系统通知
  | 'friend_request';       // 好友申请

export interface Notification {
  id: string;
  user_id: string;
  type: NotificationType;
  title: string;
  content: string | null;
  related_id: string | null;
  action_url: string | null;
  is_read: boolean;
  created_at: string;
}

export type TemplateCategory = 'skill_learning' | 'exam_tutoring' | 'interest_exchange' | 'custom';

export interface ExchangeTemplate {
  id: string;
  user_id: string | null;
  title: string;
  content: string;
  is_system: boolean;
  category: TemplateCategory;
  usage_count: number;
  created_at: string;
  updated_at: string;
}

export type AccountStatus = 'normal' | 'warned' | 'suspended' | 'banned';

export type ViolationType = 'no_show' | 'false_info' | 'malicious_review' | 'spam' | 'harassment' | 'other';

export type ViolationStatus = 'pending' | 'processing' | 'resolved' | 'rejected';

export interface ViolationRecord {
  id: string;
  violator_id: string;
  reporter_id: string | null;
  type: ViolationType;
  description: string;
  evidence: string[];
  related_id: string | null;
  related_type: string | null;
  credit_deducted: number;
  status: ViolationStatus;
  handler_id: string | null;
  handler_note: string | null;
  handled_at: string | null;
  appeal_status: string | null;
  can_appeal: boolean;
  created_at: string;
  updated_at: string;
  violator?: Profile;
  reporter?: Profile;
  handler?: Profile;
}

export interface ViolationStats {
  total_violations: number;
  pending_violations: number;
  resolved_violations: number;
  no_show_count: number;
  false_info_count: number;
  malicious_review_count: number;
  spam_count: number;
  harassment_count: number;
  total_credit_deducted: number;
}

export type AppealStatus = 'pending' | 'approved' | 'rejected';

export interface Appeal {
  id: string;
  violation_record_id: string;
  appellant_id: string;
  reason: string;
  evidence: string[];
  status: AppealStatus;
  handler_id: string | null;
  handler_note: string | null;
  result: string | null;
  handled_at: string | null;
  created_at: string;
  updated_at: string;
  appellant?: Profile;
  handler?: Profile;
  violation_record?: ViolationRecord;
}

export interface AppealStats {
  total_appeals: number;
  pending_appeals: number;
  approved_appeals: number;
  rejected_appeals: number;
  total_credit_restored: number;
}
