import { createClient } from 'jsr:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface DailySettlementRequest {
  action: 'settle_interest' | 'check_deposits' | 'check_expired_integrals';
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const { action } = await req.json() as DailySettlementRequest;

    if (action === 'settle_interest') {
      // 结算活期利息（每天0.1%）
      const { data: accounts } = await supabaseClient
        .from('user_integral')
        .select('user_id, balance')
        .gt('balance', 0);

      if (accounts) {
        for (const account of accounts) {
          const interest = Math.floor(account.balance * 0.001 * 100) / 100; // 0.1%
          if (interest > 0) {
            await supabaseClient.rpc('add_integral', {
              p_user_id: account.user_id,
              p_amount: interest,
              p_reason: '活期利息',
              p_expire_days: 365
            });
          }
        }
      }

      return new Response(
        JSON.stringify({ success: true, message: '利息结算完成' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (action === 'check_deposits') {
      // 检查定期存款到期
      const { data: deposits } = await supabaseClient
        .from('fixed_deposits')
        .select('*')
        .eq('status', 'active')
        .lte('end_date', new Date().toISOString());

      if (deposits) {
        for (const deposit of deposits) {
          const days = deposit.period_days;
          const totalInterest = Math.floor(deposit.amount * deposit.interest_rate * days * 100) / 100;
          const totalAmount = deposit.amount + totalInterest;

          // 解冻并添加本金+利息
          await supabaseClient
            .from('user_integral')
            .update({
              balance: supabaseClient.raw(`balance + ${totalAmount}`),
              frozen_amount: supabaseClient.raw(`frozen_amount - ${deposit.amount}`)
            })
            .eq('user_id', deposit.user_id);

          // 记录交易
          await supabaseClient.rpc('add_integral', {
            p_user_id: deposit.user_id,
            p_amount: totalInterest,
            p_reason: `${days}天定期利息`,
            p_related_id: deposit.id,
            p_expire_days: 365
          });

          // 更新存款状态
          await supabaseClient
            .from('fixed_deposits')
            .update({ status: 'completed' })
            .eq('id', deposit.id);
        }
      }

      return new Response(
        JSON.stringify({ success: true, message: '定期存款检查完成' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (action === 'check_expired_integrals') {
      // 检查过期积分
      const expiredDate = new Date();
      expiredDate.setDate(expiredDate.getDate() - 365);

      const { data: expiredTransactions } = await supabaseClient
        .from('integral_transactions')
        .select('user_id, amount')
        .eq('type', 'income')
        .lt('expire_date', expiredDate.toISOString().split('T')[0])
        .is('expired', null);

      if (expiredTransactions) {
        const userExpiredMap = new Map<string, number>();
        
        for (const tx of expiredTransactions) {
          const current = userExpiredMap.get(tx.user_id) || 0;
          userExpiredMap.set(tx.user_id, current + tx.amount);
        }

        for (const [userId, amount] of userExpiredMap) {
          await supabaseClient.rpc('deduct_integral', {
            p_user_id: userId,
            p_amount: amount,
            p_reason: '积分过期'
          });
        }
      }

      return new Response(
        JSON.stringify({ success: true, message: '过期积分检查完成' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    return new Response(
      JSON.stringify({ error: '无效的操作' }),
      { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
