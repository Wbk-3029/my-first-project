import { Link } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { UserProfileDialog } from '@/components/user/UserProfileDialog';
import type { Post } from '@/types';
import { Heart, MessageCircle, Share2 } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { zhCN } from 'date-fns/locale';

interface PostCardProps {
  post: Post;
}

export function PostCard({ post }: PostCardProps) {
  return (
    <Card className="rounded-2xl hover:shadow-md transition-all duration-300 overflow-hidden">
      {/* 头部：头像、昵称、时间 */}
      <div className="p-4 pb-3">
        <div
          className="flex items-center gap-3 mb-3"
          onClick={(e) => e.preventDefault()}
        >
          {post.profiles && (
            <>
              <UserProfileDialog
                userId={post.user_id}
                userName={post.profiles.nickname || '匿名用户'}
                userAvatar={post.profiles.avatar_url}
                userCreditScore={post.profiles.credit_score || 100}
                trigger={
                  <Avatar className="h-10 w-10 cursor-pointer ring-2 ring-background hover:ring-primary/20 transition-all">
                    <AvatarImage src={post.profiles.avatar_url || undefined} />
                    <AvatarFallback>{post.profiles.nickname?.[0] || '用'}</AvatarFallback>
                  </Avatar>
                }
              />
              <div className="flex-1 min-w-0">
                <div className="font-medium text-sm">{post.profiles.nickname || '匿名用户'}</div>
                <div className="text-xs text-muted-foreground">
                  {formatDistanceToNow(new Date(post.created_at), {
                    addSuffix: true,
                    locale: zhCN,
                  })}
                </div>
              </div>
            </>
          )}
        </div>

        {/* 内容区域 */}
        <Link to={`/forum/${post.id}`} className="block">
          {/* 标题 */}
          <h3 className="text-base font-bold mb-2 line-clamp-2 leading-snug">
            {post.title}
          </h3>

          {/* 内容摘要 */}
          <p className="text-sm text-muted-foreground line-clamp-3 leading-relaxed mb-3">
            {post.content}
          </p>

          {/* 图片网格 */}
          {post.images && post.images.length > 0 && (
            <div className="grid grid-cols-3 gap-2 mb-3">
              {post.images.slice(0, 3).map((url, index) => (
                <div key={index} className="aspect-square rounded-lg overflow-hidden">
                  <img
                    src={url}
                    alt={`图片 ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                </div>
              ))}
              {post.images.length > 3 && (
                <div className="absolute bottom-2 right-2 bg-black/60 text-white text-xs px-2 py-1 rounded-full">
                  +{post.images.length - 3}
                </div>
              )}
            </div>
          )}
        </Link>
      </div>

      {/* 底部：点赞、评论、分享 */}
      <div className="px-4 py-3 border-t border-border bg-muted/30">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-6">
            {/* 点赞 */}
            <button
              className="flex items-center gap-1.5 text-muted-foreground hover:text-primary transition-colors min-h-10 min-w-16"
              onClick={(e) => {
                e.preventDefault();
                // TODO: 点赞功能
              }}
            >
              <Heart className="h-4 w-4" />
              <span className="text-sm font-medium">{post.like_count || 0}</span>
            </button>

            {/* 评论 */}
            <Link
              to={`/forum/${post.id}`}
              className="flex items-center gap-1.5 text-muted-foreground hover:text-primary transition-colors min-h-10 min-w-16"
            >
              <MessageCircle className="h-4 w-4" />
              <span className="text-sm font-medium">{post.reply_count || 0}</span>
            </Link>
          </div>

          {/* 分享 */}
          <button
            className="flex items-center gap-1.5 text-muted-foreground hover:text-primary transition-colors min-h-10 min-w-10"
            onClick={(e) => {
              e.preventDefault();
              // TODO: 分享功能
            }}
          >
            <Share2 className="h-4 w-4" />
          </button>
        </div>
      </div>
    </Card>
  );
}
