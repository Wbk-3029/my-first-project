import { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { MainLayout } from '@/components/layouts/MainLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { SkillCard } from '@/components/skill/SkillCard';
import { PublishSkillDialog } from '@/components/skill/PublishSkillDialog';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { getSkills, getHotVideos, getRecommendations, getRecommendedSkills, type RecommendedSkill } from '@/db/api';
import type { Skill, SkillType, HotVideo, Recommendation } from '@/types';
import { SKILL_TYPE_LABELS } from '@/types';
import { 
  Search, 
  Filter, 
  RotateCcw, 
  Play, 
  Eye, 
  ThumbsUp, 
  ArrowLeft,
  Sparkles,
  TrendingUp,
  ChevronRight,
  Star,
  Coins
} from 'lucide-react';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';

export default function SkillMarketPage() {
  const navigate = useNavigate();
  const { profile } = useAuth();
  const [skills, setSkills] = useState<Skill[]>([]);
  const [hotVideos, setHotVideos] = useState<HotVideo[]>([]);
  const [recommendations, setRecommendations] = useState<Recommendation[]>([]);
  const [recommendedSkills, setRecommendedSkills] = useState<RecommendedSkill[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [mobileFilterOpen, setMobileFilterOpen] = useState(false);

  // 筛选条件
  const [selectedTypes, setSelectedTypes] = useState<SkillType[]>([]);
  const [selectedPriceRange, setSelectedPriceRange] = useState<string[]>([]);
  const [selectedExchangeModes, setSelectedExchangeModes] = useState<string[]>([]);
  const [minCreditScore, setMinCreditScore] = useState<number>(0);

  useEffect(() => {
    loadData();
  }, [selectedTypes, selectedPriceRange, selectedExchangeModes, minCreditScore, searchQuery]);

  const loadData = async () => {
    try {
      setLoading(true);
      
      // 并行加载数据
      const [skillsData, hotVideosData, recommendationsData, recommendedSkillsData] = await Promise.all([
        getSkills({ sortBy: 'hot' }),
        getHotVideos(),
        getRecommendations(),
        getRecommendedSkills(profile?.id, 10),
      ]);
      
      // 应用筛选条件
      let filteredSkills = skillsData;
      
      if (selectedTypes.length > 0) {
        filteredSkills = filteredSkills.filter((s) => selectedTypes.includes(s.type));
      }
      
      if (selectedPriceRange.length > 0) {
        filteredSkills = filteredSkills.filter((s) => {
          return selectedPriceRange.some((range) => {
            if (range === '0-10') return s.price >= 0 && s.price <= 10;
            if (range === '10-20') return s.price > 10 && s.price <= 20;
            if (range === '20-50') return s.price > 20 && s.price <= 50;
            if (range === '50+') return s.price > 50;
            return false;
          });
        });
      }
      
      if (selectedExchangeModes.length > 0) {
        filteredSkills = filteredSkills.filter((s) => {
          if (selectedExchangeModes.includes('direct') && s.required_skills) return true;
          if (selectedExchangeModes.includes('point') && !selectedExchangeModes.includes('direct')) return true;
          return false;
        });
      }
      
      if (minCreditScore > 0 && filteredSkills.length > 0) {
        filteredSkills = filteredSkills.filter((s) => s.profiles && s.profiles.credit_score >= minCreditScore);
      }
      
      if (searchQuery) {
        const query = searchQuery.toLowerCase();
        filteredSkills = filteredSkills.filter(
          (s) =>
            s.name.toLowerCase().includes(query) ||
            s.description?.toLowerCase().includes(query) ||
            s.profiles?.nickname?.toLowerCase().includes(query)
        );
      }
      
      setSkills(filteredSkills);
      setHotVideos(hotVideosData);
      setRecommendations(recommendationsData);
      setRecommendedSkills(recommendedSkillsData);
    } catch (error) {
      console.error('加载数据失败:', error);
      toast.error('加载数据失败');
    } finally {
      setLoading(false);
    }
  };

  const handleResetFilters = () => {
    setSelectedTypes([]);
    setSelectedPriceRange([]);
    setSelectedExchangeModes([]);
    setMinCreditScore(0);
    setSearchQuery('');
  };

  const toggleType = (type: SkillType) => {
    setSelectedTypes((prev) =>
      prev.includes(type) ? prev.filter((t) => t !== type) : [...prev, type]
    );
  };

  const togglePriceRange = (range: string) => {
    setSelectedPriceRange((prev) =>
      prev.includes(range) ? prev.filter((r) => r !== range) : [...prev, range]
    );
  };

  const toggleExchangeMode = (mode: string) => {
    setSelectedExchangeModes((prev) =>
      prev.includes(mode) ? prev.filter((m) => m !== mode) : [...prev, mode]
    );
  };

  // 筛选边栏内容
  const FilterSidebar = () => (
    <div className="space-y-6">
      <div>
        <h3 className="font-semibold text-lg mb-4">技能分类</h3>
        <div className="space-y-3">
          {(Object.keys(SKILL_TYPE_LABELS) as SkillType[]).map((type) => (
            <div key={type} className="flex items-center space-x-2">
              <Checkbox
                id={`type-${type}`}
                checked={selectedTypes.includes(type)}
                onCheckedChange={() => toggleType(type)}
              />
              <Label
                htmlFor={`type-${type}`}
                className="text-sm font-normal cursor-pointer"
              >
                {SKILL_TYPE_LABELS[type]}
              </Label>
            </div>
          ))}
        </div>
      </div>

      <Separator />

      <div>
        <h3 className="font-semibold text-base mb-4">价格区间</h3>
        <div className="space-y-3">
          {[
            { value: '0-10', label: '0-10 技易点' },
            { value: '10-20', label: '10-20 技易点' },
            { value: '20-50', label: '20-50 技易点' },
            { value: '50+', label: '50+ 技易点' },
          ].map((range) => (
            <div key={range.value} className="flex items-center space-x-2">
              <Checkbox
                id={`price-${range.value}`}
                checked={selectedPriceRange.includes(range.value)}
                onCheckedChange={() => togglePriceRange(range.value)}
              />
              <Label
                htmlFor={`price-${range.value}`}
                className="text-sm font-normal cursor-pointer"
              >
                {range.label}
              </Label>
            </div>
          ))}
        </div>
      </div>

      <Separator />

      <div>
        <h3 className="font-semibold text-base mb-4">交换模式</h3>
        <div className="space-y-3">
          {[
            { value: 'direct', label: '直接交换' },
            { value: 'point', label: '技易点交换' },
            { value: 'group', label: '团购' },
          ].map((mode) => (
            <div key={mode.value} className="flex items-center space-x-2">
              <Checkbox
                id={`mode-${mode.value}`}
                checked={selectedExchangeModes.includes(mode.value)}
                onCheckedChange={() => toggleExchangeMode(mode.value)}
              />
              <Label
                htmlFor={`mode-${mode.value}`}
                className="text-sm font-normal cursor-pointer"
              >
                {mode.label}
              </Label>
            </div>
          ))}
        </div>
      </div>

      <Separator />

      <div>
        <h3 className="font-semibold text-base mb-4">信用分筛选</h3>
        <div className="space-y-3">
          {[
            { value: 0, label: '不限' },
            { value: 60, label: '60分以上' },
            { value: 80, label: '80分以上' },
            { value: 95, label: '95分以上' },
          ].map((score) => (
            <div key={score.value} className="flex items-center space-x-2">
              <Checkbox
                id={`credit-${score.value}`}
                checked={minCreditScore === score.value}
                onCheckedChange={() => setMinCreditScore(score.value)}
              />
              <Label
                htmlFor={`credit-${score.value}`}
                className="text-sm font-normal cursor-pointer"
              >
                {score.label}
              </Label>
            </div>
          ))}
        </div>
      </div>

      <Button
        variant="outline"
        className="w-full gap-2"
        onClick={handleResetFilters}
      >
        <RotateCcw className="h-4 w-4" />
        重置筛选
      </Button>
    </div>
  );

  return (
    <MainLayout>
      <div className="flex flex-col lg:flex-row gap-6">
        {/* 左侧筛选边栏 - 桌面端 */}
        <aside className="hidden lg:block w-72 shrink-0">
          <Card className="sticky top-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Filter className="h-5 w-5" />
                筛选条件
              </CardTitle>
            </CardHeader>
            <CardContent className="max-h-[calc(100vh-200px)] overflow-y-auto">
              <FilterSidebar />
            </CardContent>
          </Card>
        </aside>

        {/* 右侧主内容区 */}
        <div className="flex-1 space-y-6">
          {/* 顶部操作栏 */}
          <div className="flex flex-col sm:flex-row gap-4">
            <Button
              variant="ghost"
              size="sm"
              className="gap-2 self-start"
              onClick={() => navigate(-1)}
            >
              <ArrowLeft className="h-4 w-4" />
              返回
            </Button>

            {/* 移动端筛选按钮 */}
            <Sheet open={mobileFilterOpen} onOpenChange={setMobileFilterOpen}>
              <SheetTrigger asChild>
                <Button variant="outline" className="lg:hidden gap-2">
                  <Filter className="h-4 w-4" />
                  筛选
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-80 overflow-y-auto">
                <SheetHeader>
                  <SheetTitle>筛选条件</SheetTitle>
                </SheetHeader>
                <div className="mt-6">
                  <FilterSidebar />
                </div>
              </SheetContent>
            </Sheet>

            {/* 搜索栏 */}
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="搜索技能名称或用户昵称..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>

            {/* 发布技能按钮 */}
            <PublishSkillDialog onPublishSuccess={loadData} />
          </div>

          {/* 为你推荐板块 */}
          {recommendedSkills.length > 0 && (
            <Card className="rounded-xl">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Sparkles className="h-5 w-5 text-primary" />
                    <CardTitle>为你推荐</CardTitle>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => navigate('/profile/interests')}
                    className="text-sm text-muted-foreground hover:text-primary"
                  >
                    设置兴趣
                    <ChevronRight className="h-4 w-4 ml-1" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {recommendedSkills.map((skill) => (
                    <Card
                      key={skill.skill_id}
                      className="hover:shadow-lg transition-all hover:border-primary/50 cursor-pointer group"
                      onClick={() => navigate(`/skills/${skill.skill_id}`)}
                    >
                      <CardContent className="p-4 space-y-3">
                        {/* 匹配度徽章 */}
                        <div className="flex items-center justify-between">
                          <Badge variant="secondary" className="bg-primary/10 text-primary">
                            <Sparkles className="h-3 w-3 mr-1" />
                            {Math.round(skill.match_score)}%匹配
                          </Badge>
                          <Badge variant="outline">
                            {SKILL_TYPE_LABELS[skill.skill_type as SkillType]}
                          </Badge>
                        </div>

                        {/* 技能名称 */}
                        <div>
                          <h3 className="font-semibold text-lg group-hover:text-primary transition-colors line-clamp-1">
                            {skill.skill_name}
                          </h3>
                          <p className="text-sm text-muted-foreground line-clamp-2 mt-1">
                            {skill.skill_description}
                          </p>
                        </div>

                        {/* 提供者信息 */}
                        <div className="flex items-center gap-2">
                          <Avatar className="h-8 w-8">
                            <AvatarImage src={skill.provider_avatar || undefined} />
                            <AvatarFallback>
                              {skill.provider_nickname?.charAt(0) || '?'}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1 min-w-0">
                            <div className="text-sm font-medium truncate">
                              {skill.provider_nickname}
                            </div>
                            <div className="flex items-center gap-2 text-xs text-muted-foreground">
                              <div className="flex items-center gap-1">
                                <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                                <span>{skill.provider_credit}</span>
                              </div>
                              <span>•</span>
                              <span>{skill.exchange_count}次交换</span>
                            </div>
                          </div>
                        </div>

                        {/* 价格 */}
                        <div className="flex items-center justify-between pt-2 border-t">
                          <div className="flex items-center gap-1 text-primary font-semibold">
                            <Coins className="h-4 w-4" />
                            <span>{skill.skill_price}</span>
                            <span className="text-xs text-muted-foreground">技易点</span>
                          </div>
                          <div className="flex items-center text-sm text-primary font-medium">
                            查看详情
                            <ChevronRight className="h-4 w-4 ml-1" />
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* 热门视频专区 */}
          {hotVideos.length > 0 && (
            <Card>

            </Card>
          )}

          {/* 推荐位 */}
          {recommendations.length > 0 && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {recommendations.map((rec) => (
                <Link key={rec.id} to={rec.link}>
                  <Card className="h-full hover:shadow-lg transition-all hover:border-primary/50 group">
                    <CardContent className="p-0">
                      <div className="relative aspect-video rounded-t-lg overflow-hidden bg-muted">
                        <img
                          src={rec.cover_image}
                          alt={rec.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                        />
                        {rec.is_paid && (
                          <Badge className="absolute top-2 right-2 bg-amber-500">
                            <Sparkles className="h-3 w-3 mr-1" />
                            推荐
                          </Badge>
                        )}
                      </div>
                      <div className="p-4 space-y-2">

                        {rec.description && (
                          <p className="text-sm text-muted-foreground line-clamp-2">
                            {rec.description}
                          </p>
                        )}
                        <div className="flex items-center text-sm text-primary font-medium">
                          查看详情
                          <ChevronRight className="h-4 w-4 ml-1" />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          )}

          {/* 技能列表 */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                技能广场
              </h2>
              <span className="text-sm text-muted-foreground">
                共 {skills.length} 个技能
              </span>
            </div>

            {loading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {[1, 2, 3, 4].map((i) => (
                  <Card key={i}>
                    <CardHeader>
                      <Skeleton className="h-6 w-3/4 bg-muted" />
                      <Skeleton className="h-4 w-full bg-muted" />
                    </CardHeader>
                    <CardContent>
                      <Skeleton className="h-4 w-1/2 bg-muted" />
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : skills.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center text-muted-foreground">
                  暂无符合条件的技能
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {skills.map((skill) => (
                  <SkillCard key={skill.id} skill={skill} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
