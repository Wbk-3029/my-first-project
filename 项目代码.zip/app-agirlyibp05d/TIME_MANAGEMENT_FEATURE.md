# 交换时间管理功能说明

## 功能概述
交换时间管理功能为技遇平台提供完整的时间预约、冲突检查、改期申请和未履约举报等功能，确保交换的顺利进行和用户权益的保护。

---

## 1. 数据库设计

### 1.1 reschedule_requests表
改期申请表

| 字段名 | 类型 | 说明 |
|--------|------|------|
| id | uuid | 主键 |
| exchange_id | uuid | 交换ID |
| requester_id | uuid | 申请人ID |
| old_start_time | timestamptz | 原开始时间 |
| new_start_time | timestamptz | 新开始时间 |
| reason | text | 改期原因 |
| status | text | 状态（pending/approved/rejected） |
| created_at | timestamptz | 创建时间 |
| updated_at | timestamptz | 更新时间 |

**索引**:
- idx_reschedule_requests_exchange: exchange_id索引
- idx_reschedule_requests_requester: requester_id索引
- idx_reschedule_requests_status: status索引

**RLS策略**:
- 用户可以查看相关的改期申请
- 用户可以创建改期申请
- 用户可以更新改期申请状态

### 1.2 breach_reports表
未履约举报表

| 字段名 | 类型 | 说明 |
|--------|------|------|
| id | uuid | 主键 |
| exchange_id | uuid | 交换ID |
| reporter_id | uuid | 举报人ID |
| reported_id | uuid | 被举报人ID |
| evidence | text | 证据（如聊天记录） |
| status | text | 状态（pending/processing/resolved/rejected） |
| resolution | text | 处理结果 |
| created_at | timestamptz | 创建时间 |
| updated_at | timestamptz | 更新时间 |

**索引**:
- idx_breach_reports_exchange: exchange_id索引
- idx_breach_reports_reporter: reporter_id索引
- idx_breach_reports_reported: reported_id索引
- idx_breach_reports_status: status索引

**RLS策略**:
- 用户可以查看相关的举报
- 用户可以创建举报

---

## 2. RPC函数

### 2.1 check_time_conflict
检查时间冲突

**参数**:
- `p_user_id`: 用户ID
- `p_start_time`: 开始时间
- `p_duration`: 时长（小时）

**返回**:
```json
{
  "has_conflict": false,
  "conflict_count": 0
}
```

**业务逻辑**:
1. 计算结束时间（开始时间 + 时长）
2. 查询用户的所有进行中或已接受的交换
3. 检查新时间段是否与现有时间段冲突
4. 冲突判断：
   - 新时间段的开始时间在现有时间段内
   - 新时间段的结束时间在现有时间段内
   - 新时间段包含现有时间段
5. 返回是否有冲突和冲突数量

### 2.2 create_reschedule_request
创建改期申请

**参数**:
- `p_exchange_id`: 交换ID
- `p_new_start_time`: 新开始时间
- `p_reason`: 改期原因

**返回**:
```json
{
  "success": true,
  "request_id": "uuid",
  "message": "改期申请已发送"
}
```

**业务逻辑**:
1. 检查交换是否存在且状态为in_progress
2. 检查是否已有待处理的改期申请
3. 获取对方用户ID
4. 检查对方在新时间段是否有冲突
5. 如果有冲突，抛出异常
6. 创建改期申请记录
7. 返回成功结果

### 2.3 handle_reschedule_request
处理改期申请

**参数**:
- `p_request_id`: 改期申请ID
- `p_action`: 操作（approve/reject）

**返回**:
```json
{
  "success": true,
  "message": "已同意改期申请"
}
```

**业务逻辑**:
1. 检查action参数（approve/reject）
2. 获取改期申请信息
3. 检查申请状态是否为pending
4. 检查用户是否有权处理（必须是对方，不能是申请人）
5. 如果同意：
   - 更新改期申请状态为approved
   - 更新交换时间为新时间
6. 如果拒绝：
   - 更新改期申请状态为rejected
7. 返回成功结果

### 2.4 create_breach_report
创建未履约举报

**参数**:
- `p_exchange_id`: 交换ID
- `p_reported_id`: 被举报人ID
- `p_evidence`: 证据

**返回**:
```json
{
  "success": true,
  "report_id": "uuid",
  "message": "举报已提交，平台将尽快处理"
}
```

**业务逻辑**:
1. 检查交换是否存在且状态为in_progress
2. 检查是否已举报
3. 检查是否在约定时间后15分钟
4. 创建举报记录
5. 返回成功结果

---

## 3. API函数

### 3.1 checkTimeConflict
检查时间冲突

```typescript
checkTimeConflict(
  userId: string,
  startTime: string,
  duration: number
): Promise<{ hasConflict: boolean; conflictCount: number }>
```

### 3.2 createRescheduleRequest
创建改期申请

```typescript
createRescheduleRequest(params: {
  exchangeId: string;
  newStartTime: string;
  reason: string;
}): Promise<{ success: boolean; requestId: string; message: string }>
```

### 3.3 handleRescheduleRequest
处理改期申请

```typescript
handleRescheduleRequest(
  requestId: string,
  action: 'approve' | 'reject'
): Promise<{ success: boolean; message: string }>
```

### 3.4 getRescheduleRequests
获取改期申请列表

```typescript
getRescheduleRequests(exchangeId: string): Promise<RescheduleRequest[]>
```

### 3.5 createBreachReport
创建未履约举报

```typescript
createBreachReport(params: {
  exchangeId: string;
  reportedId: string;
  evidence: string;
}): Promise<{ success: boolean; reportId: string; message: string }>
```

### 3.6 getBreachReports
获取举报列表

```typescript
getBreachReports(exchangeId: string): Promise<BreachReport[]>
```

---

## 4. 前端组件

### 4.1 RescheduleDialog
改期申请对话框

**位置**: src/components/exchange/RescheduleDialog.tsx

**Props**:
- `exchangeId`: 交换ID
- `currentStartTime`: 当前开始时间
- `trigger`: 触发按钮（可选）
- `onSuccess`: 成功回调（可选）

**功能**:
- 选择新的日期（未来7天内）
- 选择时间段（08:00-21:00，每小时一个时段）
- 填写改期原因
- 提交改期申请

**日期选择**:
- 使用Calendar组件
- 禁用今天之前的日期
- 禁用7天之后的日期
- 显示"支持预约未来7天内的时段"提示

**时间段选择**:
- 使用Select组件
- 12个时间段：08:00-09:00, 09:00-10:00, ..., 20:00-21:00
- 每个时段1小时

**改期原因**:
- 使用Textarea组件
- 必填
- 最多500字

**提交流程**:
1. 验证表单数据
2. 组合日期和时间
3. 调用createRescheduleRequest API
4. 显示成功提示
5. 关闭对话框
6. 调用onSuccess回调

### 4.2 BreachReportDialog
未履约举报对话框

**位置**: src/components/exchange/BreachReportDialog.tsx

**Props**:
- `exchangeId`: 交换ID
- `reportedId`: 被举报人ID
- `reportedName`: 被举报人昵称
- `trigger`: 触发按钮（可选）
- `onSuccess`: 成功回调（可选）

**功能**:
- 填写证据说明
- 提交举报

**证据说明**:
- 使用Textarea组件
- 必填
- 最多1000字
- 显示字数统计

**举报须知**:
- 只能在约定时间后15分钟举报未履约
- 请提供真实有效的证据
- 平台将在3个工作日内处理
- 恶意举报将影响你的信用分

**提交流程**:
1. 验证证据说明
2. 调用createBreachReport API
3. 显示成功提示
4. 关闭对话框
5. 调用onSuccess回调

---

## 5. ExchangeDetailPage更新

### 5.1 新增功能
- 显示改期申请列表
- 处理改期申请（同意/拒绝）
- 申请改期按钮
- 举报未履约按钮

### 5.2 改期申请列表
**显示内容**:
- 申请人（你/对方）
- 申请状态（待处理/已同意/已拒绝）
- 原时间
- 新时间
- 改期原因

**操作按钮**:
- 如果是对方发起且状态为待处理，显示"同意"和"拒绝"按钮
- 如果是自己发起或已处理，不显示操作按钮

**状态徽章**:
- pending: 灰色，"待处理"
- approved: 蓝色，"已同意"
- rejected: 红色，"已拒绝"

### 5.3 申请改期按钮
**显示条件**:
- 交换状态为in_progress
- 交换有start_time

**点击行为**:
- 打开RescheduleDialog对话框
- 显示当前约定时间
- 选择新的日期和时间段
- 填写改期原因
- 提交申请

### 5.4 举报未履约按钮
**显示条件**:
- 交换状态为in_progress
- 约定时间后15分钟

**点击行为**:
- 打开BreachReportDialog对话框
- 填写证据说明
- 提交举报

**判断逻辑**:
```typescript
const canReportBreach = () => {
  if (!exchange?.start_time) return false;
  const startTime = new Date(exchange.start_time);
  const now = new Date();
  const minutesSinceStart = (now.getTime() - startTime.getTime()) / (1000 * 60);
  return minutesSinceStart >= 15;
};
```

---

## 6. 业务流程

### 6.1 时间冲突检查流程
1. 用户选择交换时间
2. 系统调用check_time_conflict RPC函数
3. 系统查询用户的所有进行中或已接受的交换
4. 系统检查新时间段是否与现有时间段冲突
5. 如果有冲突，提示用户重新选择
6. 如果无冲突，允许创建交换

### 6.2 改期申请流程
1. 用户在交换详情页点击"申请改期"按钮
2. 系统打开改期申请对话框
3. 用户选择新的日期和时间段
4. 用户填写改期原因
5. 用户点击"发起申请"按钮
6. 系统检查对方在新时间段是否有冲突
7. 如果有冲突，提示"对方在该时间段有其他交换安排"
8. 如果无冲突，创建改期申请记录
9. 系统发送通知给对方
10. 对方在交换详情页查看改期申请
11. 对方点击"同意"或"拒绝"按钮
12. 如果同意，更新交换时间
13. 如果拒绝，改期申请状态更新为rejected
14. 系统发送通知给申请人

### 6.3 未履约举报流程
1. 约定时间后15分钟，用户在交换详情页点击"举报未履约"按钮
2. 系统打开未履约举报对话框
3. 用户填写证据说明
4. 用户点击"提交举报"按钮
5. 系统创建举报记录
6. 系统发送通知给平台管理员
7. 平台管理员在3个工作日内处理举报
8. 平台管理员审核证据
9. 如果举报属实，扣除被举报人信用分
10. 如果举报不实，扣除举报人信用分
11. 系统发送处理结果通知给双方

---

## 7. 时间管理规则

### 7.1 时间预约规则
- 支持预约未来7天内的时段
- 时间段：08:00-21:00，每小时一个时段
- 每个时段1小时
- 不能预约今天之前的日期
- 不能预约7天之后的日期

### 7.2 时间冲突规则
**冲突判断**:
- 新时间段的开始时间在现有时间段内
- 新时间段的结束时间在现有时间段内
- 新时间段包含现有时间段

**冲突检查时机**:
- 创建交换申请时
- 创建改期申请时

**冲突处理**:
- 如果有冲突，提示用户重新选择时间
- 不允许创建冲突的交换或改期申请

### 7.3 改期规则
- 只能在交换状态为in_progress时申请改期
- 同一交换同时只能有一个待处理的改期申请
- 改期申请需要对方同意
- 改期后交换时间更新为新时间
- 改期申请被拒绝后可以重新发起

### 7.4 未履约举报规则
- 只能在约定时间后15分钟举报未履约
- 只能在交换状态为in_progress时举报
- 同一交换只能举报一次
- 举报需要提供证据
- 平台将在3个工作日内处理
- 恶意举报将影响举报人信用分

---

## 8. 用户界面

### 8.1 改期申请对话框
- 标题: "申请改期"
- 当前约定时间: 显示格式化的时间
- 新的日期: Calendar组件
- 时间段: Select组件
- 改期原因: Textarea组件
- 操作按钮: 取消、发起申请

### 8.2 未履约举报对话框
- 标题: "举报未履约"（红色，带警告图标）
- 举报对象: 显示被举报人昵称
- 证据说明: Textarea组件
- 举报须知: 提示信息
- 操作按钮: 取消、提交举报

### 8.3 交换详情页
- 改期申请列表: 显示所有改期申请
- 申请改期按钮: 进行中状态显示
- 举报未履约按钮: 约定时间后15分钟显示

---

## 9. 错误处理

### 9.1 前端验证
- 检查日期是否选择
- 检查时间段是否选择
- 检查改期原因是否填写
- 检查证据说明是否填写

### 9.2 后端验证
- 检查交换是否存在
- 检查交换状态
- 检查用户权限
- 检查是否已有待处理的改期申请
- 检查对方在新时间段是否有冲突
- 检查是否已举报
- 检查是否在约定时间后15分钟

### 9.3 错误提示
- "请填写完整信息"
- "交换不存在或无权操作"
- "已有待处理的改期申请"
- "对方在该时间段有其他交换安排"
- "你已经举报过此次交换"
- "只能在约定时间后15分钟举报未履约"
- "提交失败"

---

## 10. 性能优化

### 10.1 数据库优化
- 使用索引加速查询
- 使用RLS策略限制数据访问
- 使用RPC函数封装业务逻辑
- 使用时间范围查询优化冲突检查

### 10.2 前端优化
- 使用Promise.all并行加载数据
- 使用骨架屏提升加载体验
- 操作后刷新页面

---

## 11. 安全性

### 11.1 RLS策略
- 用户只能查看相关的改期申请
- 用户只能查看相关的举报
- 用户只能创建自己的改期申请和举报

### 11.2 业务逻辑
- 检查用户权限
- 检查交换状态
- 检查时间冲突
- 检查是否重复操作
- 使用SECURITY DEFINER确保权限

---

## 12. 扩展功能

### 12.1 交换提醒（待实现）
**功能**:
- 约定时间前1小时提醒
- 约定时间前15分钟提醒

**实现方案**:
1. 创建Edge Function定时任务
2. 每5分钟查询即将开始的交换
3. 检查是否已发送提醒
4. 发送应用内通知
5. 记录提醒状态

### 12.2 自动取消（待实现）
**功能**:
- 约定时间后30分钟未开始，自动取消交换

**实现方案**:
1. 创建Edge Function定时任务
2. 每10分钟查询超时的交换
3. 检查交换状态
4. 自动取消交换
5. 发送通知给双方

### 12.3 改期次数限制
**功能**:
- 同一交换最多改期3次

**实现方案**:
1. 在reschedule_requests表添加计数字段
2. 创建改期申请时检查次数
3. 超过限制时提示用户

### 12.4 举报处理流程
**功能**:
- 平台管理员审核举报
- 处理结果通知双方

**实现方案**:
1. 创建管理员后台
2. 显示待处理的举报列表
3. 管理员审核证据
4. 管理员填写处理结果
5. 更新举报状态
6. 扣除信用分
7. 发送通知给双方

---

## 13. 测试建议

### 13.1 功能测试
1. 测试时间冲突检查
2. 测试创建改期申请
3. 测试处理改期申请
4. 测试创建未履约举报
5. 测试举报时间限制

### 13.2 边界测试
1. 测试预约今天之前的日期
2. 测试预约7天之后的日期
3. 测试重复创建改期申请
4. 测试重复举报
5. 测试约定时间后15分钟之前举报

### 13.3 性能测试
1. 测试大量交换的时间冲突检查
2. 测试并发创建改期申请

---

## 14. 常见问题

### Q1: 为什么只能预约未来7天内的时段？
A: 为了避免长期预约导致的时间浪费，限制预约时间在7天内。

### Q2: 改期申请被拒绝后可以重新发起吗？
A: 可以，改期申请被拒绝后可以重新发起。

### Q3: 为什么要在约定时间后15分钟才能举报未履约？
A: 给对方一定的缓冲时间，避免因为迟到几分钟就被举报。

### Q4: 举报未履约会影响信用分吗？
A: 如果举报属实，被举报人信用分会被扣除；如果举报不实，举报人信用分会被扣除。

### Q5: 改期申请需要多久处理？
A: 对方可以随时处理改期申请，建议在24小时内处理。

---

## 15. 更新日志

### v1.0.0 (2026-03-23)
- 初始版本
- 创建reschedule_requests表（改期申请）
- 创建breach_reports表（未履约举报）
- 创建check_time_conflict RPC函数（检查时间冲突）
- 创建create_reschedule_request RPC函数（创建改期申请）
- 创建handle_reschedule_request RPC函数（处理改期申请）
- 创建create_breach_report RPC函数（创建未履约举报）
- 创建API函数：checkTimeConflict、createRescheduleRequest、handleRescheduleRequest、getRescheduleRequests、createBreachReport、getBreachReports
- 创建RescheduleDialog组件（改期申请对话框）
- 创建BreachReportDialog组件（未履约举报对话框）
- 更新ExchangeDetailPage页面（显示改期申请列表、申请改期按钮、举报未履约按钮）

---

## 16. 技术实现细节

### 16.1 时间冲突检查算法
使用区间重叠算法检查时间冲突：
```sql
-- 新时间段的开始时间在现有时间段内
(p_start_time >= e.start_time AND p_start_time < e.start_time + interval)
OR
-- 新时间段的结束时间在现有时间段内
(v_end_time > e.start_time AND v_end_time <= e.start_time + interval)
OR
-- 新时间段包含现有时间段
(p_start_time <= e.start_time AND v_end_time >= e.start_time + interval)
```

### 16.2 日期时间组合
前端组合日期和时间：
```typescript
const [startHour] = formData.timeSlot.split('-')[0].split(':');
const newStartTime = new Date(formData.date);
newStartTime.setHours(parseInt(startHour), 0, 0, 0);
```

### 16.3 举报时间判断
计算约定时间后经过的分钟数：
```typescript
const startTime = new Date(exchange.start_time);
const now = new Date();
const minutesSinceStart = (now.getTime() - startTime.getTime()) / (1000 * 60);
return minutesSinceStart >= 15;
```

---

## 17. 界面设计规范

### 17.1 颜色规范
- 改期申请: 蓝色
- 未履约举报: 红色
- 待处理: 灰色
- 已同意: 蓝色
- 已拒绝: 红色

### 17.2 间距规范
- 卡片间距: 16px（space-y-4）
- 卡片内边距: 16px（p-4）
- 元素间距: 12px（space-y-3）

### 17.3 字体规范
- 标题: 18px（text-title-lg）
- 正文: 14px（text-sm）
- 辅助: 12px（text-xs）

### 17.4 交互规范
- 按钮最小高度: 44px
- 输入框最小高度: 44px
- 对话框最大宽度: 28rem（max-w-md）

---

## 18. 数据流图

```
用户 → RescheduleDialog → createRescheduleRequest → create_reschedule_request RPC
                                                    → 检查交换状态
                                                    → 检查待处理申请
                                                    → 检查时间冲突
                                                    → 创建改期申请
                                                    → 返回结果

用户 → ExchangeDetailPage → handleReschedule → handle_reschedule_request RPC
                                              → 检查申请状态
                                              → 检查用户权限
                                              → 更新申请状态
                                              → 更新交换时间（如果同意）
                                              → 返回结果

用户 → BreachReportDialog → createBreachReport → create_breach_report RPC
                                                → 检查交换状态
                                                → 检查是否已举报
                                                → 检查时间限制
                                                → 创建举报记录
                                                → 返回结果
```

---

**最后更新**: 2026-03-23
**版本**: v1.0.0
**维护者**: 技遇开发团队
