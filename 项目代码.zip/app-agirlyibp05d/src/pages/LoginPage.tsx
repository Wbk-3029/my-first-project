import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useLoginDialog } from '@/contexts/LoginDialogContext';

export default function LoginPage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { openLoginDialog } = useLoginDialog();

  useEffect(() => {
    if (user) {
      navigate('/');
    } else {
      openLoginDialog();
    }
  }, [user, navigate, openLoginDialog]);

  return null;
}
