import { useState, useEffect } from 'react';
import { supabase } from '@/db/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { toast } from 'sonner';
import { Loader2, Smartphone } from 'lucide-react';

interface BindPhoneDialogProps {
  onBindSuccess: () => void;
}

export function BindPhoneDialog({ onBindSuccess }: BindPhoneDialogProps) {
  const { sendSmsCode, user } = useAuth();
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [sendingCode, setSendingCode] = useState(false);
  const [countdown, setCountdown] = useState(0);
  const [sessionId, setSessionId] = useState('');
  const [phone, setPhone] = useState('');
  const [code, setCode] = useState('');

  useEffect(() => {
    let timer: ReturnType<typeof setInterval>;
    if (countdown > 0) {
      timer = setInterval(() => {
        setCountdown((prev) => {
          if (prev <= 1) {
            clearInterval(timer);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [countdown]);

  const handleSendCode = async () => {
    if (!phone) {
      toast.error('请输入手机号');
      return;
    }

    if (!/^1[3-9]\d{9}$/.test(phone)) {
      toast.error('请输入正确的手机号');
      return;
    }

    setSendingCode(true);

    try {
      const { error, sessionId: newSessionId } = await sendSmsCode(phone);

      if (error) {
        toast.error(error.message || '发送失败');
        return;
      }

      if (newSessionId) {
        setSessionId(newSessionId);
      }

      toast.success('验证码已发送');
      setCountdown(60);
    } catch (error) {
      toast.error('发送失败,请重试');
    } finally {
      setSendingCode(false);
    }
  };

  const handleBind = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!phone || !code) {
      toast.error('请填写完整信息');
      return;
    }

    if (!sessionId) {
      toast.error('请先获取验证码');
      return;
    }

    setLoading(true);

    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session) {
        toast.error('请先登录');
        return;
      }

      const { data, error } = await supabase.functions.invoke('bind-phone', {
        body: { phone, code, sessionId },
        headers: {
          Authorization: `Bearer ${session.access_token}`,
        },
      });

      if (error) {
        const errorMsg = await error?.context?.text();
        toast.error(errorMsg || error.message || '绑定失败');
        return;
      }

      if (!data.success) {
        toast.error(data.error || '绑定失败');
        return;
      }

      toast.success('绑定成功');
      setOpen(false);
      setPhone('');
      setCode('');
      setSessionId('');
      onBindSuccess();
    } catch (error) {
      toast.error('绑定失败,请重试');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <Smartphone className="h-4 w-4 mr-2" />
          绑定手机号
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>绑定手机号</DialogTitle>
          <DialogDescription>
            绑定手机号后可以使用手机号+密码登录
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleBind} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="bind-phone">手机号</Label>
            <Input
              id="bind-phone"
              type="tel"
              placeholder="请输入手机号"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="bind-code">验证码</Label>
            <div className="flex gap-2">
              <Input
                id="bind-code"
                type="text"
                placeholder="请输入验证码"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                required
              />
              <Button
                type="button"
                variant="outline"
                onClick={handleSendCode}
                disabled={sendingCode || countdown > 0}
                className="shrink-0 w-28"
              >
                {sendingCode && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                {countdown > 0 ? `${countdown}秒` : '获取验证码'}
              </Button>
            </div>
          </div>
          <Button type="submit" className="w-full" disabled={loading}>
            {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            确认绑定
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
