import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { Check, Sparkles, ArrowRight, ArrowLeft } from 'lucide-react';
import { supabase } from '@/db/supabase';
import { updatePoints } from '@/db/api';
import confetti from 'canvas-confetti';

const SKILL_OPTIONS = [
  '英语/编程',
  'PS/视频剪辑',
  '吉他/声乐',
  '摄影',
  '考研/考证',
  '化妆穿搭',
  '游戏娱乐',
  '演讲表达',
  '其他',
];

const TIME_OPTIONS = [
  { value: 'weekday_day', label: '周一至周五白天' },
  { value: 'weekday_night', label: '周一至周五晚上' },
  { value: 'weekend', label: '周末全天' },
  { value: 'flexible', label: '灵活安排' },
];

export default function OnboardingPage() {
  const { user, profile, refreshProfile } = useAuth();
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);

  const [wantToLearn, setWantToLearn] = useState<string[]>([]);
  const [canTeach, setCanTeach] = useState<string[]>([]);
  const [availableTime, setAvailableTime] = useState<string>('');

  const progress = (step / 3) * 100;

  // 切换技能选择
  const toggleSkill = (skill: string, type: 'learn' | 'teach') => {
    if (type === 'learn') {
      setWantToLearn((prev) =>
        prev.includes(skill) ? prev.filter((s) => s !== skill) : [...prev, skill]
      );
    } else {
      setCanTeach((prev) =>
        prev.includes(skill) ? prev.filter((s) => s !== skill) : [...prev, skill]
      );
    }
  };

  // 下一步
  const handleNext = () => {
    if (step === 1 && wantToLearn.length === 0) {
      toast.error('请至少选择一项想学的技能');
      return;
    }
    if (step === 3 && !availableTime) {
      toast.error('请选择你的空闲时间偏好');
      return;
    }
    setStep(step + 1);
  };

  // 上一步
  const handleBack = () => {
    setStep(step - 1);
  };

  // 完成引导
  const handleComplete = async () => {
    if (!user) return;

    setLoading(true);
    try {
      // 更新用户资料
      const { error: updateError } = await supabase
        .from('profiles')
        // @ts-ignore - Supabase类型推断问题
        .update({
          onboarding_completed: true,
          skills_want_to_learn: wantToLearn,
          skills_can_teach: canTeach,
          available_time: availableTime,
        })
        .eq('id', user.id);

      if (updateError) throw updateError;

      // 发放50技易点
      await updatePoints(user.id, 50, 'onboarding_reward', '新手引导奖励');

      // 刷新用户资料
      await refreshProfile();

      // 进入完成页面
      setStep(4);

      // 播放庆祝动画
      setTimeout(() => {
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 },
        });
      }, 100);

      toast.success('恭喜！你已获得50技易点');

      // 延迟跳转
      setTimeout(() => {
        navigate('/skills');
      }, 3000);
    } catch (error) {
      console.error('完成新手引导失败:', error);
      toast.error('操作失败，请重试');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-secondary/5 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl shadow-lg">
        <CardHeader className="text-center space-y-4">
          <div className="flex items-center justify-center gap-2">
            <Sparkles className="h-6 w-6 text-primary" />
            <CardTitle className="text-2xl">欢迎来到技遇！</CardTitle>
            <Sparkles className="h-6 w-6 text-primary" />
          </div>
          <CardDescription className="text-base">
            完成以下几步，即可获得启动积分，开启你的技能交换之旅~
          </CardDescription>
          <div className="space-y-2">
            <div className="flex justify-between text-sm text-muted-foreground">
              <span>第 {step} 步，共 3 步</span>
              <span>{Math.round(progress)}%</span>
            </div>
            <Progress value={progress} className="h-2" />
          </div>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* 第一步：想学的技能 */}
          {step === 1 && (
            <div className="space-y-4 animate-in fade-in slide-in-from-right-5 duration-300">
              <div className="text-center space-y-2">
                <h3 className="text-lg font-semibold">我想学的技能</h3>
                <p className="text-sm text-muted-foreground">选择你感兴趣的技能（至少选1项）</p>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {SKILL_OPTIONS.map((skill) => (
                  <Button
                    key={skill}
                    variant={wantToLearn.includes(skill) ? 'default' : 'outline'}
                    className="h-auto py-4 relative"
                    onClick={() => toggleSkill(skill, 'learn')}
                  >
                    {wantToLearn.includes(skill) && (
                      <Check className="h-4 w-4 absolute top-2 right-2" />
                    )}
                    <span>{skill}</span>
                  </Button>
                ))}
              </div>
            </div>
          )}

          {/* 第二步：能教的技能 */}
          {step === 2 && (
            <div className="space-y-4 animate-in fade-in slide-in-from-right-5 duration-300">
              <div className="text-center space-y-2">
                <h3 className="text-lg font-semibold">我能教别人的技能</h3>
                <p className="text-sm text-muted-foreground">选择你擅长的技能（可选）</p>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {[...SKILL_OPTIONS, '暂时没有想教的'].map((skill) => (
                  <Button
                    key={skill}
                    variant={canTeach.includes(skill) ? 'default' : 'outline'}
                    className="h-auto py-4 relative"
                    onClick={() => toggleSkill(skill, 'teach')}
                  >
                    {canTeach.includes(skill) && (
                      <Check className="h-4 w-4 absolute top-2 right-2" />
                    )}
                    <span className="text-sm">{skill}</span>
                  </Button>
                ))}
              </div>
            </div>
          )}

          {/* 第三步：空闲时间 */}
          {step === 3 && (
            <div className="space-y-4 animate-in fade-in slide-in-from-right-5 duration-300">
              <div className="text-center space-y-2">
                <h3 className="text-lg font-semibold">我的空闲时间偏好</h3>
                <p className="text-sm text-muted-foreground">选择你通常有空的时间段</p>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {TIME_OPTIONS.map((option) => (
                  <Button
                    key={option.value}
                    variant={availableTime === option.value ? 'default' : 'outline'}
                    className="h-auto py-6 text-base relative"
                    onClick={() => setAvailableTime(option.value)}
                  >
                    {availableTime === option.value && (
                      <Check className="h-5 w-5 absolute top-3 right-3" />
                    )}
                    <span>{option.label}</span>
                  </Button>
                ))}
              </div>
            </div>
          )}

          {/* 完成页面 */}
          {step === 4 && (
            <div className="space-y-6 text-center animate-in fade-in zoom-in duration-500">
              <div className="flex justify-center">
                <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center">
                  <Sparkles className="h-10 w-10 text-primary" />
                </div>
              </div>
              <div className="space-y-2">
                <h3 className="text-2xl font-bold text-primary">恭喜！</h3>
                <p className="text-lg">你已获得 50 技易点</p>
                <p className="text-muted-foreground">快去技能广场看看吧！</p>
              </div>
              <div className="flex flex-wrap justify-center gap-2">
                <Badge variant="secondary" className="text-sm py-1 px-3">
                  想学: {wantToLearn.join('、')}
                </Badge>
                {canTeach.length > 0 && (
                  <Badge variant="secondary" className="text-sm py-1 px-3">
                    能教: {canTeach.join('、')}
                  </Badge>
                )}
                <Badge variant="secondary" className="text-sm py-1 px-3">
                  {TIME_OPTIONS.find((t) => t.value === availableTime)?.label}
                </Badge>
              </div>
            </div>
          )}

          {/* 按钮组 */}
          <div className="flex justify-between pt-4">
            {step > 1 && step < 4 && (
              <Button variant="outline" onClick={handleBack} className="gap-2">
                <ArrowLeft className="h-4 w-4" />
                上一步
              </Button>
            )}
            {step < 3 && (
              <Button onClick={handleNext} className="ml-auto gap-2">
                下一步
                <ArrowRight className="h-4 w-4" />
              </Button>
            )}
            {step === 3 && (
              <Button onClick={handleComplete} disabled={loading} className="ml-auto gap-2">
                {loading ? '处理中...' : '完成'}
                <Check className="h-4 w-4" />
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
