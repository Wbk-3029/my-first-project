-- 增加帖子点赞数
CREATE OR REPLACE FUNCTION increment_post_like_count(post_id uuid)
RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE posts SET like_count = like_count + 1 WHERE id = post_id;
END;
$$;

-- 减少帖子点赞数
CREATE OR REPLACE FUNCTION decrement_post_like_count(post_id uuid)
RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE posts SET like_count = GREATEST(0, like_count - 1) WHERE id = post_id;
END;
$$;

-- 增加帖子回复数
CREATE OR REPLACE FUNCTION increment_post_reply_count(post_id uuid)
RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE posts SET reply_count = reply_count + 1 WHERE id = post_id;
END;
$$;

-- 增加技能交换次数
CREATE OR REPLACE FUNCTION increment_skill_exchange_count(skill_id uuid)
RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE skills SET exchange_count = exchange_count + 1 WHERE id = skill_id;
END;
$$;