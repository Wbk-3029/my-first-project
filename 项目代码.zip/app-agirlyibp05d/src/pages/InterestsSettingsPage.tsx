import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { MainLayout } from '@/components/layouts/MainLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { updateUserInterests } from '@/db/api';
import { SKILL_TYPE_LABELS } from '@/types';
import type { SkillType } from '@/types';
import { ArrowLeft, Plus, X, Sparkles, BookOpen, GraduationCap } from 'lucide-react';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';

export default function InterestsSettingsPage() {
  const navigate = useNavigate();
  const { profile } = useAuth();
  const [submitting, setSubmitting] = useState(false);

  // 兴趣标签
  const [interestTags, setInterestTags] = useState<string[]>([]);
  
  // 我想学的技能
  const [wantToLearn, setWantToLearn] = useState<string[]>([]);
  const [wantToLearnInput, setWantToLearnInput] = useState('');
  
  // 我能教的技能
  const [canTeach, setCanTeach] = useState<string[]>([]);
  const [canTeachInput, setCanTeachInput] = useState('');

  useEffect(() => {
    if (profile) {
      setInterestTags((profile as any).interest_tags || []);
      setWantToLearn((profile as any).want_to_learn || []);
      setCanTeach((profile as any).can_teach || []);
    }
  }, [profile]);

  const skillTypes: SkillType[] = [
    'entertainment',
    'normal',
    'hot',
    'rare',
    'master',
  ];

  const toggleInterestTag = (tag: string) => {
    if (interestTags.includes(tag)) {
      setInterestTags(interestTags.filter((t) => t !== tag));
    } else {
      setInterestTags([...interestTags, tag]);
    }
  };

  const addWantToLearn = () => {
    const skill = wantToLearnInput.trim();
    if (!skill) {
      toast.error('请输入技能名称');
      return;
    }
    if (wantToLearn.includes(skill)) {
      toast.error('该技能已添加');
      return;
    }
    setWantToLearn([...wantToLearn, skill]);
    setWantToLearnInput('');
  };

  const removeWantToLearn = (skill: string) => {
    setWantToLearn(wantToLearn.filter((s) => s !== skill));
  };

  const addCanTeach = () => {
    const skill = canTeachInput.trim();
    if (!skill) {
      toast.error('请输入技能名称');
      return;
    }
    if (canTeach.includes(skill)) {
      toast.error('该技能已添加');
      return;
    }
    setCanTeach([...canTeach, skill]);
    setCanTeachInput('');
  };

  const removeCanTeach = (skill: string) => {
    setCanTeach(canTeach.filter((s) => s !== skill));
  };

  const handleSubmit = async () => {
    try {
      setSubmitting(true);

      const result = await updateUserInterests({
        interestTags,
        wantToLearn,
        canTeach,
      });

      toast.success(result.message);
      navigate(-1);
    } catch (error: any) {
      toast.error(error.message || '保存失败');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <MainLayout>
      <div className="container max-w-4xl mx-auto p-4 space-y-6">
        {/* 标题栏 */}
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate(-1)}
            className="shrink-0"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold">兴趣设置</h1>
            <p className="text-sm text-muted-foreground mt-1">
              设置你的兴趣标签，获得更精准的技能推荐
            </p>
          </div>
        </div>

        {/* 兴趣标签 */}
        <Card className="rounded-xl">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-primary" />
              <CardTitle>兴趣标签</CardTitle>
            </div>
            <CardDescription>
              选择你感兴趣的技能类型，系统将优先推荐这些类型的技能
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-3">
              {skillTypes.map((type) => (
                <Badge
                  key={type}
                  variant={interestTags.includes(type) ? 'default' : 'outline'}
                  className="cursor-pointer px-4 py-2 text-sm hover:bg-primary/10 transition-colors"
                  onClick={() => toggleInterestTag(type)}
                >
                  {SKILL_TYPE_LABELS[type]}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* 我想学的技能 */}
        <Card className="rounded-xl">
          <CardHeader>
            <div className="flex items-center gap-2">
              <BookOpen className="h-5 w-5 text-primary" />
              <CardTitle>我想学的技能</CardTitle>
            </div>
            <CardDescription>
              添加你想学习的技能，系统将优先推荐这些技能
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* 输入框 */}
            <div className="flex gap-2">
              <div className="flex-1">
                <Input
                  placeholder="输入技能名称，如：吉他、摄影、编程..."
                  value={wantToLearnInput}
                  onChange={(e) => setWantToLearnInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      addWantToLearn();
                    }
                  }}
                />
              </div>
              <Button onClick={addWantToLearn} className="gap-2">
                <Plus className="h-4 w-4" />
                添加
              </Button>
            </div>

            {/* 已添加的技能 */}
            {wantToLearn.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {wantToLearn.map((skill) => (
                  <Badge
                    key={skill}
                    variant="secondary"
                    className="px-3 py-1.5 text-sm gap-2"
                  >
                    {skill}
                    <X
                      className="h-3 w-3 cursor-pointer hover:text-destructive"
                      onClick={() => removeWantToLearn(skill)}
                    />
                  </Badge>
                ))}
              </div>
            )}

            {wantToLearn.length === 0 && (
              <div className="text-center py-8 text-sm text-muted-foreground">
                暂无技能，请添加你想学习的技能
              </div>
            )}
          </CardContent>
        </Card>

        {/* 我能教的技能 */}
        <Card className="rounded-xl">
          <CardHeader>
            <div className="flex items-center gap-2">
              <GraduationCap className="h-5 w-5 text-primary" />
              <CardTitle>我能教的技能</CardTitle>
            </div>
            <CardDescription>
              添加你能教授的技能，帮助系统更好地匹配交换对象
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* 输入框 */}
            <div className="flex gap-2">
              <div className="flex-1">
                <Input
                  placeholder="输入技能名称，如：吉他、摄影、编程..."
                  value={canTeachInput}
                  onChange={(e) => setCanTeachInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      addCanTeach();
                    }
                  }}
                />
              </div>
              <Button onClick={addCanTeach} className="gap-2">
                <Plus className="h-4 w-4" />
                添加
              </Button>
            </div>

            {/* 已添加的技能 */}
            {canTeach.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {canTeach.map((skill) => (
                  <Badge
                    key={skill}
                    variant="secondary"
                    className="px-3 py-1.5 text-sm gap-2"
                  >
                    {skill}
                    <X
                      className="h-3 w-3 cursor-pointer hover:text-destructive"
                      onClick={() => removeCanTeach(skill)}
                    />
                  </Badge>
                ))}
              </div>
            )}

            {canTeach.length === 0 && (
              <div className="text-center py-8 text-sm text-muted-foreground">
                暂无技能，请添加你能教授的技能
              </div>
            )}
          </CardContent>
        </Card>

        {/* 提示信息 */}
        <Card className="rounded-xl bg-muted/50">
          <CardContent className="p-4">
            <div className="text-sm text-muted-foreground space-y-2">
              <div className="font-medium">💡 推荐算法说明：</div>
              <div>• 基于"我想学的技能"匹配：40分</div>
              <div>• 基于兴趣标签匹配：30分</div>
              <div>• 基于历史交换记录匹配：20分</div>
              <div>• 基于提供者信用分：10分</div>
              <div className="pt-2 text-xs">
                匹配度越高，推荐优先级越高。设置完整的兴趣信息可以获得更精准的推荐。
              </div>
            </div>
          </CardContent>
        </Card>

        {/* 操作按钮 */}
        <div className="flex gap-3 sticky bottom-4">
          <Button
            variant="outline"
            onClick={() => navigate(-1)}
            className="flex-1 min-h-[44px]"
          >
            取消
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={submitting}
            className="flex-1 min-h-[44px]"
          >
            {submitting ? '保存中...' : '保存设置'}
          </Button>
        </div>
      </div>
    </MainLayout>
  );
}
