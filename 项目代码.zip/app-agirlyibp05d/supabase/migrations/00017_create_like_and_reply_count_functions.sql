-- 增加帖子点赞数
CREATE OR REPLACE FUNCTION increment_post_likes(post_id UUID)
RETURNS VOID AS $$
BEGIN
  UPDATE posts
  SET like_count = like_count + 1
  WHERE id = post_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 减少帖子点赞数
CREATE OR REPLACE FUNCTION decrement_post_likes(post_id UUID)
RETURNS VOID AS $$
BEGIN
  UPDATE posts
  SET like_count = GREATEST(like_count - 1, 0)
  WHERE id = post_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 增加评论点赞数
CREATE OR REPLACE FUNCTION increment_reply_likes(reply_id UUID)
RETURNS VOID AS $$
BEGIN
  UPDATE post_replies
  SET like_count = like_count + 1
  WHERE id = reply_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 减少评论点赞数
CREATE OR REPLACE FUNCTION decrement_reply_likes(reply_id UUID)
RETURNS VOID AS $$
BEGIN
  UPDATE post_replies
  SET like_count = GREATEST(like_count - 1, 0)
  WHERE id = reply_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;