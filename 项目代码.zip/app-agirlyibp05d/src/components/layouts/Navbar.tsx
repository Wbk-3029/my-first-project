import { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useLoginDialog } from '@/contexts/LoginDialogContext';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Menu, Home, MessageSquare, Store, Repeat, User, Coins, Award, Bot, Bell, Users } from 'lucide-react';

const navItems = [
  { name: '首页', path: '/', icon: Home },
  { name: '社区论坛', path: '/forum', icon: MessageSquare },
  { name: '技能广场', path: '/skills', icon: Store },
  { name: '交换中心', path: '/exchanges', icon: Repeat },
  { name: '我的好友', path: '/friends', icon: Users },
  { name: '习遇', path: '/ai-chat', icon: Bot },
  { name: '个人中心', path: '/profile', icon: User },
];

export function Navbar() {
  const { user, profile, signOut } = useAuth();
  const { openLoginDialog } = useLoginDialog();
  const location = useLocation();
  const navigate = useNavigate();
  const [unreadCount, setUnreadCount] = useState(0);

  // 加载未读通知数
  useEffect(() => {
    if (user) {
      loadUnreadCount();
      // 每30秒刷新一次
      const interval = setInterval(loadUnreadCount, 30000);
      return () => clearInterval(interval);
    }
  }, [user]);

  const loadUnreadCount = async () => {
    try {
      const { getUnreadNotificationCount } = await import('@/db/api');
      const count = await getUnreadNotificationCount();
      setUnreadCount(count);
    } catch (error) {
      console.error('加载未读通知数失败:', error);
    }
  };

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center space-x-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-primary to-secondary">
            <span className="text-lg font-bold text-white">技</span>
          </div>
          <span className="text-xl font-bold gradient-text">技遇</span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-6">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center space-x-1 text-sm font-medium transition-colors hover:text-primary ${
                  isActive ? 'text-primary' : 'text-muted-foreground'
                }`}
              >
                <Icon className="h-4 w-4" />
                <span>{item.name}</span>
              </Link>
            );
          })}
        </nav>

        {/* User Menu */}
        <div className="flex items-center space-x-4">
          {user && profile && (
            <>
              <div className="hidden md:flex items-center space-x-4 text-sm">
                <div className="flex items-center space-x-1 text-muted-foreground">
                  <Coins className="h-4 w-4 text-secondary" />
                  <span>{profile.points}</span>
                </div>
                <div className="flex items-center space-x-1 text-muted-foreground">
                  <Award className="h-4 w-4 text-primary" />
                  <span>{profile.credit_score}</span>
                </div>
              </div>

              {/* 通知图标 */}
              <Button
                variant="ghost"
                size="icon"
                className="relative"
                onClick={() => navigate('/notifications')}
              >
                <Bell className="h-5 w-5" />
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 h-5 min-w-5 flex items-center justify-center rounded-full bg-destructive text-[10px] font-medium text-destructive-foreground px-1">
                    {unreadCount > 99 ? '99+' : unreadCount}
                  </span>
                )}
              </Button>
            </>
          )}

          {user && profile ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-9 w-9 rounded-full">
                  <Avatar className="h-9 w-9">
                    <AvatarImage src={profile.avatar_url || undefined} alt={profile.nickname || '用户'} />
                    <AvatarFallback>{profile.nickname?.[0] || '用'}</AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel>
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-medium">{profile.nickname || '未设置昵称'}</p>
                    <p className="text-xs text-muted-foreground">{profile.phone}</p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link to="/profile" className="cursor-pointer">
                    个人中心
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link to="/profile/skills" className="cursor-pointer">
                    我的技能
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link to="/profile/exchanges" className="cursor-pointer">
                    交换记录
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link to="/profile/favorites" className="cursor-pointer">
                    我的收藏
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleSignOut} className="cursor-pointer text-destructive">
                  退出登录
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Button onClick={openLoginDialog} variant="default" size="sm">
              登录
            </Button>
          )}

          {/* Mobile Menu */}
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-64">
              <div className="flex flex-col space-y-4 mt-8">
                {user && profile && (
                  <div className="flex flex-col space-y-2 pb-4 border-b border-border">
                    <div className="flex items-center space-x-2">
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={profile.avatar_url || undefined} alt={profile.nickname || '用户'} />
                        <AvatarFallback>{profile.nickname?.[0] || '用'}</AvatarFallback>
                      </Avatar>
                      <div className="flex flex-col">
                        <span className="text-sm font-medium">{profile.nickname || '未设置昵称'}</span>
                        <span className="text-xs text-muted-foreground">{profile.phone}</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-around text-sm">
                      <div className="flex items-center space-x-1">
                        <Coins className="h-4 w-4 text-secondary" />
                        <span>{profile.points}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Award className="h-4 w-4 text-primary" />
                        <span>{profile.credit_score}</span>
                      </div>
                    </div>
                  </div>
                )}

                {navItems.map((item) => {
                  const Icon = item.icon;
                  const isActive = location.pathname === item.path;
                  return (
                    <Link
                      key={item.path}
                      to={item.path}
                      className={`flex items-center space-x-2 text-sm font-medium transition-colors hover:text-primary ${
                        isActive ? 'text-primary' : 'text-muted-foreground'
                      }`}
                    >
                      <Icon className="h-4 w-4" />
                      <span>{item.name}</span>
                    </Link>
                  );
                })}

                {user ? (
                  <>
                    <div className="border-t border-border pt-4" />
                    <Button onClick={handleSignOut} variant="destructive" size="sm" className="w-full">
                      退出登录
                    </Button>
                  </>
                ) : (
                  <>
                    <div className="border-t border-border pt-4" />
                    <Button onClick={openLoginDialog} variant="default" size="sm" className="w-full">
                      登录
                    </Button>
                  </>
                )}
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}
