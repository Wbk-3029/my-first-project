# 智能评价流程功能说明

## 功能概述
智能评价流程为交换完成后的评价环节提供多维度评分、自动信用分调整、积分结算和评价提醒等完整功能，确保评价的公平性和准确性。

---

## 1. 数据库设计

### 1.1 ratings表新增字段
在原有ratings表基础上新增以下字段：

| 字段名 | 类型 | 说明 |
|--------|------|------|
| skill_rating | int | 技能水平评分（1-5星） |
| attitude_rating | int | 教学态度评分（1-5星） |
| punctuality_rating | int | 准时性评分（1-5星） |
| average_rating | numeric | 平均评分（自动计算） |

**约束**:
- skill_rating: CHECK (skill_rating >= 1 AND skill_rating <= 5)
- attitude_rating: CHECK (attitude_rating >= 1 AND attitude_rating <= 5)
- punctuality_rating: CHECK (punctuality_rating >= 1 AND punctuality_rating <= 5)
- average_rating: GENERATED ALWAYS AS ((skill_rating + attitude_rating + punctuality_rating) / 3.0) STORED

### 1.2 credit_score_changes表
信用分变化记录表

| 字段名 | 类型 | 说明 |
|--------|------|------|
| id | uuid | 主键 |
| user_id | uuid | 用户ID |
| change_amount | numeric | 变化金额（正数为增加，负数为减少） |
| reason | text | 变化原因 |
| related_id | uuid | 关联ID（如评价ID、交换ID） |
| old_score | int | 变化前信用分 |
| new_score | int | 变化后信用分 |
| created_at | timestamptz | 创建时间 |

**索引**:
- idx_credit_score_changes_user: user_id索引
- idx_credit_score_changes_created: created_at DESC索引

**RLS策略**:
- 用户可以查看自己的信用分变化记录

---

## 2. RPC函数

### 2.1 submit_rating
提交评价

**参数**:
- `p_exchange_id`: 交换ID
- `p_rated_id`: 被评价人ID
- `p_skill_rating`: 技能水平评分（1-5）
- `p_attitude_rating`: 教学态度评分（1-5）
- `p_punctuality_rating`: 准时性评分（1-5）
- `p_comment`: 文字评价（可选）

**返回**:
```json
{
  "success": true,
  "rating_id": "uuid",
  "credit_change": 0.5,
  "new_credit": 60,
  "message": "评价提交成功"
}
```

**业务逻辑**:
1. 检查评分范围（1-5）
2. 检查交换是否存在且状态为completed
3. 检查是否已评价
4. 计算平均评分
5. 计算信用分变化：
   - 好评（≥4.0星）：+0.5
   - 中评（3.0-4.0星）：0
   - 差评（<3.0星）：-1
6. 更新被评价人信用分（限制在0-100之间）
7. 记录信用分变化
8. 创建评价记录
9. 检查对方是否已评价
10. 如果双方都已评价，处理积分结算（如有）

### 2.2 check_pending_ratings
检查待评价数量

**返回**:
```json
{
  "pending_count": 5
}
```

**业务逻辑**:
- 统计需要评价的交换数量
- 条件：交换状态为completed且用户未评价

### 2.3 get_pending_rating_exchanges
获取待评价的交换列表

**返回**:
```json
[
  {
    "exchange_id": "uuid",
    "other_user_id": "uuid",
    "other_user_nickname": "张三",
    "other_user_avatar": "url",
    "skill_name": "吉他教学",
    "completed_at": "2026-03-23T10:00:00Z",
    "hours_since_completion": 12.5
  }
]
```

**业务逻辑**:
- 查询用户参与的已完成交换
- 排除已评价的交换
- 计算完成后经过的小时数
- 按完成时间倒序排列

---

## 3. API函数

### 3.1 submitRating
提交评价

```typescript
submitRating(params: {
  exchangeId: string;
  ratedId: string;
  skillRating: number;
  attitudeRating: number;
  punctualityRating: number;
  comment?: string;
}): Promise<{
  success: boolean;
  ratingId: string;
  creditChange: number;
  newCredit: number;
  message: string;
}>
```

### 3.2 checkPendingRatings
检查待评价数量

```typescript
checkPendingRatings(): Promise<number>
```

### 3.3 getPendingRatingExchanges
获取待评价的交换列表

```typescript
getPendingRatingExchanges(): Promise<PendingRatingExchange[]>
```

### 3.4 getCreditScoreChanges
获取信用分变化记录

```typescript
getCreditScoreChanges(userId?: string): Promise<CreditScoreChange[]>
```

---

## 4. 前端页面

### 4.1 RatePage
评价页面

**路由**: `/rate/:id`

**功能**:
- 显示对方信息（头像、昵称、技能）
- 三个维度评分（技能水平、教学态度、准时性）
- 显示综合评分和信用分变化预览
- 文字评价输入（选填，最多500字）
- 提交评价

**评分组件**:
- 1-5星评分
- 点击星星设置评分
- 实时显示当前评分
- 黄色填充表示已选中

**综合评分**:
- 自动计算三个维度的平均分
- 显示评分对信用分的影响
- 好评（≥4.0星）：+0.5
- 中评（3.0-4.0星）：0
- 差评（<3.0星）：-1

**提交流程**:
1. 用户填写评分和评价
2. 点击"提交评价"按钮
3. 调用submitRating API
4. 显示成功提示（包含信用分变化）
5. 返回我的交换页面

### 4.2 PendingRatingsPage
待评价交换列表页面

**路由**: `/pending-ratings`

**功能**:
- 显示所有待评价的交换
- 显示完成时间和经过时长
- 紧急程度标识
- 立即评价按钮

**紧急程度标识**:
- 超过24小时: 红色徽章，"超过24小时"
- 12-24小时: 橙色徽章，"即将超时"
- 小于12小时: 无徽章

**交换卡片**:
- 对方头像和昵称
- 技能名称
- 完成时间
- 经过时长
- 立即评价按钮

**空状态**:
- 居中显示"暂无待评价的交换"

**提示卡片**:
- 温馨提示
- 评价规则说明

---

## 5. 业务流程

### 5.1 提交评价流程
1. 交换完成后，用户进入评价页面
2. 用户对三个维度进行评分（1-5星）
3. 系统自动计算综合评分
4. 系统显示信用分变化预览
5. 用户填写文字评价（可选）
6. 用户点击"提交评价"按钮
7. 系统验证评分范围
8. 系统检查交换状态和评价权限
9. 系统计算信用分变化
10. 系统更新被评价人信用分
11. 系统记录信用分变化
12. 系统创建评价记录
13. 系统检查对方是否已评价
14. 如果双方都已评价，处理积分结算
15. 显示成功提示
16. 返回我的交换页面

### 5.2 查看待评价交换流程
1. 用户进入待评价交换列表页面
2. 系统加载待评价的交换列表
3. 系统计算每个交换的完成时长
4. 系统显示紧急程度标识
5. 用户点击"立即评价"按钮
6. 跳转到评价页面

### 5.3 自动评价流程（待实现）
1. 系统定时任务每小时运行一次
2. 查询完成超过24小时且未评价的交换
3. 检查对方是否已评价
4. 如果对方已评价，使用对方评分
5. 如果对方未评价，默认5星好评
6. 自动创建评价记录
7. 更新信用分
8. 记录信用分变化
9. 发送通知给用户

---

## 6. 评价规则

### 6.1 评分维度
1. **技能水平**（1-5星）
   - 评估对方的技能掌握程度
   - 教学质量和专业性

2. **教学态度**（1-5星）
   - 评估对方的服务态度
   - 耐心程度和沟通能力

3. **准时性**（1-5星）
   - 评估对方的守时情况
   - 是否按约定时间进行交换

### 6.2 综合评分计算
```
综合评分 = (技能水平 + 教学态度 + 准时性) / 3
```

### 6.3 信用分变化规则
| 综合评分 | 信用分变化 | 评价类型 |
|----------|------------|----------|
| ≥4.0星 | +0.5 | 好评 |
| 3.0-4.0星 | 0 | 中评 |
| <3.0星 | -1 | 差评 |

**信用分限制**:
- 最低: 0分
- 最高: 100分

### 6.4 评价时限
- 建议时限: 交换完成后24小时内
- 超时处理: 自动默认好评（待实现）

---

## 7. 积分结算

### 7.1 积分交换结算
- 时机: 双方都完成评价后
- 计算公式: 最终积分 = 基础积分 × 信用系数
- 信用系数: 信用分 / 100

**示例**:
- 基础积分: 50点
- 教学方信用分: 80分
- 信用系数: 0.8
- 最终积分: 50 × 0.8 = 40点

**注意**: 当前积分已在交换同意时结算，此处仅作为扩展功能预留。

---

## 8. 用户界面

### 8.1 评价页面
- 返回按钮: 返回我的交换页面
- 对方信息卡片: 头像、昵称、技能
- 评分区域:
  - 技能水平评分（星星）
  - 教学态度评分（星星）
  - 准时性评分（星星）
- 综合评分卡片: 显示平均分和信用分变化
- 文字评价输入框: Textarea，最多500字
- 操作按钮: 取消、提交评价
- 提示卡片: 评价规则说明

### 8.2 待评价交换列表页面
- 标题: "待评价交换"
- 数量徽章: 显示待评价数量
- 交换卡片列表:
  - 对方头像和昵称
  - 技能名称
  - 完成时间
  - 经过时长
  - 紧急程度徽章
  - 立即评价按钮
- 提示卡片: 温馨提示

---

## 9. 错误处理

### 9.1 前端验证
- 检查评分范围（1-5）
- 检查交换是否存在
- 检查交换状态

### 9.2 后端验证
- 检查评分范围（1-5）
- 检查交换是否存在且状态为completed
- 检查用户是否为交换参与方
- 检查是否已评价

### 9.3 错误提示
- "评分必须在1-5之间"
- "交换不存在或无权评价"
- "你已经评价过此次交换"
- "交换尚未完成，无法评价"
- "加载失败"
- "提交失败"

---

## 10. 性能优化

### 10.1 数据库优化
- 使用索引加速查询
- 使用GENERATED列自动计算平均评分
- 使用RLS策略限制数据访问
- 使用RPC函数封装业务逻辑

### 10.2 前端优化
- 使用骨架屏提升加载体验
- 实时计算综合评分
- 操作后返回上一页

---

## 11. 安全性

### 11.1 RLS策略
- 用户只能查看自己的信用分变化记录
- 评价记录通过RPC函数创建，确保权限

### 11.2 业务逻辑
- 检查用户权限
- 检查交换状态
- 检查是否重复评价
- 使用SECURITY DEFINER确保权限

---

## 12. 扩展功能

### 12.1 自动评价（待实现）
**功能**:
- 交换完成后24小时内未评价，自动默认好评
- 如果对方已评价，使用对方评分

**实现方案**:
1. 创建Edge Function定时任务
2. 每小时查询完成超过24小时且未评价的交换
3. 检查对方是否已评价
4. 自动创建评价记录
5. 更新信用分
6. 记录信用分变化
7. 发送通知给用户

### 12.2 评价提醒（待实现）
**功能**:
- 交换完成后立即推送评价提醒
- 12小时后再次提醒
- 24小时前最后提醒

**实现方案**:
1. 交换完成时创建通知
2. 使用Edge Function定时任务
3. 检查待评价交换
4. 发送应用内通知

### 12.3 评价统计
**功能**:
- 用户评价统计
- 平均评分
- 好评率
- 评价分布

### 12.4 评价展示
**功能**:
- 在技能详情页展示评价
- 在个人主页展示评价
- 评价筛选和排序

---

## 13. 测试建议

### 13.1 功能测试
1. 测试提交评价
2. 测试查看待评价交换
3. 测试信用分变化
4. 测试重复评价
5. 测试评分范围验证

### 13.2 边界测试
1. 测试评分为1星
2. 测试评分为5星
3. 测试评分为3星
4. 测试信用分达到上限（100）
5. 测试信用分达到下限（0）

### 13.3 性能测试
1. 测试大量待评价交换加载
2. 测试并发提交评价

---

## 14. 常见问题

### Q1: 为什么需要多维度评分？
A: 多维度评分可以更全面地评估对方的表现，提供更准确的信用分调整依据。

### Q2: 评价后可以修改吗？
A: 评价提交后无法修改，请谨慎评价。

### Q3: 信用分变化规则是什么？
A: 好评（≥4.0星）+0.5，中评（3.0-4.0星）0，差评（<3.0星）-1。

### Q4: 超过24小时未评价会怎样？
A: 未来会实现自动默认好评功能，目前需要手动评价。

### Q5: 如何查看我的信用分变化记录？
A: 在个人中心的信用分明细页面可以查看完整的变化记录。

---

## 15. 更新日志

### v1.0.0 (2026-03-23)
- 初始版本
- 为ratings表添加多维度评分字段（skill_rating, attitude_rating, punctuality_rating, average_rating）
- 创建credit_score_changes表记录信用分变化
- 创建submit_rating RPC函数
- 创建check_pending_ratings RPC函数
- 创建get_pending_rating_exchanges RPC函数
- 创建API函数：submitRating、checkPendingRatings、getPendingRatingExchanges、getCreditScoreChanges
- 重写RatePage页面（多维度评分）
- 创建PendingRatingsPage页面（待评价交换列表）
- 更新路由：/rate/:id、/pending-ratings

---

## 16. 技术实现细节

### 16.1 平均评分计算
使用PostgreSQL的GENERATED列自动计算平均评分：
```sql
average_rating numeric GENERATED ALWAYS AS 
  ((skill_rating + attitude_rating + punctuality_rating) / 3.0) STORED
```

### 16.2 信用分变化记录
每次评价都会记录信用分变化：
```sql
INSERT INTO credit_score_changes (
  user_id, change_amount, reason, related_id, old_score, new_score
) VALUES (
  p_rated_id, v_credit_change, '获得好评', p_exchange_id, v_old_credit, v_new_credit
);
```

### 16.3 评价时限计算
使用PostgreSQL的EXTRACT函数计算经过的小时数：
```sql
EXTRACT(EPOCH FROM (now() - e.completed_at)) / 3600 AS hours_since_completion
```

---

## 17. 界面设计规范

### 17.1 颜色规范
- 星星选中: 黄色（fill-yellow-400 text-yellow-400）
- 星星未选中: 灰色（text-gray-300 dark:text-gray-600）
- 好评: 绿色
- 中评: 橙色
- 差评: 红色

### 17.2 间距规范
- 卡片间距: 16px（space-y-4）
- 卡片内边距: 16px（p-4）
- 元素间距: 24px（space-y-6）

### 17.3 字体规范
- 标题: 18px（text-title-lg）
- 正文: 14px（text-sm）
- 辅助: 12px（text-xs）

### 17.4 交互规范
- 星星hover: scale-110
- 按钮最小高度: 44px
- 输入框最小高度: 44px

---

## 18. 数据流图

```
用户 → RatePage → submitRating → submit_rating RPC
                                 → 更新信用分
                                 → 记录信用分变化
                                 → 创建评价记录
                                 → 检查对方是否已评价
                                 → 处理积分结算（如有）
                                 → 返回结果

用户 → PendingRatingsPage → getPendingRatingExchanges → get_pending_rating_exchanges RPC
                                                        → 返回待评价交换列表
```

---

**最后更新**: 2026-03-23
**版本**: v1.0.0
**维护者**: 技遇开发团队
