-- 修改用户初始信用分为60分
ALTER TABLE profiles 
ALTER COLUMN credit_score SET DEFAULT 60;

-- 更新现有用户的信用分为60分（如果当前为100分，说明是初始值）
UPDATE profiles 
SET credit_score = 60 
WHERE credit_score = 100;

-- 添加注释
COMMENT ON COLUMN profiles.credit_score IS '信用分（初始60分，范围0-100）';
