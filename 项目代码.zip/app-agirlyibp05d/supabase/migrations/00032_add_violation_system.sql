-- 为profiles表添加账号状态字段
DO $$ BEGIN
  CREATE TYPE account_status AS ENUM ('normal', 'warned', 'suspended', 'banned');
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

ALTER TABLE profiles ADD COLUMN IF NOT EXISTS account_status account_status DEFAULT 'normal';
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS suspended_until timestamp with time zone;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS ban_reason text;

COMMENT ON COLUMN profiles.account_status IS '账号状态：normal正常、warned警告、suspended临时封禁、banned永久封禁';
COMMENT ON COLUMN profiles.suspended_until IS '封禁截止时间';
COMMENT ON COLUMN profiles.ban_reason IS '封禁原因';

-- 创建违规类型枚举
DO $$ BEGIN
  CREATE TYPE violation_type AS ENUM ('no_show', 'false_info', 'malicious_review', 'spam', 'harassment', 'other');
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

COMMENT ON TYPE violation_type IS '违规类型：no_show爽约、false_info虚假信息、malicious_review恶意评价、spam垃圾信息、harassment骚扰行为、other其他';

-- 创建违规处理状态枚举
DO $$ BEGIN
  CREATE TYPE violation_status AS ENUM ('pending', 'processing', 'resolved', 'rejected');
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

COMMENT ON TYPE violation_status IS '违规处理状态：pending待处理、processing处理中、resolved已处理、rejected已驳回';

-- 创建违规记录表
CREATE TABLE IF NOT EXISTS violation_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  violator_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  reporter_id uuid REFERENCES profiles(id) ON DELETE SET NULL,
  type violation_type NOT NULL,
  description text NOT NULL,
  evidence jsonb DEFAULT '[]',
  related_id uuid,
  related_type text,
  credit_deducted integer DEFAULT 0,
  status violation_status DEFAULT 'pending',
  handler_id uuid REFERENCES profiles(id) ON DELETE SET NULL,
  handler_note text,
  handled_at timestamp with time zone,
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now()
);

COMMENT ON TABLE violation_records IS '违规记录表';
COMMENT ON COLUMN violation_records.violator_id IS '违规者ID';
COMMENT ON COLUMN violation_records.reporter_id IS '举报者ID';
COMMENT ON COLUMN violation_records.type IS '违规类型';
COMMENT ON COLUMN violation_records.description IS '违规描述';
COMMENT ON COLUMN violation_records.evidence IS '证据（截图、链接等）';
COMMENT ON COLUMN violation_records.related_id IS '关联对象ID（交换、帖子、评价等）';
COMMENT ON COLUMN violation_records.related_type IS '关联对象类型（exchange、post、review等）';
COMMENT ON COLUMN violation_records.credit_deducted IS '扣除的信用分';
COMMENT ON COLUMN violation_records.status IS '处理状态';
COMMENT ON COLUMN violation_records.handler_id IS '处理人ID';
COMMENT ON COLUMN violation_records.handler_note IS '处理备注';
COMMENT ON COLUMN violation_records.handled_at IS '处理时间';

-- 创建索引
CREATE INDEX IF NOT EXISTS idx_violation_records_violator ON violation_records(violator_id);
CREATE INDEX IF NOT EXISTS idx_violation_records_reporter ON violation_records(reporter_id);
CREATE INDEX IF NOT EXISTS idx_violation_records_status ON violation_records(status);
CREATE INDEX IF NOT EXISTS idx_violation_records_type ON violation_records(type);
CREATE INDEX IF NOT EXISTS idx_violation_records_created ON violation_records(created_at DESC);

-- 创建RLS策略
ALTER TABLE violation_records ENABLE ROW LEVEL SECURITY;

-- 用户可以查看自己作为违规者或举报者的记录
CREATE POLICY violation_records_select ON violation_records
  FOR SELECT
  USING (violator_id = auth.uid() OR reporter_id = auth.uid());

-- 用户可以创建举报记录
CREATE POLICY violation_records_insert ON violation_records
  FOR INSERT
  WITH CHECK (reporter_id = auth.uid());

-- 创建RPC函数：举报违规行为
CREATE OR REPLACE FUNCTION report_violation(
  p_violator_id uuid,
  p_type violation_type,
  p_description text,
  p_evidence jsonb DEFAULT '[]',
  p_related_id uuid DEFAULT NULL,
  p_related_type text DEFAULT NULL
) RETURNS jsonb AS $$
DECLARE
  v_record_id uuid;
  v_reporter_id uuid;
BEGIN
  -- 获取当前用户ID
  v_reporter_id := auth.uid();
  
  IF v_reporter_id IS NULL THEN
    RETURN jsonb_build_object(
      'success', false,
      'message', '未登录'
    );
  END IF;
  
  -- 不能举报自己
  IF v_reporter_id = p_violator_id THEN
    RETURN jsonb_build_object(
      'success', false,
      'message', '不能举报自己'
    );
  END IF;
  
  -- 检查被举报者是否存在
  IF NOT EXISTS (SELECT 1 FROM profiles WHERE id = p_violator_id) THEN
    RETURN jsonb_build_object(
      'success', false,
      'message', '被举报用户不存在'
    );
  END IF;
  
  -- 检查是否重复举报（同一举报者对同一违规者的同一关联对象）
  IF p_related_id IS NOT NULL AND EXISTS (
    SELECT 1 FROM violation_records
    WHERE reporter_id = v_reporter_id
      AND violator_id = p_violator_id
      AND related_id = p_related_id
      AND status IN ('pending', 'processing')
  ) THEN
    RETURN jsonb_build_object(
      'success', false,
      'message', '您已举报过该内容，请等待处理'
    );
  END IF;
  
  -- 创建违规记录
  INSERT INTO violation_records (
    violator_id,
    reporter_id,
    type,
    description,
    evidence,
    related_id,
    related_type,
    status
  ) VALUES (
    p_violator_id,
    v_reporter_id,
    p_type,
    p_description,
    p_evidence,
    p_related_id,
    p_related_type,
    'pending'
  ) RETURNING id INTO v_record_id;
  
  RETURN jsonb_build_object(
    'success', true,
    'message', '举报成功，我们会尽快处理',
    'record_id', v_record_id
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

COMMENT ON FUNCTION report_violation IS '举报违规行为';

-- 创建RPC函数：处理违规记录
CREATE OR REPLACE FUNCTION handle_violation(
  p_record_id uuid,
  p_action text, -- 'approve'批准、'reject'驳回
  p_handler_note text DEFAULT NULL
) RETURNS jsonb AS $$
DECLARE
  v_handler_id uuid;
  v_record record;
  v_credit_deduction integer;
  v_violation_count integer;
  v_new_status account_status;
  v_suspend_until timestamp with time zone;
BEGIN
  -- 获取当前用户ID
  v_handler_id := auth.uid();
  
  IF v_handler_id IS NULL THEN
    RETURN jsonb_build_object(
      'success', false,
      'message', '未登录'
    );
  END IF;
  
  -- 获取违规记录
  SELECT * INTO v_record
  FROM violation_records
  WHERE id = p_record_id;
  
  IF v_record IS NULL THEN
    RETURN jsonb_build_object(
      'success', false,
      'message', '违规记录不存在'
    );
  END IF;
  
  IF v_record.status != 'pending' THEN
    RETURN jsonb_build_object(
      'success', false,
      'message', '该记录已处理'
    );
  END IF;
  
  -- 驳回举报
  IF p_action = 'reject' THEN
    UPDATE violation_records
    SET status = 'rejected',
        handler_id = v_handler_id,
        handler_note = p_handler_note,
        handled_at = now(),
        updated_at = now()
    WHERE id = p_record_id;
    
    RETURN jsonb_build_object(
      'success', true,
      'message', '已驳回举报'
    );
  END IF;
  
  -- 批准举报，根据违规类型扣除信用分
  CASE v_record.type
    WHEN 'no_show' THEN v_credit_deduction := 10;
    WHEN 'false_info' THEN v_credit_deduction := 15;
    WHEN 'malicious_review' THEN v_credit_deduction := 8;
    WHEN 'spam' THEN v_credit_deduction := 5;
    WHEN 'harassment' THEN v_credit_deduction := 20;
    ELSE v_credit_deduction := 5;
  END CASE;
  
  -- 扣除信用分
  UPDATE user_credit
  SET score = GREATEST(0, score - v_credit_deduction),
      updated_at = now()
  WHERE user_id = v_record.violator_id;
  
  -- 记录信用分变动
  INSERT INTO credit_logs (
    user_id,
    change_amount,
    change_type,
    reason,
    related_id,
    operator_id
  ) VALUES (
    v_record.violator_id,
    -v_credit_deduction,
    'violation',
    '违规行为：' || 
      CASE v_record.type
        WHEN 'no_show' THEN '爽约'
        WHEN 'false_info' THEN '虚假信息'
        WHEN 'malicious_review' THEN '恶意评价'
        WHEN 'spam' THEN '垃圾信息'
        WHEN 'harassment' THEN '骚扰行为'
        ELSE '其他违规'
      END,
    p_record_id,
    v_handler_id
  );
  
  -- 统计该用户的违规次数
  SELECT COUNT(*) INTO v_violation_count
  FROM violation_records
  WHERE violator_id = v_record.violator_id
    AND status = 'resolved';
  
  -- 根据违规次数和类型决定账号状态
  v_new_status := 'normal';
  v_suspend_until := NULL;
  
  CASE v_record.type
    WHEN 'no_show' THEN
      IF v_violation_count >= 5 THEN
        v_new_status := 'banned';
      ELSIF v_violation_count >= 3 THEN
        v_new_status := 'warned';
      END IF;
    WHEN 'false_info' THEN
      IF v_violation_count >= 3 THEN
        v_new_status := 'banned';
      ELSIF v_violation_count >= 2 THEN
        v_new_status := 'warned';
      END IF;
    WHEN 'malicious_review' THEN
      IF v_violation_count >= 5 THEN
        v_new_status := 'banned';
      ELSIF v_violation_count >= 3 THEN
        v_new_status := 'warned';
      END IF;
    WHEN 'spam' THEN
      IF v_violation_count >= 10 THEN
        v_new_status := 'banned';
      ELSIF v_violation_count >= 5 THEN
        v_new_status := 'suspended';
        v_suspend_until := now() + interval '7 days';
      END IF;
    WHEN 'harassment' THEN
      IF v_violation_count >= 2 THEN
        v_new_status := 'banned';
      ELSIF v_violation_count >= 1 THEN
        v_new_status := 'warned';
      END IF;
  END CASE;
  
  -- 更新账号状态
  UPDATE profiles
  SET account_status = v_new_status,
      suspended_until = v_suspend_until,
      ban_reason = CASE 
        WHEN v_new_status IN ('suspended', 'banned') THEN 
          '违规行为：' || 
          CASE v_record.type
            WHEN 'no_show' THEN '爽约'
            WHEN 'false_info' THEN '虚假信息'
            WHEN 'malicious_review' THEN '恶意评价'
            WHEN 'spam' THEN '垃圾信息'
            WHEN 'harassment' THEN '骚扰行为'
            ELSE '其他违规'
          END || '（累计' || v_violation_count || '次）'
        ELSE NULL
      END
  WHERE id = v_record.violator_id;
  
  -- 更新违规记录
  UPDATE violation_records
  SET status = 'resolved',
      credit_deducted = v_credit_deduction,
      handler_id = v_handler_id,
      handler_note = p_handler_note,
      handled_at = now(),
      updated_at = now()
  WHERE id = p_record_id;
  
  RETURN jsonb_build_object(
    'success', true,
    'message', '处理成功',
    'credit_deducted', v_credit_deduction,
    'new_status', v_new_status,
    'violation_count', v_violation_count
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

COMMENT ON FUNCTION handle_violation IS '处理违规记录';

-- 创建RPC函数：自动检测爽约行为
CREATE OR REPLACE FUNCTION auto_detect_no_show() RETURNS void AS $$
DECLARE
  v_exchange record;
BEGIN
  -- 查找所有应该开始但未完成的交换（开始时间超过24小时）
  FOR v_exchange IN
    SELECT *
    FROM exchanges
    WHERE status = 'in_progress'
      AND start_time IS NOT NULL
      AND start_time < now() - interval '24 hours'
      AND completed_at IS NULL
  LOOP
    -- 为发起方创建爽约记录
    INSERT INTO violation_records (
      violator_id,
      reporter_id,
      type,
      description,
      related_id,
      related_type,
      status
    ) VALUES (
      v_exchange.initiator_id,
      NULL,
      'no_show',
      '交换开始后24小时未确认完成',
      v_exchange.id,
      'exchange',
      'pending'
    ) ON CONFLICT DO NOTHING;
    
    -- 为接收方创建爽约记录
    INSERT INTO violation_records (
      violator_id,
      reporter_id,
      type,
      description,
      related_id,
      related_type,
      status
    ) VALUES (
      v_exchange.receiver_id,
      NULL,
      'no_show',
      '交换开始后24小时未确认完成',
      v_exchange.id,
      'exchange',
      'pending'
    ) ON CONFLICT DO NOTHING;
  END LOOP;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

COMMENT ON FUNCTION auto_detect_no_show IS '自动检测爽约行为';

-- 创建RPC函数：获取违规统计
CREATE OR REPLACE FUNCTION get_violation_stats(p_user_id uuid)
RETURNS jsonb AS $$
DECLARE
  v_result jsonb;
BEGIN
  SELECT jsonb_build_object(
    'total_violations', COUNT(*),
    'pending_violations', COUNT(*) FILTER (WHERE status = 'pending'),
    'resolved_violations', COUNT(*) FILTER (WHERE status = 'resolved'),
    'no_show_count', COUNT(*) FILTER (WHERE type = 'no_show' AND status = 'resolved'),
    'false_info_count', COUNT(*) FILTER (WHERE type = 'false_info' AND status = 'resolved'),
    'malicious_review_count', COUNT(*) FILTER (WHERE type = 'malicious_review' AND status = 'resolved'),
    'spam_count', COUNT(*) FILTER (WHERE type = 'spam' AND status = 'resolved'),
    'harassment_count', COUNT(*) FILTER (WHERE type = 'harassment' AND status = 'resolved'),
    'total_credit_deducted', COALESCE(SUM(credit_deducted) FILTER (WHERE status = 'resolved'), 0)
  ) INTO v_result
  FROM violation_records
  WHERE violator_id = p_user_id;
  
  RETURN v_result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

COMMENT ON FUNCTION get_violation_stats IS '获取用户违规统计';
