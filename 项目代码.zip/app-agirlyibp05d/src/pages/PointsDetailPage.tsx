import { useEffect, useState } from 'react';
import { MainLayout } from '@/components/layouts/MainLayout';
import { PageHeader } from '@/components/layouts/PageHeader';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Separator } from '@/components/ui/separator';
import { useAuth } from '@/contexts/AuthContext';
import { getPointRecords } from '@/db/api';
import { POINT_TYPE_LABELS } from '@/lib/credit-utils';
import { Coins, TrendingUp, TrendingDown, Info, Gift, Zap, ShoppingBag } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { zhCN } from 'date-fns/locale';

interface PointRecord {
  id: string;
  amount: number;
  type: string;
  description: string;
  created_at: string;
}

export default function PointsDetailPage() {
  const { user, profile } = useAuth();
  const [records, setRecords] = useState<PointRecord[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      loadRecords();
    }
  }, [user]);

  const loadRecords = async () => {
    if (!user?.id) return;
    
    try {
      setLoading(true);
      const data = await getPointRecords(user.id);
      setRecords(data.slice(0, 50));
    } catch (error) {
      console.error('加载积分记录失败:', error);
    } finally {
      setLoading(false);
    }
  };

  // 分离收入和支出记录
  const incomeRecords = records.filter((r) => r.amount > 0);
  const expenseRecords = records.filter((r) => r.amount < 0);

  return (
    <MainLayout>
      <PageHeader title="技易点明细" />

      <div className="space-y-6">
        {/* 当前余额 */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Coins className="h-5 w-5 text-secondary" />
              当前余额
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-4xl font-bold text-secondary">
              {profile?.points || 0}
            </div>
            <p className="text-sm text-muted-foreground mt-2">
              技易点可用于兑换技能和参与团购
            </p>
          </CardContent>
        </Card>

        {/* 使用方式说明 */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Info className="h-5 w-5" />
              使用方式
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-start gap-3">
              <div className="p-2 rounded-lg bg-primary/10 shrink-0">
                <ShoppingBag className="h-4 w-4 text-primary" />
              </div>
              <div>
                <div className="font-medium">购买技能</div>
                <div className="text-sm text-muted-foreground">
                  使用技易点直接兑换他人发布的技能
                </div>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="p-2 rounded-lg bg-secondary/10 shrink-0">
                <Gift className="h-4 w-4 text-secondary" />
              </div>
              <div>
                <div className="font-medium">参与团购</div>
                <div className="text-sm text-muted-foreground">
                  以更优惠的价格参与技能团购活动
                </div>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="p-2 rounded-lg bg-primary/10 shrink-0">
                <Zap className="h-4 w-4 text-primary" />
              </div>
              <div>
                <div className="font-medium">解锁增值功能</div>
                <div className="text-sm text-muted-foreground">
                  使用技易点解锁平台增值服务和特权
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* 获取方式 */}
        <Card>
          <CardHeader>
            <CardTitle>如何获得技易点</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 text-sm">
              <div className="flex items-center justify-between p-2 rounded bg-muted/50">
                <span>发布技能</span>
                <Badge variant="secondary">+5点</Badge>
              </div>
              <div className="flex items-center justify-between p-2 rounded bg-muted/50">
                <span>完成交换</span>
                <Badge variant="secondary">+10点</Badge>
              </div>
              <div className="flex items-center justify-between p-2 rounded bg-muted/50">
                <span>获得好评</span>
                <Badge variant="secondary">+3点</Badge>
              </div>
              <div className="flex items-center justify-between p-2 rounded bg-muted/50">
                <span>新手引导</span>
                <Badge variant="secondary">+50点</Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* 收入记录 */}
        {incomeRecords.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-green-600">
                <TrendingUp className="h-5 w-5" />
                收入记录
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {incomeRecords.map((record) => (
                  <div
                    key={record.id}
                    className="flex items-center justify-between p-3 rounded-lg border border-green-200 bg-green-50/50"
                  >
                    <div>
                      <div className="font-medium">{record.description}</div>
                      <div className="text-xs text-muted-foreground mt-1">
                        {POINT_TYPE_LABELS[record.type] || record.type} ·{' '}
                        {formatDistanceToNow(new Date(record.created_at), {
                          addSuffix: true,
                          locale: zhCN,
                        })}
                      </div>
                    </div>
                    <Badge variant="default" className="bg-green-600 text-base font-bold">
                      +{record.amount}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* 支出记录 */}
        {expenseRecords.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-red-600">
                <TrendingDown className="h-5 w-5" />
                支出记录
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {expenseRecords.map((record) => (
                  <div
                    key={record.id}
                    className="flex items-center justify-between p-3 rounded-lg border border-red-200 bg-red-50/50"
                  >
                    <div>
                      <div className="font-medium">{record.description}</div>
                      <div className="text-xs text-muted-foreground mt-1">
                        {POINT_TYPE_LABELS[record.type] || record.type} ·{' '}
                        {formatDistanceToNow(new Date(record.created_at), {
                          addSuffix: true,
                          locale: zhCN,
                        })}
                      </div>
                    </div>
                    <Badge variant="destructive" className="text-base font-bold">
                      {record.amount}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* 无记录提示 */}
        {!loading && records.length === 0 && (
          <Card>
            <CardContent className="py-12 text-center text-muted-foreground">
              暂无积分记录
            </CardContent>
          </Card>
        )}

        {/* 加载状态 */}
        {loading && (
          <Card>
            <CardContent className="py-6">
              <div className="space-y-4">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="flex items-center justify-between">
                    <Skeleton className="h-12 w-3/4 bg-muted" />
                    <Skeleton className="h-8 w-16 bg-muted" />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* 注意事项 */}
        <Card className="border-amber-200 bg-amber-50/50">
          <CardHeader>
            <CardTitle className="text-amber-900 flex items-center gap-2">
              <Info className="h-5 w-5" />
              注意事项
            </CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-amber-900 space-y-2">
            <p>• 技易点仅限平台内使用，不可提现或转让</p>
            <p>• 技易点长期不使用不会过期</p>
            <p>• 技易点余额不足时无法发起交换</p>
            <p>• 违规行为可能导致技易点被扣除</p>
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}
