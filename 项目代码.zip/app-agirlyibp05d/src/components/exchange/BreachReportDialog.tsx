import { useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { createBreachReport } from '@/db/api';
import { AlertTriangle } from 'lucide-react';
import { toast } from 'sonner';

interface BreachReportDialogProps {
  exchangeId: string;
  reportedId: string;
  reportedName: string;
  trigger?: React.ReactNode;
  onSuccess?: () => void;
}

export function BreachReportDialog({
  exchangeId,
  reportedId,
  reportedName,
  trigger,
  onSuccess,
}: BreachReportDialogProps) {
  const [open, setOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [evidence, setEvidence] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!evidence.trim()) {
      toast.error('请填写证据说明');
      return;
    }

    try {
      setSubmitting(true);

      const result = await createBreachReport({
        exchangeId,
        reportedId,
        evidence,
      });

      toast.success(result.message);
      setOpen(false);
      setEvidence('');
      onSuccess?.();
    } catch (error: any) {
      toast.error(error.message || '提交失败');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger || (
          <Button variant="destructive" className="gap-2">
            <AlertTriangle className="h-4 w-4" />
            举报未履约
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-destructive">
            <AlertTriangle className="h-5 w-5" />
            举报未履约
          </DialogTitle>
          <DialogDescription>
            举报对象：{reportedName}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* 证据说明 */}
          <div className="space-y-2">
            <Label htmlFor="evidence">证据说明</Label>
            <Textarea
              id="evidence"
              placeholder="请详细描述情况并提供证据（如聊天记录、截图等）..."
              value={evidence}
              onChange={(e) => setEvidence(e.target.value)}
              rows={6}
              className="resize-none"
            />
            <p className="text-xs text-muted-foreground">
              {evidence.length} / 1000
            </p>
          </div>

          {/* 提示信息 */}
          <div className="p-3 bg-destructive/10 rounded-lg">
            <div className="text-sm text-destructive space-y-1">
              <div className="font-medium">⚠️ 举报须知：</div>
              <div>• 只能在约定时间后15分钟举报未履约</div>
              <div>• 请提供真实有效的证据</div>
              <div>• 平台将在3个工作日内处理</div>
              <div>• 恶意举报将影响你的信用分</div>
            </div>
          </div>

          {/* 提交按钮 */}
          <div className="flex gap-3">
            <Button
              type="button"
              variant="outline"
              onClick={() => setOpen(false)}
              className="flex-1"
            >
              取消
            </Button>
            <Button
              type="submit"
              variant="destructive"
              disabled={submitting}
              className="flex-1"
            >
              {submitting ? '提交中...' : '提交举报'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
