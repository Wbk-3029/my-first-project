import { useEffect, useState, useRef } from 'react';
import { useParams, Link } from 'react-router-dom';
import { MainLayout } from '@/components/layouts/MainLayout';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { UserProfileDialog } from '@/components/user/UserProfileDialog';
import { CommentItem } from '@/components/forum/CommentItem';
import { Textarea } from '@/components/ui/textarea';
import { Skeleton } from '@/components/ui/skeleton';
import {
  getPostById,
  getPostReplies,
  createPostReply,
  togglePostLike,
  checkPostLiked,
  toggleFavorite,
  checkFavorited,
} from '@/db/api';
import type { Post, PostReply } from '@/types';
import { Heart, MessageCircle, Star, ArrowLeft, Send } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { zhCN } from 'date-fns/locale';
import { toast } from 'sonner';

export default function ForumDetailPage() {
  const { id } = useParams<{ id: string }>();
  const [post, setPost] = useState<Post | null>(null);
  const [replies, setReplies] = useState<PostReply[]>([]);
  const [loading, setLoading] = useState(true);
  const [replyContent, setReplyContent] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [liked, setLiked] = useState(false);
  const [favorited, setFavorited] = useState(false);
  const [replyingTo, setReplyingTo] = useState<string | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (id) {
      loadData();
    }
  }, [id]);

  const loadData = async () => {
    if (!id) return;

    try {
      setLoading(true);
      const [postData, repliesData, likedStatus, favoritedStatus] = await Promise.all([
        getPostById(id),
        getPostReplies(id),
        checkPostLiked(id),
        checkFavorited('post', id),
      ]);

      setPost(postData);
      setReplies(repliesData);
      setLiked(likedStatus);
      setFavorited(favoritedStatus);
    } catch (error) {
      toast.error('加载帖子失败');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmitReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!id || !replyContent.trim()) return;

    try {
      setSubmitting(true);
      await createPostReply(id, replyContent, replyingTo || undefined);
      toast.success('回复成功');
      setReplyContent('');
      setReplyingTo(null);
      await loadData();
    } catch (error) {
      toast.error('回复失败');
    } finally {
      setSubmitting(false);
    }
  };

  const handleLike = async () => {
    if (!id) return;
    try {
      await togglePostLike(id);
      setLiked(!liked);
      if (post) {
        setPost({
          ...post,
          like_count: liked ? (post.like_count || 0) - 1 : (post.like_count || 0) + 1,
        });
      }
    } catch (error) {
      toast.error('操作失败');
    }
  };

  const handleFavorite = async () => {
    if (!id) return;
    try {
      await toggleFavorite('post', id);
      setFavorited(!favorited);
      toast.success(favorited ? '已取消收藏' : '收藏成功');
    } catch (error) {
      toast.error('操作失败');
    }
  };

  const handleReplyTo = (replyId: string) => {
    setReplyingTo(replyId);
    textareaRef.current?.focus();
  };

  if (loading) {
    return (
      <MainLayout>
        <div className="space-y-4">
          <Skeleton className="h-8 w-full bg-muted" />
          <Card className="rounded-2xl">
            <div className="p-4 space-y-4">
              <div className="flex items-center gap-3">
                <Skeleton className="h-10 w-10 rounded-full bg-muted" />
                <div className="flex-1">
                  <Skeleton className="h-4 w-24 mb-1 bg-muted" />
                  <Skeleton className="h-3 w-16 bg-muted" />
                </div>
              </div>
              <Skeleton className="h-6 w-3/4 bg-muted" />
              <Skeleton className="h-20 w-full bg-muted" />
            </div>
          </Card>
        </div>
      </MainLayout>
    );
  }

  if (!post) {
    return (
      <MainLayout>
        <Card className="rounded-2xl">
          <div className="p-12 text-center text-muted-foreground">帖子不存在</div>
        </Card>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="space-y-4 pb-24">
        {/* 返回按钮 */}
        <Button variant="ghost" size="sm" asChild className="gap-2">
          <Link to="/forum">
            <ArrowLeft className="h-4 w-4" />
            返回列表
          </Link>
        </Button>

        {/* 帖子内容 */}
        <Card className="rounded-2xl overflow-hidden">
          <div className="p-4 space-y-4">
            {/* 作者信息 */}
            <div className="flex items-center gap-3">
              {post.profiles && (
                <>
                  <UserProfileDialog
                    userId={post.user_id}
                    userName={post.profiles.nickname || '匿名用户'}
                    userAvatar={post.profiles.avatar_url}
                    userCreditScore={post.profiles.credit_score || 100}
                    trigger={
                      <Avatar className="h-11 w-11 cursor-pointer ring-2 ring-background hover:ring-primary/20 transition-all">
                        <AvatarImage src={post.profiles.avatar_url || undefined} />
                        <AvatarFallback>{post.profiles.nickname?.[0] || '用'}</AvatarFallback>
                      </Avatar>
                    }
                  />
                  <div className="flex-1 min-w-0">
                    <div className="font-medium">{post.profiles.nickname || '匿名用户'}</div>
                    <div className="text-xs text-muted-foreground">
                      {formatDistanceToNow(new Date(post.created_at), {
                        addSuffix: true,
                        locale: zhCN,
                      })}
                    </div>
                  </div>
                </>
              )}
            </div>

            {/* 标题 */}
            <h1 className="text-xl font-bold leading-tight">{post.title}</h1>

            {/* 内容 */}
            <div className="text-sm leading-relaxed whitespace-pre-wrap">{post.content}</div>

            {/* 图片 */}
            {post.images && post.images.length > 0 && (
              <div className="grid grid-cols-3 gap-2">
                {post.images.map((url, index) => (
                  <div key={index} className="aspect-square rounded-lg overflow-hidden">
                    <img src={url} alt={`图片 ${index + 1}`} className="w-full h-full object-cover" />
                  </div>
                ))}
              </div>
            )}

            {/* 交换需求 */}
            {post.exchange_need && (
              <div className="p-3 bg-muted/50 rounded-lg">
                <div className="text-xs text-muted-foreground mb-1">交换需求</div>
                <div className="text-sm">{post.exchange_need}</div>
              </div>
            )}

            {/* 操作栏 */}
            <div className="flex items-center justify-between pt-2 border-t border-border">
              <div className="flex items-center gap-4">
                <button
                  onClick={handleLike}
                  className={`flex items-center gap-1.5 transition-colors min-h-10 ${
                    liked ? 'text-red-500' : 'text-muted-foreground hover:text-red-500'
                  }`}
                >
                  <Heart className={`h-5 w-5 ${liked ? 'fill-current' : ''}`} />
                  <span className="text-sm font-medium">{post.like_count || 0}</span>
                </button>

                <div className="flex items-center gap-1.5 text-muted-foreground">
                  <MessageCircle className="h-5 w-5" />
                  <span className="text-sm font-medium">{post.reply_count || 0}</span>
                </div>
              </div>

              <button
                onClick={handleFavorite}
                className={`flex items-center gap-1.5 transition-colors min-h-10 ${
                  favorited ? 'text-yellow-500' : 'text-muted-foreground hover:text-yellow-500'
                }`}
              >
                <Star className={`h-5 w-5 ${favorited ? 'fill-current' : ''}`} />
              </button>
            </div>
          </div>
        </Card>

        {/* 评论区 */}
        <Card className="rounded-2xl">
          <div className="p-4">
            <h2 className="text-lg font-bold mb-4">
              全部评论 {replies.length > 0 && `(${replies.length})`}
            </h2>

            {replies.length > 0 ? (
              <div className="space-y-4">
                {replies.map((reply) => (
                  <CommentItem key={reply.id} reply={reply} onReply={handleReplyTo} />
                ))}
              </div>
            ) : (
              <div className="py-8 text-center text-muted-foreground text-sm">
                暂无评论，快来抢沙发吧~
              </div>
            )}
          </div>
        </Card>
      </div>

      {/* 固定底部评论输入框 */}
      <div className="fixed bottom-16 md:bottom-0 left-0 right-0 bg-background border-t border-border z-40">
        <div className="container max-w-4xl mx-auto p-4">
          <form onSubmit={handleSubmitReply} className="flex items-end gap-2">
            <div className="flex-1">
              {replyingTo && (
                <div className="text-xs text-muted-foreground mb-1 flex items-center gap-2">
                  <span>回复评论</span>
                  <button
                    type="button"
                    onClick={() => setReplyingTo(null)}
                    className="text-primary hover:underline"
                  >
                    取消
                  </button>
                </div>
              )}
              <Textarea
                ref={textareaRef}
                placeholder="写下你的评论..."
                value={replyContent}
                onChange={(e) => setReplyContent(e.target.value)}
                className="min-h-[44px] max-h-32 resize-none rounded-full px-4 py-3"
                rows={1}
              />
            </div>
            <Button
              type="submit"
              disabled={submitting || !replyContent.trim()}
              size="icon"
              className="h-11 w-11 rounded-full shrink-0"
            >
              <Send className="h-4 w-4" />
            </Button>
          </form>
        </div>
      </div>
    </MainLayout>
  );
}
