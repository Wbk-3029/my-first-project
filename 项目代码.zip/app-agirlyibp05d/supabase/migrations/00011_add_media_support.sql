-- 添加头像URL字段到profiles表
alter table profiles add column if not exists avatar_url text;

-- 添加媒体字段到skills表
alter table skills add column if not exists media jsonb default '[]'::jsonb;

-- 创建avatars存储桶
insert into storage.buckets (id, name, public)
values ('avatars', 'avatars', true)
on conflict (id) do nothing;

-- 创建skill-media存储桶
insert into storage.buckets (id, name, public)
values ('skill-media', 'skill-media', true)
on conflict (id) do nothing;

-- avatars bucket策略
create policy "Anyone can view avatars"
  on storage.objects for select
  using (bucket_id = 'avatars');

create policy "Users can upload own avatar"
  on storage.objects for insert
  with check (
    bucket_id = 'avatars' 
    and auth.uid()::text = (storage.foldername(name))[1]
  );

create policy "Users can update own avatar"
  on storage.objects for update
  using (
    bucket_id = 'avatars' 
    and auth.uid()::text = (storage.foldername(name))[1]
  );

create policy "Users can delete own avatar"
  on storage.objects for delete
  using (
    bucket_id = 'avatars' 
    and auth.uid()::text = (storage.foldername(name))[1]
  );

-- skill-media bucket策略
create policy "Anyone can view skill media"
  on storage.objects for select
  using (bucket_id = 'skill-media');

create policy "Authenticated users can upload skill media"
  on storage.objects for insert
  with check (
    bucket_id = 'skill-media' 
    and auth.role() = 'authenticated'
  );

create policy "Users can update own skill media"
  on storage.objects for update
  using (
    bucket_id = 'skill-media' 
    and auth.uid()::text = (storage.foldername(name))[1]
  );

create policy "Users can delete own skill media"
  on storage.objects for delete
  using (
    bucket_id = 'skill-media' 
    and auth.uid()::text = (storage.foldername(name))[1]
  );