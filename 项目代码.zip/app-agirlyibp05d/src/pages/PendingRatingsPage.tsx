import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { MainLayout } from '@/components/layouts/MainLayout';
import { Card } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import {
  getPendingRatingExchanges,
  type PendingRatingExchange,
} from '@/db/api';
import { Star, Clock, AlertCircle } from 'lucide-react';
import { format } from 'date-fns';
import { zhCN } from 'date-fns/locale';
import { toast } from 'sonner';

export default function PendingRatingsPage() {
  const [exchanges, setExchanges] = useState<PendingRatingExchange[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const data = await getPendingRatingExchanges();
      setExchanges(data);
    } catch (error) {
      toast.error('加载失败');
    } finally {
      setLoading(false);
    }
  };

  const getUrgencyBadge = (hours: number) => {
    if (hours >= 24) {
      return (
        <Badge variant="destructive" className="gap-1">
          <AlertCircle className="h-3 w-3" />
          超过24小时
        </Badge>
      );
    } else if (hours >= 12) {
      return (
        <Badge variant="default" className="gap-1 bg-orange-500">
          <Clock className="h-3 w-3" />
          即将超时
        </Badge>
      );
    }
    return null;
  };

  if (loading) {
    return (
      <MainLayout>
        <div className="space-y-4">
          <Skeleton className="h-8 w-48 bg-muted" />
          <Skeleton className="h-40 w-full rounded-xl bg-muted" />
          <Skeleton className="h-40 w-full rounded-xl bg-muted" />
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h1 className="text-title-lg">待评价交换</h1>
          {exchanges.length > 0 && (
            <Badge variant="destructive">{exchanges.length}</Badge>
          )}
        </div>

        {exchanges.length > 0 ? (
          <div className="space-y-3">
            {exchanges.map((exchange) => (
              <Card key={exchange.exchange_id} className="rounded-xl overflow-hidden">
                <div className="p-4">
                  <div className="flex items-center gap-3 mb-3">
                    <Avatar className="h-10 w-10">
                      <AvatarImage src={exchange.other_user_avatar || undefined} />
                      <AvatarFallback>
                        {exchange.other_user_nickname?.[0] || '用'}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="font-medium truncate">
                        {exchange.other_user_nickname || '匿名用户'}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {exchange.skill_name || '未知技能'}
                      </div>
                    </div>
                    {getUrgencyBadge(exchange.hours_since_completion)}
                  </div>

                  <div className="p-3 bg-muted/50 rounded-lg space-y-2 mb-3">
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Clock className="h-3.5 w-3.5" />
                      <span>
                        完成于{' '}
                        {format(new Date(exchange.completed_at), 'yyyy-MM-dd HH:mm', {
                          locale: zhCN,
                        })}
                      </span>
                    </div>
                    <div className="text-xs text-muted-foreground">
                      已过 {Math.floor(exchange.hours_since_completion)} 小时
                      {exchange.hours_since_completion >= 24 && (
                        <span className="text-destructive ml-1">
                          （建议尽快评价）
                        </span>
                      )}
                    </div>
                  </div>

                  <Button asChild className="w-full min-h-[44px] gap-2">
                    <Link to={`/rate/${exchange.exchange_id}`}>
                      <Star className="h-4 w-4" />
                      立即评价
                    </Link>
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="rounded-xl">
            <div className="p-12 text-center text-muted-foreground">
              暂无待评价的交换
            </div>
          </Card>
        )}

        {/* 提示卡片 */}
        {exchanges.length > 0 && (
          <Card className="rounded-xl bg-muted/30">
            <div className="p-4">
              <div className="text-sm text-muted-foreground space-y-1">
                <div>💡 温馨提示：</div>
                <div>• 请在交换完成后24小时内完成评价</div>
                <div>• 超过24小时未评价，系统将自动默认好评</div>
                <div>• 评价将影响对方的信用分</div>
              </div>
            </div>
          </Card>
        )}
      </div>
    </MainLayout>
  );
}
