-- 创建交换模板表
CREATE TABLE IF NOT EXISTS exchange_templates (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  is_system BOOLEAN DEFAULT FALSE,
  category TEXT CHECK (category IN ('skill_learning', 'exam_tutoring', 'interest_exchange', 'custom')),
  usage_count INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 添加索引
CREATE INDEX IF NOT EXISTS idx_exchange_templates_user ON exchange_templates(user_id);
CREATE INDEX IF NOT EXISTS idx_exchange_templates_is_system ON exchange_templates(is_system);
CREATE INDEX IF NOT EXISTS idx_exchange_templates_category ON exchange_templates(category);

-- 添加RLS策略
ALTER TABLE exchange_templates ENABLE ROW LEVEL SECURITY;

-- 用户可以查看系统模板和自己的模板
CREATE POLICY "用户可以查看系统模板和自己的模板"
  ON exchange_templates FOR SELECT
  USING (is_system = true OR user_id = auth.uid());

-- 用户可以创建自己的模板
CREATE POLICY "用户可以创建自己的模板"
  ON exchange_templates FOR INSERT
  WITH CHECK (user_id = auth.uid() AND is_system = false);

-- 用户可以更新自己的模板
CREATE POLICY "用户可以更新自己的模板"
  ON exchange_templates FOR UPDATE
  USING (user_id = auth.uid() AND is_system = false);

-- 用户可以删除自己的模板
CREATE POLICY "用户可以删除自己的模板"
  ON exchange_templates FOR DELETE
  USING (user_id = auth.uid() AND is_system = false);

-- 添加注释
COMMENT ON TABLE exchange_templates IS '交换模板表';
COMMENT ON COLUMN exchange_templates.user_id IS '创建者ID（系统模板为NULL）';
COMMENT ON COLUMN exchange_templates.title IS '模板标题';
COMMENT ON COLUMN exchange_templates.content IS '模板内容';
COMMENT ON COLUMN exchange_templates.is_system IS '是否为系统模板';
COMMENT ON COLUMN exchange_templates.category IS '模板分类';
COMMENT ON COLUMN exchange_templates.usage_count IS '使用次数';

-- 插入系统预设模板
INSERT INTO exchange_templates (user_id, title, content, is_system, category) VALUES
(NULL, 'PS入门交换英语口语', '## 交换内容

### 我提供的技能：Photoshop入门教学
- 基础工具使用（选区、画笔、图层等）
- 图片修饰与调色技巧
- 简单海报设计实战
- 预计教学时长：每周2小时，共4周

### 我希望学习的技能：英语口语练习
- 日常对话练习
- 发音纠正
- 话题讨论（旅游、美食、电影等）
- 预计学习时长：每周2小时，共4周

## 双方义务

### 甲方义务（PS教学方）
1. 按时参加约定的教学时间
2. 准备教学素材和案例
3. 耐心解答学习过程中的问题
4. 提供课后练习和反馈

### 乙方义务（英语教学方）
1. 按时参加约定的练习时间
2. 准备对话主题和素材
3. 纠正发音和语法错误
4. 提供口语练习建议

## 时间安排
- 开始时间：双方协商确定
- 每周固定时间：待商定
- 总时长：4周（8次课程）
- 每次时长：2小时

## 违约处理
1. 单次迟到超过15分钟，需补偿对方30分钟教学时间
2. 无故缺席1次，扣除5个信用分
3. 连续缺席2次，视为违约，扣除10个信用分
4. 任意一方可提前3天申请终止交换，不扣信用分

## 其他约定
- 交换过程中保持友好沟通
- 遇到问题及时协商解决
- 完成后互相评价，共同进步', true, 'skill_learning'),

(NULL, '考研数学辅导交换编程入门', '## 交换内容

### 我提供的技能：考研数学辅导
- 高等数学重点知识梳理
- 线性代数核心概念讲解
- 概率论与数理统计要点
- 真题解析与答题技巧
- 预计辅导时长：每周3小时，共6周

### 我希望学习的技能：Python编程入门
- Python基础语法
- 数据类型与控制结构
- 函数与模块使用
- 简单项目实战
- 预计学习时长：每周3小时，共6周

## 双方义务

### 甲方义务（数学辅导方）
1. 制定详细的复习计划
2. 准备知识点讲义和习题
3. 批改作业并提供反馈
4. 解答疑难问题

### 乙方义务（编程教学方）
1. 准备教学大纲和代码示例
2. 讲解编程思维和最佳实践
3. 布置练习题并检查代码
4. 提供学习资源推荐

## 时间安排
- 开始时间：双方协商确定
- 每周固定时间：待商定
- 总时长：6周（12次课程）
- 每次时长：3小时

## 违约处理
1. 迟到超过20分钟，需补偿对方40分钟教学时间
2. 无故缺席1次，扣除8个信用分
3. 连续缺席2次，视为违约，扣除15个信用分
4. 任意一方可提前5天申请终止交换，不扣信用分

## 其他约定
- 提前准备教学内容，提高效率
- 课后及时完成作业和练习
- 定期回顾学习进度
- 完成后互相评价', true, 'exam_tutoring'),

(NULL, '吉他弹唱交换绘画技巧', '## 交换内容

### 我提供的技能：吉他弹唱教学
- 吉他基础指法和和弦
- 常见歌曲弹唱教学
- 节奏感训练
- 简单编曲技巧
- 预计教学时长：每周1.5小时，共8周

### 我希望学习的技能：绘画技巧
- 素描基础（线条、明暗、构图）
- 色彩搭配原理
- 简单插画创作
- 数字绘画入门
- 预计学习时长：每周1.5小时，共8周

## 双方义务

### 甲方义务（吉他教学方）
1. 准备吉他和教学曲谱
2. 示范演奏和讲解技巧
3. 纠正手型和节奏问题
4. 推荐练习曲目

### 乙方义务（绘画教学方）
1. 准备绘画工具和素材
2. 讲解绘画理论和技法
3. 点评作品并提供改进建议
4. 分享绘画资源

## 时间安排
- 开始时间：双方协商确定
- 每周固定时间：待商定
- 总时长：8周（16次课程）
- 每次时长：1.5小时

## 违约处理
1. 迟到超过10分钟，需补偿对方20分钟教学时间
2. 无故缺席1次，扣除3个信用分
3. 连续缺席2次，视为违约，扣除8个信用分
4. 任意一方可提前3天申请终止交换，不扣信用分

## 其他约定
- 保持轻松愉快的学习氛围
- 互相鼓励，共同进步
- 分享学习心得和作品
- 完成后互相评价', true, 'interest_exchange'),

(NULL, '日语入门交换摄影技巧', '## 交换内容

### 我提供的技能：日语入门教学
- 五十音图学习
- 基础语法和句型
- 日常会话练习
- 简单阅读理解
- 预计教学时长：每周2小时，共5周

### 我希望学习的技能：摄影技巧
- 相机基础操作
- 构图与光线运用
- 人像/风景摄影技巧
- 后期修图基础
- 预计学习时长：每周2小时，共5周

## 双方义务

### 甲方义务（日语教学方）
1. 准备教学讲义和练习题
2. 纠正发音和语法错误
3. 提供日语学习资源
4. 布置课后作业

### 乙方义务（摄影教学方）
1. 讲解摄影理论和技巧
2. 带领实地拍摄练习
3. 点评照片并提供建议
4. 分享摄影心得

## 时间安排
- 开始时间：双方协商确定
- 每周固定时间：待商定
- 总时长：5周（10次课程）
- 每次时长：2小时

## 违约处理
1. 迟到超过15分钟，需补偿对方30分钟教学时间
2. 无故缺席1次，扣除5个信用分
3. 连续缺席2次，视为违约，扣除10个信用分
4. 任意一方可提前3天申请终止交换，不扣信用分

## 其他约定
- 尊重彼此的学习进度
- 及时沟通学习困难
- 分享学习资源和经验
- 完成后互相评价', true, 'skill_learning'),

(NULL, '健身指导交换视频剪辑', '## 交换内容

### 我提供的技能：健身指导
- 健身基础知识讲解
- 器械使用和动作指导
- 训练计划制定
- 饮食建议
- 预计指导时长：每周2小时，共6周

### 我希望学习的技能：视频剪辑
- 剪辑软件基础操作（PR/剪映）
- 视频素材整理和剪辑
- 转场特效和字幕添加
- 音频处理和配乐
- 预计学习时长：每周2小时，共6周

## 双方义务

### 甲方义务（健身指导方）
1. 制定个性化训练计划
2. 示范动作并纠正姿势
3. 监督训练进度
4. 提供饮食建议

### 乙方义务（剪辑教学方）
1. 准备教学素材和案例
2. 讲解剪辑技巧和流程
3. 指导实战项目
4. 提供软件使用技巧

## 时间安排
- 开始时间：双方协商确定
- 每周固定时间：待商定
- 总时长：6周（12次课程）
- 每次时长：2小时

## 违约处理
1. 迟到超过15分钟，需补偿对方30分钟教学时间
2. 无故缺席1次，扣除5个信用分
3. 连续缺席2次，视为违约，扣除10个信用分
4. 任意一方可提前3天申请终止交换，不扣信用分

## 其他约定
- 注意安全，量力而行
- 保持积极的学习态度
- 及时反馈学习效果
- 完成后互相评价', true, 'interest_exchange');

-- 创建RPC函数：获取交换模板列表
CREATE OR REPLACE FUNCTION get_exchange_templates(
  p_category text DEFAULT NULL,
  p_include_system boolean DEFAULT true,
  p_include_user boolean DEFAULT true
)
RETURNS TABLE (
  id uuid,
  user_id uuid,
  title text,
  content text,
  is_system boolean,
  category text,
  usage_count integer,
  created_at timestamptz,
  updated_at timestamptz
) AS $$
DECLARE
  v_user_id uuid;
BEGIN
  v_user_id := auth.uid();

  RETURN QUERY
  SELECT
    t.id,
    t.user_id,
    t.title,
    t.content,
    t.is_system,
    t.category,
    t.usage_count,
    t.created_at,
    t.updated_at
  FROM exchange_templates t
  WHERE
    (p_category IS NULL OR t.category = p_category)
    AND (
      (p_include_system AND t.is_system = true)
      OR (p_include_user AND t.user_id = v_user_id)
    )
  ORDER BY t.is_system DESC, t.usage_count DESC, t.created_at DESC;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 创建RPC函数：创建交换模板
CREATE OR REPLACE FUNCTION create_exchange_template(
  p_title text,
  p_content text,
  p_category text DEFAULT 'custom'
)
RETURNS json AS $$
DECLARE
  v_user_id uuid;
  v_template_id uuid;
BEGIN
  v_user_id := auth.uid();

  IF v_user_id IS NULL THEN
    RAISE EXCEPTION '未登录';
  END IF;

  INSERT INTO exchange_templates (user_id, title, content, category, is_system)
  VALUES (v_user_id, p_title, p_content, p_category, false)
  RETURNING id INTO v_template_id;

  RETURN json_build_object(
    'success', true,
    'template_id', v_template_id,
    'message', '模板创建成功'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 创建RPC函数：更新交换模板
CREATE OR REPLACE FUNCTION update_exchange_template(
  p_template_id uuid,
  p_title text,
  p_content text,
  p_category text DEFAULT NULL
)
RETURNS json AS $$
DECLARE
  v_user_id uuid;
BEGIN
  v_user_id := auth.uid();

  IF v_user_id IS NULL THEN
    RAISE EXCEPTION '未登录';
  END IF;

  UPDATE exchange_templates
  SET
    title = p_title,
    content = p_content,
    category = COALESCE(p_category, category),
    updated_at = NOW()
  WHERE id = p_template_id AND user_id = v_user_id AND is_system = false;

  IF NOT FOUND THEN
    RAISE EXCEPTION '模板不存在或无权限修改';
  END IF;

  RETURN json_build_object(
    'success', true,
    'message', '模板更新成功'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 创建RPC函数：删除交换模板
CREATE OR REPLACE FUNCTION delete_exchange_template(p_template_id uuid)
RETURNS json AS $$
DECLARE
  v_user_id uuid;
BEGIN
  v_user_id := auth.uid();

  IF v_user_id IS NULL THEN
    RAISE EXCEPTION '未登录';
  END IF;

  DELETE FROM exchange_templates
  WHERE id = p_template_id AND user_id = v_user_id AND is_system = false;

  IF NOT FOUND THEN
    RAISE EXCEPTION '模板不存在或无权限删除';
  END IF;

  RETURN json_build_object(
    'success', true,
    'message', '模板删除成功'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 创建RPC函数：增加模板使用次数
CREATE OR REPLACE FUNCTION increment_template_usage(p_template_id uuid)
RETURNS void AS $$
BEGIN
  UPDATE exchange_templates
  SET usage_count = usage_count + 1
  WHERE id = p_template_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
