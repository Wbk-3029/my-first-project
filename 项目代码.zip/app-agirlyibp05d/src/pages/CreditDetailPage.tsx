import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { MainLayout } from '@/components/layouts/MainLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Progress } from '@/components/ui/progress';
import { getCreditInfo, getCreditLogs } from '@/db/api';
import type { CreditLog, CreditInfo } from '@/db/api';
import { getCreditLevel } from '@/lib/credit-utils';
import { ArrowLeft, Award, TrendingUp, TrendingDown, Info, Star, Shield, Zap, Target } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { zhCN } from 'date-fns/locale';
import { toast } from 'sonner';

export default function CreditDetailPage() {
  const [creditInfo, setCreditInfo] = useState<CreditInfo | null>(null);
  const [logs, setLogs] = useState<CreditLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const [info, logsData] = await Promise.all([getCreditInfo(), getCreditLogs(1, 20)]);

      setCreditInfo(info);
      setLogs(logsData);
      setHasMore(logsData.length === 20);
    } catch (error) {
      console.error('加载数据失败:', error);
      toast.error('加载数据失败');
    } finally {
      setLoading(false);
    }
  };

  const loadMore = async () => {
    if (loadingMore || !hasMore) return;

    try {
      setLoadingMore(true);
      const nextPage = currentPage + 1;
      const logsData = await getCreditLogs(nextPage, 20);

      if (logsData.length < 20) {
        setHasMore(false);
      }

      setLogs((prev) => [...prev, ...logsData]);
      setCurrentPage(nextPage);
    } catch (error) {
      console.error('加载更多失败:', error);
      toast.error('加载更多失败');
    } finally {
      setLoadingMore(false);
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('zh-CN', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  if (loading) {
    return (
      <MainLayout>
        <div className="container max-w-4xl mx-auto px-4 py-8 space-y-6">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-48 w-full" />
          <Skeleton className="h-64 w-full" />
        </div>
      </MainLayout>
    );
  }

  const score = creditInfo?.score || 100;
  const level = getCreditLevel(score);
  const completionRate =
    creditInfo && creditInfo.total_exchanges > 0
      ? (creditInfo.completed_exchanges / creditInfo.total_exchanges) * 100
      : 100;
  const avgRating =
    creditInfo && creditInfo.rating_count > 0 ? creditInfo.total_rating / creditInfo.rating_count : 5;
  const timelinessRate =
    creditInfo && creditInfo.completed_exchanges > 0
      ? (creditInfo.timely_count / creditInfo.completed_exchanges) * 100
      : 100;

  return (
    <MainLayout>
      <div className="container max-w-4xl mx-auto px-4 py-8 space-y-6">
        {/* Header */}
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" asChild>
            <Link to="/profile">
              <ArrowLeft className="h-5 w-5" />
            </Link>
          </Button>
          <h1 className="text-2xl font-bold">信用分明细</h1>
        </div>

        {/* Credit Score Card */}
        <Card className="bg-gradient-to-br from-amber-50 via-orange-50 to-yellow-50 dark:from-amber-950 dark:via-orange-950 dark:to-yellow-950 border-amber-200 dark:border-amber-800">
          <CardContent className="p-6">
            <div className="space-y-4">
              <div className="text-center">
                <div className="text-sm text-muted-foreground mb-2">当前信用分</div>
                <div className="flex items-center justify-center gap-4 mb-4">
                  <div className="text-6xl font-bold text-amber-600 dark:text-amber-400">
                    {score.toFixed(1)}
                  </div>
                  <Badge
                    className={`${level.bgColor} ${level.color} text-lg px-4 py-2`}
                  >
                    <Award className="h-4 w-4 mr-1" />
                    {level.label}
                  </Badge>
                </div>
                <Progress value={score} className="h-3 mb-2" />
                <div className="text-xs text-muted-foreground">满分 100 分</div>
              </div>

              {/* Stats Grid */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-4 border-t border-border">
                <div className="text-center">
                  <div className="text-xs text-muted-foreground mb-1">完成率</div>
                  <div className="text-lg font-semibold text-green-600">
                    {completionRate.toFixed(0)}%
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-xs text-muted-foreground mb-1">平均评分</div>
                  <div className="text-lg font-semibold text-blue-600">
                    {avgRating.toFixed(1)}★
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-xs text-muted-foreground mb-1">及时率</div>
                  <div className="text-lg font-semibold text-purple-600">
                    {timelinessRate.toFixed(0)}%
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-xs text-muted-foreground mb-1">活跃度</div>
                  <div className="text-lg font-semibold text-orange-600">
                    {creditInfo?.activity_score.toFixed(1) || '0.0'}
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Change Logs */}
        <Card>
          <CardHeader>
            <CardTitle>变化记录</CardTitle>
          </CardHeader>
          <CardContent>
            {logs.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                <Award className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>暂无记录</p>
              </div>
            ) : (
              <div className="space-y-3">
                {logs.map((log) => (
                  <Card key={log.id} className="hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            {log.change_amount >= 0 ? (
                              <TrendingUp className="h-4 w-4 text-green-500 shrink-0" />
                            ) : (
                              <TrendingDown className="h-4 w-4 text-red-500 shrink-0" />
                            )}
                            <span className="font-medium truncate">{log.reason}</span>
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {formatDate(log.created_at)}
                            <span className="mx-2">·</span>
                            {formatDistanceToNow(new Date(log.created_at), {
                              addSuffix: true,
                              locale: zhCN,
                            })}
                          </div>
                        </div>
                        <div className="text-right shrink-0">
                          <div
                            className={`text-lg font-bold ${
                              log.change_amount >= 0 ? 'text-green-600' : 'text-red-600'
                            }`}
                          >
                            {log.change_amount >= 0 ? '+' : ''}
                            {log.change_amount.toFixed(1)}
                          </div>
                          <div className="text-xs text-muted-foreground">
                            当前 {log.new_score.toFixed(1)}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}

            {hasMore && logs.length > 0 && (
              <div className="mt-6 text-center">
                <Button
                  variant="outline"
                  onClick={loadMore}
                  disabled={loadingMore}
                  className="w-full md:w-auto"
                >
                  {loadingMore ? '加载中...' : '加载更多'}
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Rules Card */}
        <Card className="bg-muted/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Info className="h-4 w-4" />
              信用分规则说明
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-sm text-muted-foreground">
            <div>
              <h4 className="font-medium text-foreground mb-2 flex items-center gap-2">
                <Target className="h-4 w-4" />
                信用分计算
              </h4>
              <div className="space-y-2 pl-6">
                <div className="flex items-start gap-2">
                  <span className="text-primary font-medium">30%</span>
                  <span>交换完成率 = 成功完成的交换次数 ÷ 发起的交换总次数</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-primary font-medium">40%</span>
                  <span>平均评价分 = 每次交换后互评（1-5星）的算术平均值</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-primary font-medium">20%</span>
                  <span>履约及时率 = 按时完成交换的次数 ÷ 总交换次数</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-primary font-medium">10%</span>
                  <span>账户活跃度 = 近30天登录天数、发布技能数量、参与社区互动</span>
                </div>
              </div>
            </div>

            <div>
              <h4 className="font-medium text-foreground mb-2 flex items-center gap-2">
                <Shield className="h-4 w-4" />
                信用等级与权益
              </h4>
              <div className="space-y-2 pl-6">
                <div>
                  <Badge className="bg-muted text-muted-foreground mb-1">新手 (0-59分)</Badge>
                  <p className="text-xs">基础功能，发布技能需人工审核，信用系数0.9</p>
                </div>
                <div>
                  <Badge className="bg-blue-100 text-blue-600 dark:bg-blue-950 dark:text-blue-400 mb-1">
                    可信 (60-79分)
                  </Badge>
                  <p className="text-xs">正常发布，信用系数1.0</p>
                </div>
                <div>
                  <Badge className="bg-purple-100 text-purple-600 dark:bg-purple-950 dark:text-purple-400 mb-1">
                    优秀 (80-89分)
                  </Badge>
                  <p className="text-xs">发布优先级提升，信用系数1.1</p>
                </div>
                <div>
                  <Badge className="bg-amber-100 text-amber-600 dark:bg-amber-950 dark:text-amber-400 mb-1">
                    大神 (90-100分)
                  </Badge>
                  <p className="text-xs">优先推荐位，信用系数1.2，可发起团购</p>
                </div>
              </div>
            </div>

            <div>
              <h4 className="font-medium text-foreground mb-2 flex items-center gap-2">
                <Zap className="h-4 w-4" />
                信用分变化规则
              </h4>
              <ul className="space-y-1 list-disc list-inside pl-6">
                <li>获得4-5星好评：+0.5分</li>
                <li>获得3星：0分</li>
                <li>获得1-2星差评：-1分</li>
                <li>无故取消交换：-2分</li>
                <li>被举报核实：-3至-10分（视情节）</li>
                <li>连续10次获得好评：+2分（奖励）</li>
                <li>信用分低于20分时，需完成信用恢复任务（3次小额交换且无差评）</li>
              </ul>
            </div>

            <div className="pt-2 border-t border-border">
              <p className="text-xs">
                💡 提示：保持良好的交换记录和及时履约，可以快速提升信用分。信用分越高，获得的积分奖励系数越高！
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}
