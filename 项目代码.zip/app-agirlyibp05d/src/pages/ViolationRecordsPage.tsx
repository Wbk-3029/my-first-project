import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { MainLayout } from '@/components/layouts/MainLayout';
import { PageHeader } from '@/components/layouts/PageHeader';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AppealDialog } from '@/components/violation/AppealDialog';
import { getViolationRecords, getViolationStats } from '@/db/api';
import type { ViolationRecord, ViolationStats } from '@/types';
import { useAuth } from '@/contexts/AuthContext';
import { AlertTriangle, ShieldAlert, Clock, CheckCircle, XCircle, ArrowLeft, Scale, FileText } from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { zhCN } from 'date-fns/locale';

const VIOLATION_TYPE_LABELS: Record<string, string> = {
  no_show: '爽约',
  false_info: '虚假信息',
  malicious_review: '恶意评价',
  spam: '垃圾信息',
  harassment: '骚扰行为',
  other: '其他违规',
};

const VIOLATION_STATUS_LABELS: Record<string, string> = {
  pending: '待处理',
  processing: '处理中',
  resolved: '已处理',
  rejected: '已驳回',
};

const VIOLATION_STATUS_ICONS: Record<string, React.ReactNode> = {
  pending: <Clock className="h-4 w-4" />,
  processing: <AlertTriangle className="h-4 w-4" />,
  resolved: <CheckCircle className="h-4 w-4" />,
  rejected: <XCircle className="h-4 w-4" />,
};

export default function ViolationRecordsPage() {
  const navigate = useNavigate();
  const { profile } = useAuth();
  const [records, setRecords] = useState<ViolationRecord[]>([]);
  const [stats, setStats] = useState<ViolationStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('all');
  const [appealDialogOpen, setAppealDialogOpen] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState<ViolationRecord | null>(null);

  useEffect(() => {
    if (profile?.id) {
      loadData();
    }
  }, [profile?.id, activeTab]);

  const loadData = async () => {
    if (!profile?.id) return;

    try {
      setLoading(true);
      const [recordsData, statsData] = await Promise.all([
        getViolationRecords({
          violatorId: profile.id,
          status: activeTab === 'all' ? undefined : activeTab,
        }),
        getViolationStats(profile.id),
      ]);

      setRecords(recordsData);
      setStats(statsData);
    } catch (error) {
      console.error('加载违规记录失败:', error);
      toast.error('加载违规记录失败');
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case 'pending':
        return 'secondary';
      case 'processing':
        return 'default';
      case 'resolved':
        return 'destructive';
      case 'rejected':
        return 'outline';
      default:
        return 'secondary';
    }
  };

  const getTypeBadgeVariant = (type: string) => {
    switch (type) {
      case 'no_show':
      case 'false_info':
        return 'destructive';
      case 'malicious_review':
      case 'spam':
        return 'default';
      case 'harassment':
        return 'destructive';
      default:
        return 'secondary';
    }
  };

  const handleAppeal = (record: ViolationRecord) => {
    setSelectedRecord(record);
    setAppealDialogOpen(true);
  };

  const canAppeal = (record: ViolationRecord) => {
    // 只能对已处理的记录申诉
    if (record.status !== 'resolved') return false;
    // 检查是否可以申诉
    if (record.can_appeal === false) return false;
    // 检查申诉状态
    if (record.appeal_status && record.appeal_status !== 'not_appealed') return false;
    // 检查申诉时限（处理后7天内）
    if (!record.handled_at) return false;
    const handledDate = new Date(record.handled_at);
    const deadline = new Date(handledDate.getTime() + 7 * 24 * 60 * 60 * 1000);
    return new Date() <= deadline;
  };

  const getAppealStatusText = (record: ViolationRecord) => {
    if (!record.appeal_status) return null;
    switch (record.appeal_status) {
      case 'appealing':
        return '申诉中';
      case 'appeal_approved':
        return '申诉成功';
      case 'appeal_rejected':
        return '申诉失败';
      default:
        return null;
    }
  };

  return (
    <MainLayout>
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate('/profile')}
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <PageHeader title="违规记录" />
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => navigate('/profile/appeals')}
            className="gap-2"
          >
            <FileText className="h-4 w-4" />
            申诉记录
          </Button>
        </div>

        {/* 统计卡片 */}
        {stats && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="pt-6">
                <div className="text-center">
                  <div className="text-2xl font-bold text-destructive">
                    {stats.total_violations}
                  </div>
                  <div className="text-sm text-muted-foreground mt-1">
                    总违规次数
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="text-center">
                  <div className="text-2xl font-bold text-orange-500">
                    {stats.pending_violations}
                  </div>
                  <div className="text-sm text-muted-foreground mt-1">
                    待处理
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="text-center">
                  <div className="text-2xl font-bold">
                    {stats.resolved_violations}
                  </div>
                  <div className="text-sm text-muted-foreground mt-1">
                    已处理
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="text-center">
                  <div className="text-2xl font-bold text-destructive">
                    -{stats.total_credit_deducted}
                  </div>
                  <div className="text-sm text-muted-foreground mt-1">
                    扣除信用分
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* 违规类型统计 */}
        {stats && stats.resolved_violations > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="text-base">违规类型统计</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {stats.no_show_count > 0 && (
                  <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                    <span className="text-sm">爽约</span>
                    <span className="font-semibold">{stats.no_show_count}次</span>
                  </div>
                )}
                {stats.false_info_count > 0 && (
                  <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                    <span className="text-sm">虚假信息</span>
                    <span className="font-semibold">{stats.false_info_count}次</span>
                  </div>
                )}
                {stats.malicious_review_count > 0 && (
                  <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                    <span className="text-sm">恶意评价</span>
                    <span className="font-semibold">{stats.malicious_review_count}次</span>
                  </div>
                )}
                {stats.spam_count > 0 && (
                  <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                    <span className="text-sm">垃圾信息</span>
                    <span className="font-semibold">{stats.spam_count}次</span>
                  </div>
                )}
                {stats.harassment_count > 0 && (
                  <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                    <span className="text-sm">骚扰行为</span>
                    <span className="font-semibold">{stats.harassment_count}次</span>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {/* 违规记录列表 */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">违规记录</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="all">全部</TabsTrigger>
                <TabsTrigger value="pending">待处理</TabsTrigger>
                <TabsTrigger value="resolved">已处理</TabsTrigger>
                <TabsTrigger value="rejected">已驳回</TabsTrigger>
              </TabsList>

              <TabsContent value={activeTab} className="mt-6">
                {loading ? (
                  <div className="space-y-4">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="space-y-3">
                        <Skeleton className="h-4 w-1/4" />
                        <Skeleton className="h-20 w-full" />
                      </div>
                    ))}
                  </div>
                ) : records.length === 0 ? (
                  <div className="text-center py-12">
                    <ShieldAlert className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                    <p className="text-muted-foreground">暂无违规记录</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {records.map((record) => (
                      <div
                        key={record.id}
                        className="border rounded-lg p-4 space-y-3"
                      >
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1 space-y-2">
                            <div className="flex items-center gap-2 flex-wrap">
                              <Badge variant={getTypeBadgeVariant(record.type)}>
                                {VIOLATION_TYPE_LABELS[record.type]}
                              </Badge>
                              <Badge
                                variant={getStatusBadgeVariant(record.status)}
                                className="gap-1"
                              >
                                {VIOLATION_STATUS_ICONS[record.status]}
                                {VIOLATION_STATUS_LABELS[record.status]}
                              </Badge>
                              {record.credit_deducted > 0 && (
                                <Badge variant="destructive">
                                  -{record.credit_deducted}信用分
                                </Badge>
                              )}
                              {getAppealStatusText(record) && (
                                <Badge variant="outline" className="gap-1">
                                  <Scale className="h-3 w-3" />
                                  {getAppealStatusText(record)}
                                </Badge>
                              )}
                            </div>

                            <p className="text-sm">{record.description}</p>

                            {record.handler_note && (
                              <div className="bg-muted p-3 rounded-lg text-sm">
                                <p className="font-medium mb-1">处理说明：</p>
                                <p className="text-muted-foreground">
                                  {record.handler_note}
                                </p>
                              </div>
                            )}
                          </div>

                          {/* 申诉按钮 */}
                          {canAppeal(record) && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleAppeal(record)}
                              className="gap-2 shrink-0"
                            >
                              <Scale className="h-4 w-4" />
                              申诉
                            </Button>
                          )}
                        </div>

                        <div className="flex items-center justify-between text-xs text-muted-foreground pt-2 border-t">
                          <span>
                            举报时间：
                            {format(
                              new Date(record.created_at),
                              'yyyy-MM-dd HH:mm',
                              { locale: zhCN }
                            )}
                          </span>
                          {record.handled_at && (
                            <span>
                              处理时间：
                              {format(
                                new Date(record.handled_at),
                                'yyyy-MM-dd HH:mm',
                                { locale: zhCN }
                              )}
                            </span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {/* 温馨提示 */}
        <Card className="border-orange-200 bg-orange-50 dark:bg-orange-950/20">
          <CardContent className="pt-6">
            <div className="flex gap-3">
              <AlertTriangle className="h-5 w-5 text-orange-500 shrink-0 mt-0.5" />
              <div className="space-y-2 text-sm">
                <p className="font-medium text-orange-900 dark:text-orange-100">
                  违规处罚规则
                </p>
                <ul className="space-y-1 text-orange-800 dark:text-orange-200">
                  <li>• 爽约：扣10分，累计3次警告，5次封号</li>
                  <li>• 虚假信息：扣15分，累计2次警告，3次封号</li>
                  <li>• 恶意评价：扣8分，累计3次警告，5次封号</li>
                  <li>• 垃圾信息：扣5分，累计5次警告，10次封号</li>
                  <li>• 骚扰行为：扣20分，累计1次警告，2次封号</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 申诉对话框 */}
      {selectedRecord && (
        <AppealDialog
          open={appealDialogOpen}
          onOpenChange={setAppealDialogOpen}
          violationRecordId={selectedRecord.id}
          violationType={selectedRecord.type}
          violationDescription={selectedRecord.description}
          creditDeducted={selectedRecord.credit_deducted}
          onSuccess={loadData}
        />
      )}
    </MainLayout>
  );
}
