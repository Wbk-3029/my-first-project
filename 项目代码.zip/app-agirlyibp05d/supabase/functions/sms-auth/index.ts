import { createClient } from 'jsr:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface SendCodeRequest {
  phone: string;
}

interface VerifyCodeRequest {
  phone: string;
  code: string;
  sessionId: string;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const { action, ...body } = await req.json();

    // 发送验证码
    if (action === 'send') {
      const { phone } = body as SendCodeRequest;

      if (!phone || !/^1[3-9]\d{9}$/.test(phone)) {
        return new Response(
          JSON.stringify({ success: false, error: '请输入正确的手机号' }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
        );
      }

      // 调用短信API发送验证码
      const apiKey = Deno.env.get('INTEGRATIONS_API_KEY');
      const response = await fetch(
        'https://app-agirlyibp05d-api-W9z3M74x6ZNL-gateway.appmiaoda.com/v1/code/send_message',
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Gateway-Authorization': `Bearer ${apiKey}`,
          },
          body: JSON.stringify({ mobile: phone }),
        }
      );

      const result = await response.json();

      if (result.status !== 0) {
        return new Response(
          JSON.stringify({ success: false, error: result.msg || '发送失败' }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
        );
      }

      return new Response(
        JSON.stringify({
          success: true,
          sessionId: result.data.sessionId,
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // 验证验证码并登录
    if (action === 'verify') {
      const { phone, code, sessionId } = body as VerifyCodeRequest;

      if (!phone || !code || !sessionId) {
        return new Response(
          JSON.stringify({ success: false, error: '参数不完整' }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
        );
      }

      // 调用短信API验证验证码
      const apiKey = Deno.env.get('INTEGRATIONS_API_KEY');
      const verifyResponse = await fetch(
        'https://app-agirlyibp05d-api-Xa6JZxjyqK0a-gateway.appmiaoda.com/v1/code/verify_message_code',
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Gateway-Authorization': `Bearer ${apiKey}`,
          },
          body: JSON.stringify({
            mobile: phone,
            sessionId,
            code,
          }),
        }
      );

      const verifyResult = await verifyResponse.json();

      if (verifyResult.status !== 0) {
        return new Response(
          JSON.stringify({ success: false, error: verifyResult.msg || '验证码错误' }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
        );
      }

      // 验证成功,查找或创建用户
      const { data: existingProfile } = await supabaseClient
        .from('profiles')
        .select('*')
        .eq('phone', phone)
        .maybeSingle();

      let userId: string;
      let userEmail: string;

      if (existingProfile) {
        // 用户已存在
        userId = existingProfile.id;
        userEmail = `${phone}@sms.local`;
      } else {
        // 创建新用户
        const tempPassword = Math.random().toString(36).slice(-12) + 'Aa1!';
        userEmail = `${phone}@sms.local`;

        const { data: authData, error: authError } = await supabaseClient.auth.admin.createUser({
          email: userEmail,
          password: tempPassword,
          email_confirm: true,
        });

        if (authError || !authData.user) {
          return new Response(
            JSON.stringify({ success: false, error: '创建用户失败' }),
            { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
          );
        }

        userId = authData.user.id;

        // 更新profile表
        await supabaseClient
          .from('profiles')
          .update({
            phone,
            nickname: `用户${phone.slice(-4)}`,
          })
          .eq('id', userId);
      }

      // 生成访问令牌
      const { data: tokenData, error: tokenError } =
        await supabaseClient.auth.admin.generateLink({
          type: 'magiclink',
          email: userEmail,
        });

      if (tokenError || !tokenData) {
        return new Response(
          JSON.stringify({ success: false, error: '生成登录凭证失败' }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
        );
      }

      // 从magic link中提取token
      const url = new URL(tokenData.properties.action_link);
      const accessToken = url.searchParams.get('token');
      const refreshToken = url.searchParams.get('token'); // 使用相同的token

      if (!accessToken) {
        return new Response(
          JSON.stringify({ success: false, error: '生成token失败' }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
        );
      }

      return new Response(
        JSON.stringify({
          success: true,
          userId,
          accessToken,
          refreshToken,
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    return new Response(
      JSON.stringify({ success: false, error: '无效的操作' }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
    );
  } catch (error) {
    console.error('Error:', error);
    return new Response(
      JSON.stringify({ success: false, error: error.message || '服务器错误' }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
    );
  }
});
