-- 创建申诉证据存储桶
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'appeal-evidence',
  'appeal-evidence',
  false,
  5242880, -- 5MB
  ARRAY['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp', 'application/pdf']
)
ON CONFLICT (id) DO NOTHING;

-- 创建存储策略：用户可以上传自己的申诉证据
CREATE POLICY "Users can upload their own appeal evidence"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'appeal-evidence' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

-- 创建存储策略：用户可以查看自己的申诉证据
CREATE POLICY "Users can view their own appeal evidence"
ON storage.objects FOR SELECT
TO authenticated
USING (
  bucket_id = 'appeal-evidence' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

-- 创建存储策略：用户可以删除自己的申诉证据
CREATE POLICY "Users can delete their own appeal evidence"
ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'appeal-evidence' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

-- 创建存储策略：管理员可以查看所有申诉证据
CREATE POLICY "Admins can view all appeal evidence"
ON storage.objects FOR SELECT
TO authenticated
USING (
  bucket_id = 'appeal-evidence'
  -- 这里可以添加管理员角色检查
);

COMMENT ON POLICY "Users can upload their own appeal evidence" ON storage.objects IS '用户可以上传自己的申诉证据';
COMMENT ON POLICY "Users can view their own appeal evidence" ON storage.objects IS '用户可以查看自己的申诉证据';
COMMENT ON POLICY "Users can delete their own appeal evidence" ON storage.objects IS '用户可以删除自己的申诉证据';
COMMENT ON POLICY "Admins can view all appeal evidence" ON storage.objects IS '管理员可以查看所有申诉证据';
