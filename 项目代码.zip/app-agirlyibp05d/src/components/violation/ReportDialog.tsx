import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { reportViolation } from '@/db/api';
import { toast } from 'sonner';
import { AlertTriangle } from 'lucide-react';

interface ReportDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  violatorId: string;
  violatorName: string;
  relatedId?: string;
  relatedType?: string;
}

const VIOLATION_TYPES = [
  { value: 'no_show', label: '爽约', description: '未按时参加交换或无故缺席' },
  { value: 'false_info', label: '虚假信息', description: '技能描述不实或提供虚假资料' },
  { value: 'malicious_review', label: '恶意评价', description: '恶意差评或不实评价' },
  { value: 'spam', label: '垃圾信息', description: '发布垃圾内容或广告' },
  { value: 'harassment', label: '骚扰行为', description: '言语攻击、辱骂或骚扰他人' },
  { value: 'other', label: '其他违规', description: '其他违反平台规则的行为' },
];

export function ReportDialog({
  open,
  onOpenChange,
  violatorId,
  violatorName,
  relatedId,
  relatedType,
}: ReportDialogProps) {
  const [type, setType] = useState<string>('');
  const [description, setDescription] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async () => {
    if (!type) {
      toast.error('请选择违规类型');
      return;
    }

    if (!description.trim()) {
      toast.error('请描述违规情况');
      return;
    }

    try {
      setSubmitting(true);
      const result = await reportViolation({
        violatorId,
        type,
        description: description.trim(),
        relatedId,
        relatedType,
      });

      if (result.success) {
        toast.success(result.message);
        onOpenChange(false);
        setType('');
        setDescription('');
      } else {
        toast.error(result.message);
      }
    } catch (error) {
      console.error('举报失败:', error);
      toast.error('举报失败');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-destructive" />
            举报用户
          </DialogTitle>
          <DialogDescription>
            举报用户：{violatorName}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label>违规类型 *</Label>
            <Select value={type} onValueChange={setType}>
              <SelectTrigger>
                <SelectValue placeholder="请选择违规类型" />
              </SelectTrigger>
              <SelectContent>
                {VIOLATION_TYPES.map((item) => (
                  <SelectItem key={item.value} value={item.value}>
                    <div className="flex flex-col items-start">
                      <span className="font-medium">{item.label}</span>
                      <span className="text-xs text-muted-foreground">
                        {item.description}
                      </span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>违规描述 *</Label>
            <Textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="请详细描述违规情况，包括时间、地点、具体行为等"
              className="min-h-[120px] resize-none"
              maxLength={500}
            />
            <p className="text-xs text-muted-foreground text-right">
              {description.length}/500
            </p>
          </div>

          <div className="bg-muted p-3 rounded-lg text-sm text-muted-foreground">
            <p className="font-medium mb-1">举报须知：</p>
            <ul className="space-y-1 text-xs">
              <li>• 请如实填写举报信息，虚假举报将受到处罚</li>
              <li>• 我们会在3个工作日内处理您的举报</li>
              <li>• 举报结果将通过站内通知告知您</li>
            </ul>
          </div>
        </div>

        <div className="flex gap-3 justify-end">
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            disabled={submitting}
          >
            取消
          </Button>
          <Button onClick={handleSubmit} disabled={submitting}>
            {submitting ? '提交中...' : '提交举报'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
