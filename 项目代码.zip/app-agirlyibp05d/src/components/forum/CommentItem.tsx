import { useState } from 'react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { UserProfileDialog } from '@/components/user/UserProfileDialog';
import type { PostReply } from '@/types';
import { Heart, MessageCircle, ChevronDown, ChevronUp } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { zhCN } from 'date-fns/locale';

interface CommentItemProps {
  reply: PostReply;
  onReply?: (replyId: string) => void;
}

export function CommentItem({ reply, onReply }: CommentItemProps) {
  const [showReplies, setShowReplies] = useState(false);
  
  // 获取子回复数量
  const childRepliesCount = reply.replies?.length || 0;

  return (
    <div className="space-y-3">
      {/* 主评论 */}
      <div className="flex gap-3">
        {/* 头像 */}
        {reply.profiles && (
          <UserProfileDialog
            userId={reply.user_id}
            userName={reply.profiles.nickname || '匿名用户'}
            userAvatar={reply.profiles.avatar_url}
            userCreditScore={reply.profiles.credit_score || 100}
            trigger={
              <Avatar className="h-9 w-9 cursor-pointer ring-2 ring-background hover:ring-primary/20 transition-all">
                <AvatarImage src={reply.profiles.avatar_url || undefined} />
                <AvatarFallback>{reply.profiles.nickname?.[0] || '用'}</AvatarFallback>
              </Avatar>
            }
          />
        )}

        {/* 内容区域 */}
        <div className="flex-1 min-w-0">
          {/* 用户名和时间 */}
          <div className="flex items-center gap-2 mb-1">
            <span className="font-medium text-sm">
              {reply.profiles?.nickname || '匿名用户'}
            </span>
            <span className="text-xs text-muted-foreground">
              {formatDistanceToNow(new Date(reply.created_at), {
                addSuffix: true,
                locale: zhCN,
              })}
            </span>
          </div>

          {/* 评论内容 */}
          <p className="text-sm leading-relaxed mb-2">{reply.content}</p>

          {/* 操作按钮 */}
          <div className="flex items-center gap-4">
            <button
              className="flex items-center gap-1 text-muted-foreground hover:text-primary transition-colors min-h-8"
              onClick={() => {
                // TODO: 点赞功能
              }}
            >
              <Heart className="h-3.5 w-3.5" />
              <span className="text-xs">{reply.like_count || 0}</span>
            </button>

            <button
              className="flex items-center gap-1 text-muted-foreground hover:text-primary transition-colors min-h-8"
              onClick={() => onReply?.(reply.id)}
            >
              <MessageCircle className="h-3.5 w-3.5" />
              <span className="text-xs">回复</span>
            </button>
          </div>

          {/* 子回复折叠/展开 */}
          {childRepliesCount > 0 && (
            <Button
              variant="ghost"
              size="sm"
              className="mt-2 h-8 text-xs text-primary hover:text-primary/80"
              onClick={() => setShowReplies(!showReplies)}
            >
              {showReplies ? (
                <>
                  <ChevronUp className="h-3 w-3 mr-1" />
                  收起回复
                </>
              ) : (
                <>
                  <ChevronDown className="h-3 w-3 mr-1" />
                  查看 {childRepliesCount} 条回复
                </>
              )}
            </Button>
          )}

          {/* 子回复列表 */}
          {showReplies && reply.replies && reply.replies.length > 0 && (
            <div className="mt-3 pl-4 border-l-2 border-muted space-y-3">
              {reply.replies.map((childReply) => (
                <CommentItem key={childReply.id} reply={childReply} onReply={onReply} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
