-- 创建触发器函数，同步积分到profiles表
CREATE OR REPLACE FUNCTION sync_integral_to_profile()
RETURNS TRIGGER AS $$
BEGIN
  -- 更新profiles表的points字段
  UPDATE profiles
  SET points = NEW.balance
  WHERE id = NEW.user_id;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 创建触发器
DROP TRIGGER IF EXISTS on_integral_updated ON user_integral;
CREATE TRIGGER on_integral_updated
  AFTER INSERT OR UPDATE OF balance ON user_integral
  FOR EACH ROW
  EXECUTE FUNCTION sync_integral_to_profile();

-- 初始化现有用户的积分（从user_integral同步到profiles）
UPDATE profiles p
SET points = COALESCE(ui.balance, 0)
FROM user_integral ui
WHERE p.id = ui.user_id;