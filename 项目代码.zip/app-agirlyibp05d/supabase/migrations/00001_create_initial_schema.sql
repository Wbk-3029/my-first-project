-- 创建枚举类型
CREATE TYPE public.skill_type AS ENUM ('entertainment', 'normal', 'hot', 'rare', 'master');
CREATE TYPE public.exchange_type AS ENUM ('direct', 'point', 'group');
CREATE TYPE public.exchange_status AS ENUM ('pending', 'accepted', 'rejected', 'in_progress', 'completed', 'cancelled');
CREATE TYPE public.group_buy_status AS ENUM ('active', 'completed', 'expired');
CREATE TYPE public.rating_type AS ENUM ('positive', 'negative');
CREATE TYPE public.favorite_type AS ENUM ('skill', 'post');
CREATE TYPE public.skill_status AS ENUM ('active', 'inactive');

-- 用户表
CREATE TABLE profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  phone text UNIQUE,
  nickname text,
  avatar_url text,
  credit_score int DEFAULT 100 CHECK (credit_score >= 0 AND credit_score <= 100),
  points int DEFAULT 0 CHECK (points >= 0),
  created_at timestamptz DEFAULT now()
);

-- 技能表
CREATE TABLE skills (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  name text NOT NULL,
  type skill_type NOT NULL,
  description text,
  price int NOT NULL CHECK (price >= 0),
  exchange_count int DEFAULT 0,
  status skill_status DEFAULT 'active',
  created_at timestamptz DEFAULT now()
);

-- 技能价格调整历史
CREATE TABLE skill_price_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  skill_id uuid NOT NULL REFERENCES skills(id) ON DELETE CASCADE,
  old_price int NOT NULL,
  new_price int NOT NULL,
  reason text,
  created_at timestamptz DEFAULT now()
);

-- 帖子表
CREATE TABLE posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  title text NOT NULL,
  content text NOT NULL,
  skill_type skill_type NOT NULL,
  exchange_need text,
  like_count int DEFAULT 0,
  reply_count int DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- 帖子点赞表
CREATE TABLE post_likes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(post_id, user_id)
);

-- 帖子回复表
CREATE TABLE post_replies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  content text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- 交换记录表
CREATE TABLE exchanges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  type exchange_type NOT NULL,
  initiator_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  receiver_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  initiator_skill_id uuid REFERENCES skills(id) ON DELETE SET NULL,
  receiver_skill_id uuid NOT NULL REFERENCES skills(id) ON DELETE CASCADE,
  points_amount int,
  status exchange_status DEFAULT 'pending',
  note text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 团购表
CREATE TABLE group_buys (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  skill_id uuid NOT NULL REFERENCES skills(id) ON DELETE CASCADE,
  initiator_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  original_price int NOT NULL,
  group_price int NOT NULL CHECK (group_price < original_price),
  participant_count int DEFAULT 1,
  status group_buy_status DEFAULT 'active',
  expires_at timestamptz NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- 团购参与者表
CREATE TABLE group_buy_participants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_buy_id uuid NOT NULL REFERENCES group_buys(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(group_buy_id, user_id)
);

-- 评价表
CREATE TABLE ratings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  exchange_id uuid NOT NULL REFERENCES exchanges(id) ON DELETE CASCADE,
  rater_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  rated_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  rating_type rating_type NOT NULL,
  comment text,
  created_at timestamptz DEFAULT now(),
  UNIQUE(exchange_id, rater_id)
);

-- 收藏表
CREATE TABLE favorites (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  item_type favorite_type NOT NULL,
  item_id uuid NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, item_type, item_id)
);

-- 创建索引
CREATE INDEX idx_skills_user_id ON skills(user_id);
CREATE INDEX idx_skills_type ON skills(type);
CREATE INDEX idx_skills_status ON skills(status);
CREATE INDEX idx_posts_user_id ON posts(user_id);
CREATE INDEX idx_posts_skill_type ON posts(skill_type);
CREATE INDEX idx_exchanges_initiator_id ON exchanges(initiator_id);
CREATE INDEX idx_exchanges_receiver_id ON exchanges(receiver_id);
CREATE INDEX idx_exchanges_status ON exchanges(status);
CREATE INDEX idx_group_buys_skill_id ON group_buys(skill_id);
CREATE INDEX idx_group_buys_status ON group_buys(status);
CREATE INDEX idx_favorites_user_id ON favorites(user_id);

-- 创建触发器函数：自动同步用户
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, phone)
  VALUES (NEW.id, NEW.phone);
  RETURN NEW;
END;
$$;

-- 创建触发器
DROP TRIGGER IF EXISTS on_auth_user_confirmed ON auth.users;
CREATE TRIGGER on_auth_user_confirmed
  AFTER UPDATE ON auth.users
  FOR EACH ROW
  WHEN (OLD.confirmed_at IS NULL AND NEW.confirmed_at IS NOT NULL)
  EXECUTE FUNCTION handle_new_user();

-- 启用RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE skills ENABLE ROW LEVEL SECURITY;
ALTER TABLE skill_price_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE post_likes ENABLE ROW LEVEL SECURITY;
ALTER TABLE post_replies ENABLE ROW LEVEL SECURITY;
ALTER TABLE exchanges ENABLE ROW LEVEL SECURITY;
ALTER TABLE group_buys ENABLE ROW LEVEL SECURITY;
ALTER TABLE group_buy_participants ENABLE ROW LEVEL SECURITY;
ALTER TABLE ratings ENABLE ROW LEVEL SECURITY;
ALTER TABLE favorites ENABLE ROW LEVEL SECURITY;

-- Profiles 策略
CREATE POLICY "用户可以查看所有profiles" ON profiles FOR SELECT TO authenticated USING (true);
CREATE POLICY "用户可以更新自己的profile" ON profiles FOR UPDATE TO authenticated USING (auth.uid() = id);

-- Skills 策略
CREATE POLICY "所有人可以查看已发布的技能" ON skills FOR SELECT TO authenticated USING (status = 'active');
CREATE POLICY "用户可以创建自己的技能" ON skills FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "用户可以更新自己的技能" ON skills FOR UPDATE TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "用户可以删除自己的技能" ON skills FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- Skill price history 策略
CREATE POLICY "所有人可以查看价格历史" ON skill_price_history FOR SELECT TO authenticated USING (true);
CREATE POLICY "系统可以插入价格历史" ON skill_price_history FOR INSERT TO authenticated WITH CHECK (true);

-- Posts 策略
CREATE POLICY "所有人可以查看帖子" ON posts FOR SELECT TO authenticated USING (true);
CREATE POLICY "用户可以创建帖子" ON posts FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "用户可以更新自己的帖子" ON posts FOR UPDATE TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "用户可以删除自己的帖子" ON posts FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- Post likes 策略
CREATE POLICY "所有人可以查看点赞" ON post_likes FOR SELECT TO authenticated USING (true);
CREATE POLICY "用户可以点赞" ON post_likes FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "用户可以取消点赞" ON post_likes FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- Post replies 策略
CREATE POLICY "所有人可以查看回复" ON post_replies FOR SELECT TO authenticated USING (true);
CREATE POLICY "用户可以回复" ON post_replies FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "用户可以删除自己的回复" ON post_replies FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- Exchanges 策略
CREATE POLICY "用户可以查看自己相关的交换" ON exchanges FOR SELECT TO authenticated 
  USING (auth.uid() = initiator_id OR auth.uid() = receiver_id);
CREATE POLICY "用户可以创建交换" ON exchanges FOR INSERT TO authenticated WITH CHECK (auth.uid() = initiator_id);
CREATE POLICY "用户可以更新自己相关的交换" ON exchanges FOR UPDATE TO authenticated 
  USING (auth.uid() = initiator_id OR auth.uid() = receiver_id);

-- Group buys 策略
CREATE POLICY "所有人可以查看团购" ON group_buys FOR SELECT TO authenticated USING (true);
CREATE POLICY "用户可以创建团购" ON group_buys FOR INSERT TO authenticated WITH CHECK (auth.uid() = initiator_id);
CREATE POLICY "用户可以更新自己的团购" ON group_buys FOR UPDATE TO authenticated USING (auth.uid() = initiator_id);

-- Group buy participants 策略
CREATE POLICY "所有人可以查看团购参与者" ON group_buy_participants FOR SELECT TO authenticated USING (true);
CREATE POLICY "用户可以参与团购" ON group_buy_participants FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "用户可以取消参团" ON group_buy_participants FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- Ratings 策略
CREATE POLICY "所有人可以查看评价" ON ratings FOR SELECT TO authenticated USING (true);
CREATE POLICY "用户可以创建评价" ON ratings FOR INSERT TO authenticated WITH CHECK (auth.uid() = rater_id);

-- Favorites 策略
CREATE POLICY "用户可以查看自己的收藏" ON favorites FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "用户可以添加收藏" ON favorites FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "用户可以取消收藏" ON favorites FOR DELETE TO authenticated USING (auth.uid() = user_id);