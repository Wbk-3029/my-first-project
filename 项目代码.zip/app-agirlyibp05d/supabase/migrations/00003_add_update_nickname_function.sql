-- 创建更新昵称的函数
CREATE OR REPLACE FUNCTION update_profile_nickname(user_id uuid, new_nickname text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE profiles SET nickname = new_nickname WHERE id = user_id;
END;
$$;