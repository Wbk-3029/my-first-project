import { useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { sendFriendRequest } from '@/db/api';
import { UserPlus } from 'lucide-react';
import { toast } from 'sonner';

interface AddFriendDialogProps {
  friendId: string;
  friendName: string;
  trigger?: React.ReactNode;
}

export function AddFriendDialog({ friendId, friendName, trigger }: AddFriendDialogProps) {
  const [open, setOpen] = useState(false);
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    try {
      setLoading(true);
      await sendFriendRequest(friendId, message || undefined);
      toast.success('好友申请已发送');
      setOpen(false);
      setMessage('');
    } catch (error: any) {
      console.error('发送好友申请失败:', error);
      toast.error(error.message || '发送好友申请失败');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger || (
          <Button variant="outline" className="gap-2">
            <UserPlus className="h-4 w-4" />
            添加好友
          </Button>
        )}
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>添加好友</DialogTitle>
          <DialogDescription>向 {friendName} 发送好友申请</DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="message">申请消息（可选）</Label>
            <Textarea
              id="message"
              placeholder="我想和你成为好友..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              rows={3}
              maxLength={200}
            />
            <div className="text-xs text-muted-foreground text-right">
              {message.length}/200
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)} disabled={loading}>
            取消
          </Button>
          <Button onClick={handleSubmit} disabled={loading}>
            {loading ? '发送中...' : '发送申请'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
