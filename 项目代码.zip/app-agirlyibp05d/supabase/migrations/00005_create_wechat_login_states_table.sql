-- 创建微信登录状态表
CREATE TABLE IF NOT EXISTS wechat_login_states (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  state text NOT NULL UNIQUE,
  status text NOT NULL DEFAULT 'pending', -- pending, success, failed
  user_id uuid REFERENCES profiles(id),
  access_token text,
  expires_at timestamptz NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- 创建索引
CREATE INDEX idx_wechat_login_states_state ON wechat_login_states(state);
CREATE INDEX idx_wechat_login_states_status ON wechat_login_states(status);
CREATE INDEX idx_wechat_login_states_expires_at ON wechat_login_states(expires_at);

-- 添加wechat_id字段到profiles表
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS wechat_id text UNIQUE;
CREATE INDEX IF NOT EXISTS idx_profiles_wechat_id ON profiles(wechat_id);

-- 定期清理过期的登录状态(可选,通过pg_cron实现)
COMMENT ON TABLE wechat_login_states IS '微信扫码登录状态表,存储登录会话信息';