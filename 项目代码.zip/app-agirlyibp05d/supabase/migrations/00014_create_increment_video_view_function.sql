-- 创建增加视频观看数的函数
CREATE OR REPLACE FUNCTION increment_video_view(video_id UUID)
RETURNS VOID AS $$
BEGIN
  UPDATE hot_videos
  SET view_count = view_count + 1
  WHERE id = video_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;