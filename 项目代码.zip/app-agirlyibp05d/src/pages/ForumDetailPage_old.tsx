import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { MainLayout } from '@/components/layouts/MainLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { UserProfileDialog } from '@/components/user/UserProfileDialog';
import { Textarea } from '@/components/ui/textarea';
import { Separator } from '@/components/ui/separator';
import { Skeleton } from '@/components/ui/skeleton';
import {
  getPostById,
  getPostReplies,
  createPostReply,
  togglePostLike,
  checkPostLiked,
  toggleFavorite,
  checkFavorited,
} from '@/db/api';
import type { Post, PostReply } from '@/types';
import { Heart, MessageCircle, Star, ArrowLeft } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { zhCN } from 'date-fns/locale';
import { toast } from 'sonner';

export default function ForumDetailPage() {
  const { id } = useParams<{ id: string }>();
  const [post, setPost] = useState<Post | null>(null);
  const [replies, setReplies] = useState<PostReply[]>([]);
  const [loading, setLoading] = useState(true);
  const [replyContent, setReplyContent] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [liked, setLiked] = useState(false);
  const [favorited, setFavorited] = useState(false);

  useEffect(() => {
    if (id) {
      loadData();
    }
  }, [id]);

  const loadData = async () => {
    if (!id) return;

    try {
      setLoading(true);
      const [postData, repliesData, likedStatus, favoritedStatus] = await Promise.all([
        getPostById(id),
        getPostReplies(id),
        checkPostLiked(id),
        checkFavorited('post', id),
      ]);

      setPost(postData);
      setReplies(repliesData);
      setLiked(likedStatus);
      setFavorited(favoritedStatus);
    } catch (error) {
      toast.error('加载帖子失败');
    } finally {
      setLoading(false);
    }
  };

  const handleReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!id || !replyContent.trim()) return;

    setSubmitting(true);
    try {
      await createPostReply(id, replyContent);
      toast.success('回复成功');
      setReplyContent('');
      loadData();
    } catch (error) {
      toast.error('回复失败');
    } finally {
      setSubmitting(false);
    }
  };

  const handleLike = async () => {
    if (!id) return;

    try {
      const newLiked = await togglePostLike(id);
      setLiked(newLiked);
      if (post) {
        setPost({
          ...post,
          like_count: post.like_count + (newLiked ? 1 : -1),
        });
      }
    } catch (error) {
      toast.error('操作失败');
    }
  };

  const handleFavorite = async () => {
    if (!id) return;

    try {
      const newFavorited = await toggleFavorite('post', id);
      setFavorited(newFavorited);
      toast.success(newFavorited ? '收藏成功' : '取消收藏');
    } catch (error) {
      toast.error('操作失败');
    }
  };

  if (loading) {
    return (
      <MainLayout>
        <div className="max-w-4xl mx-auto space-y-6">
          <Skeleton className="h-8 w-32 bg-muted" />
          <Card>
            <CardHeader>
              <Skeleton className="h-8 w-3/4 bg-muted" />
              <Skeleton className="h-4 w-full bg-muted" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-24 w-full bg-muted" />
            </CardContent>
          </Card>
        </div>
      </MainLayout>
    );
  }

  if (!post) {
    return (
      <MainLayout>
        <Card>
          <CardContent className="py-12 text-center text-muted-foreground">
            帖子不存在
          </CardContent>
        </Card>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Back Button */}
        <Button asChild variant="ghost" size="sm" className="gap-2">
          <Link to="/forum">
            <ArrowLeft className="h-4 w-4" />
            返回论坛
          </Link>
        </Button>

        {/* Post Content */}
        <Card>
          <CardHeader className="space-y-4">
            <CardTitle className="text-2xl">{post.title}</CardTitle>

            <div className="flex items-center space-x-4">
              {post.profiles && (
                <>
                  <UserProfileDialog
                    userId={post.user_id}
                    userName={post.profiles.nickname || '未知用户'}
                    userAvatar={post.profiles.avatar_url}
                    userCreditScore={post.profiles.credit_score}
                    trigger={
                      <Avatar className="cursor-pointer hover:ring-2 hover:ring-primary transition-all">
                        <AvatarImage src={post.profiles.avatar_url || undefined} />
                        <AvatarFallback>{post.profiles.nickname?.[0] || '用'}</AvatarFallback>
                      </Avatar>
                    }
                  />
                  <div>
                    <p className="text-sm font-medium">{post.profiles.nickname || '未知用户'}</p>
                    <p className="text-xs text-muted-foreground">
                      {formatDistanceToNow(new Date(post.created_at), {
                        addSuffix: true,
                        locale: zhCN,
                      })}
                    </p>
                  </div>
                </>
              )}
            </div>
          </CardHeader>

          <CardContent className="space-y-6">
            <div className="prose prose-sm max-w-none">
              <p className="whitespace-pre-wrap">{post.content}</p>
            </div>

            {post.images && post.images.length > 0 && (
              <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                {post.images.map((url, index) => (
                  <div key={index} className="aspect-square">
                    <img
                      src={url}
                      alt={`图片 ${index + 1}`}
                      className="w-full h-full object-cover rounded-lg border border-border cursor-pointer hover:opacity-90 transition-opacity"
                      onClick={() => window.open(url, '_blank')}
                    />
                  </div>
                ))}
              </div>
            )}

            {post.exchange_need && (
              <div className="p-4 rounded-lg bg-accent/50 border border-border">
                <p className="text-sm font-medium mb-1">交换需求</p>
                <p className="text-sm text-muted-foreground">{post.exchange_need}</p>
              </div>
            )}

            <Separator />

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <Button
                  variant={liked ? 'default' : 'outline'}
                  size="sm"
                  className="gap-2"
                  onClick={handleLike}
                >
                  <Heart className={`h-4 w-4 ${liked ? 'fill-current' : ''}`} />
                  <span>{post.like_count}</span>
                </Button>

                <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                  <MessageCircle className="h-4 w-4" />
                  <span>{post.reply_count} 回复</span>
                </div>
              </div>

              <Button
                variant={favorited ? 'default' : 'outline'}
                size="sm"
                className="gap-2"
                onClick={handleFavorite}
              >
                <Star className={`h-4 w-4 ${favorited ? 'fill-current' : ''}`} />
                {favorited ? '已收藏' : '收藏'}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Reply Form */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">发表回复</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleReply} className="space-y-4">
              <Textarea
                placeholder="写下你的回复..."
                value={replyContent}
                onChange={(e) => setReplyContent(e.target.value)}
                rows={4}
              />
              <div className="flex justify-end">
                <Button type="submit" disabled={submitting || !replyContent.trim()}>
                  {submitting ? '发送中...' : '发送回复'}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>

        {/* Replies List */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">全部回复 ({replies.length})</CardTitle>
          </CardHeader>
          <CardContent>
            {replies.length > 0 ? (
              <div className="space-y-6">
                {replies.map((reply, index) => (
                  <div key={reply.id}>
                    {index > 0 && <Separator className="my-6" />}
                    <div className="flex space-x-4">
                      {reply.profiles && (
                        <>
                          <UserProfileDialog
                            userId={reply.user_id}
                            userName={reply.profiles.nickname || '未知用户'}
                            userAvatar={reply.profiles.avatar_url}
                            userCreditScore={reply.profiles.credit_score}
                            trigger={
                              <Avatar className="cursor-pointer hover:ring-2 hover:ring-primary transition-all">
                                <AvatarImage src={reply.profiles.avatar_url || undefined} />
                                <AvatarFallback>{reply.profiles.nickname?.[0] || '用'}</AvatarFallback>
                              </Avatar>
                            }
                          />
                          <div className="flex-1 space-y-2">
                            <div className="flex items-center space-x-2">
                              <span className="text-sm font-medium">
                                {reply.profiles.nickname || '未知用户'}
                              </span>
                              <span className="text-xs text-muted-foreground">
                                {formatDistanceToNow(new Date(reply.created_at), {
                                  addSuffix: true,
                                  locale: zhCN,
                                })}
                              </span>
                            </div>
                            <p className="text-sm whitespace-pre-wrap">{reply.content}</p>
                          </div>
                        </>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-center text-muted-foreground py-8">暂无回复</p>
            )}
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}
