-- 添加新手引导相关字段到profiles表
ALTER TABLE profiles
ADD COLUMN IF NOT EXISTS onboarding_completed BOOLEAN DEFAULT FALSE,
ADD COLUMN IF NOT EXISTS skills_want_to_learn TEXT[] DEFAULT '{}',
ADD COLUMN IF NOT EXISTS skills_can_teach TEXT[] DEFAULT '{}',
ADD COLUMN IF NOT EXISTS available_time TEXT;

-- 添加注释
COMMENT ON COLUMN profiles.onboarding_completed IS '是否完成新手引导';
COMMENT ON COLUMN profiles.skills_want_to_learn IS '想学的技能列表';
COMMENT ON COLUMN profiles.skills_can_teach IS '能教的技能列表';
COMMENT ON COLUMN profiles.available_time IS '空闲时间偏好';