import { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { MainLayout } from '@/components/layouts/MainLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import { Skeleton } from '@/components/ui/skeleton';
import { MediaPreview } from '@/components/ui/media-preview';
import { UserProfileDialog } from '@/components/user/UserProfileDialog';
import { AddFriendDialog } from '@/components/friend/AddFriendDialog';
import { ExchangeRequestDialog } from '@/components/exchange/ExchangeRequestDialog';
import {
  getSkillById,
  getSkillPriceHistory,
  getSkillRatings,
  getGroupBuys,
  toggleFavorite,
  checkFavorited,
  checkFriendStatus,
} from '@/db/api';
import type { Skill, SkillPriceHistory, Rating, GroupBuy } from '@/types';
import { SKILL_TYPE_LABELS } from '@/types';
import { Coins, TrendingUp, Star, ArrowLeft, Repeat, Users, Image as ImageIcon, Video, Play, UserPlus, MessageCircle } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { zhCN } from 'date-fns/locale';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';

export default function SkillDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [skill, setSkill] = useState<Skill | null>(null);
  const [priceHistory, setPriceHistory] = useState<SkillPriceHistory[]>([]);
  const [ratings, setRatings] = useState<Rating[]>([]);
  const [groupBuys, setGroupBuys] = useState<GroupBuy[]>([]);
  const [loading, setLoading] = useState(true);
  const [favorited, setFavorited] = useState(false);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewIndex, setPreviewIndex] = useState(0);
  const [friendStatus, setFriendStatus] = useState<'none' | 'pending' | 'friend'>('none');

  useEffect(() => {
    if (id) {
      loadData();
    }
  }, [id]);

  const loadData = async () => {
    if (!id) return;

    try {
      setLoading(true);
      const [skillData, historyData, ratingsData, groupBuysData, favoritedStatus] =
        await Promise.all([
          getSkillById(id),
          getSkillPriceHistory(id),
          getSkillRatings(id),
          getGroupBuys(id),
          checkFavorited('skill', id),
        ]);

      setSkill(skillData);
      setPriceHistory(historyData);
      setRatings(ratingsData);
      setGroupBuys(groupBuysData);
      setFavorited(favoritedStatus);

      // 检查好友状态
      if (skillData && skillData.user_id && user && skillData.user_id !== user.id) {
        const status = await checkFriendStatus(skillData.user_id);
        setFriendStatus(status);
      }
    } catch (error) {
      toast.error('加载技能详情失败');
    } finally {
      setLoading(false);
    }
  };

  const handleFavorite = async () => {
    if (!id) return;

    try {
      const newFavorited = await toggleFavorite('skill', id);
      setFavorited(newFavorited);
      toast.success(newFavorited ? '收藏成功' : '取消收藏');
    } catch (error) {
      toast.error('操作失败');
    }
  };

  const handleDirectExchange = () => {
    if (!user) {
      toast.error('请先登录');
      navigate('/login');
      return;
    }
    navigate(`/exchanges/create?skillId=${id}`);
  };

  const handlePointExchange = () => {
    if (!user) {
      toast.error('请先登录');
      navigate('/login');
      return;
    }
    navigate(`/exchanges/create?skillId=${id}`);
  };

  const handleGroupBuy = () => {
    if (!user) {
      toast.error('请先登录');
      navigate('/login');
      return;
    }
    navigate(`/exchanges/create?skillId=${id}`);
  };

  if (loading) {
    return (
      <MainLayout>
        <div className="max-w-4xl mx-auto space-y-6">
          <Skeleton className="h-8 w-32 bg-muted" />
          <Card>
            <CardHeader>
              <Skeleton className="h-8 w-3/4 bg-muted" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-24 w-full bg-muted" />
            </CardContent>
          </Card>
        </div>
      </MainLayout>
    );
  }

  if (!skill) {
    return (
      <MainLayout>
        <Card>
          <CardContent className="py-12 text-center text-muted-foreground">
            技能不存在
          </CardContent>
        </Card>
      </MainLayout>
    );
  }

  const isOwner = user?.id === skill.user_id;

  return (
    <MainLayout>
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Back Button */}
        <Button asChild variant="ghost" size="sm" className="gap-2">
          <Link to="/skills">
            <ArrowLeft className="h-4 w-4" />
            返回技能广场
          </Link>
        </Button>

        {/* Skill Info */}
        <Card>
          <CardHeader className="space-y-4">
            <div className="flex items-start justify-between">
              <div className="space-y-2">
                <CardTitle className="text-2xl">{skill.name}</CardTitle>
                <Badge variant="secondary">{SKILL_TYPE_LABELS[skill.type]}</Badge>
              </div>
              <div className="text-right">
                <div className="text-3xl font-bold text-secondary">{skill.price}</div>
                <div className="text-sm text-muted-foreground">技易点</div>
              </div>
            </div>

            {skill.profiles && (
              <div className="flex items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <UserProfileDialog
                    userId={skill.user_id}
                    userName={skill.profiles.nickname || '未知用户'}
                    userAvatar={skill.profiles.avatar_url}
                    userCreditScore={skill.profiles.credit_score}
                    trigger={
                      <Avatar className="h-12 w-12 cursor-pointer hover:ring-2 hover:ring-primary transition-all">
                        <AvatarImage src={skill.profiles.avatar_url || undefined} />
                        <AvatarFallback>{skill.profiles.nickname?.[0] || '用'}</AvatarFallback>
                      </Avatar>
                    }
                  />
                  <div>
                    <p className="text-sm font-medium">{skill.profiles.nickname || '未知用户'}</p>
                    <div className="flex items-center space-x-2 text-xs text-muted-foreground">
                      <span>信用分 {skill.profiles.credit_score}</span>
                      <span>·</span>
                      <span>技易点 {skill.profiles.points}</span>
                    </div>
                  </div>
                </div>

                {/* 好友操作按钮 */}
                {user && skill.user_id !== user.id && (
                  <div className="flex items-center gap-2">
                    {friendStatus === 'friend' ? (
                      <Button size="sm" variant="outline" className="gap-2" asChild>
                        <Link to={`/messages/${skill.user_id}`}>
                          <MessageCircle className="h-4 w-4" />
                          发消息
                        </Link>
                      </Button>
                    ) : friendStatus === 'pending' ? (
                      <Button onClick={() => {}} size="sm" variant="outline" disabled>
                        已发送申请
                      </Button>
                    ) : (
                      <AddFriendDialog
                        friendId={skill.user_id}
                        friendName={skill.profiles.nickname || '未知用户'}
                        trigger={
                          <button className="inline-flex items-center justify-center gap-2 rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 border border-input bg-background hover:bg-accent hover:text-accent-foreground h-9 px-3">
                            <UserPlus className="h-4 w-4" />
                            添加好友
                          </button>
                        }
                      />
                    )}
                  </div>
                )}
              </div>
            )}
          </CardHeader>

          <CardContent className="space-y-6">
            {/* 媒体展示 */}
            {skill.media && skill.media.length > 0 && (
              <div>
                <h3 className="text-sm font-medium mb-3">技能展示</h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {skill.media.map((mediaUrl, index) => {
                    const isVideo = mediaUrl.match(/\.(mp4|webm|ogg)$/i);
                    return (
                      <button
                        key={index}
                        onClick={() => {
                          setPreviewIndex(index);
                          setPreviewOpen(true);
                        }}
                        className="relative aspect-video rounded-lg overflow-hidden bg-muted hover:opacity-90 transition-opacity group"
                      >
                        {isVideo ? (
                          <>
                            <video
                              src={mediaUrl}
                              className="w-full h-full object-cover"
                              muted
                            />
                            <div className="absolute inset-0 bg-black/30 flex items-center justify-center group-hover:bg-black/40 transition-colors">
                              <div className="w-10 h-10 rounded-full bg-white/90 flex items-center justify-center">
                                <Play className="h-5 w-5 text-primary ml-0.5" />
                              </div>
                            </div>
                          </>
                        ) : (
                          <img
                            src={mediaUrl}
                            alt={`技能展示 ${index + 1}`}
                            className="w-full h-full object-cover"
                          />
                        )}
                        <div className="absolute top-2 right-2 px-2 py-0.5 bg-black/60 text-white text-xs rounded">
                          {isVideo ? <Video className="h-3 w-3" /> : <ImageIcon className="h-3 w-3" />}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            <div>
              <h3 className="text-sm font-medium mb-2">技能描述</h3>
              <p className="text-sm text-muted-foreground whitespace-pre-wrap">
                {skill.description || '暂无描述'}
              </p>
            </div>

            {skill.required_skills && (
              <div>
                <h3 className="text-sm font-medium mb-2">所需技能(直接交换)</h3>
                <p className="text-sm text-muted-foreground whitespace-pre-wrap">
                  {skill.required_skills}
                </p>
              </div>
            )}

            <div className="flex items-center space-x-6 text-sm text-muted-foreground">
              <div className="flex items-center space-x-1">
                <TrendingUp className="h-4 w-4" />
                <span>已交换 {skill.exchange_count} 次</span>
              </div>
            </div>

            <Separator />

            {!isOwner && skill && (
              <div className="flex flex-wrap gap-3">
                <ExchangeRequestDialog
                  skillId={skill.id}
                  skillName={skill.name}
                  skillPrice={skill.price}
                  publisherId={skill.user_id}
                  onSuccess={() => {
                    toast.success('交换申请已发送，请等待对方确认');
                  }}
                />
                <Button
                  onClick={handleFavorite}
                  variant={favorited ? 'default' : 'outline'}
                  className="gap-2 min-h-[44px]"
                >
                  <Star className={`h-4 w-4 ${favorited ? 'fill-current' : ''}`} />
                  {favorited ? '已收藏' : '收藏'}
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Active Group Buys */}
        {groupBuys.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">进行中的团购</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {groupBuys.map((gb) => (
                  <div
                    key={gb.id}
                    className="flex items-center justify-between p-4 rounded-lg border border-border"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center space-x-2">
                        <span className="text-sm font-medium">团购价: {gb.group_price} 技易点</span>
                        <Badge variant="outline">原价 {gb.original_price}</Badge>
                      </div>
                      <div className="text-xs text-muted-foreground">
                        已有 {gb.participant_count} 人参团 · 还需{' '}
                        {Math.max(0, 3 - gb.participant_count)} 人成团
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {formatDistanceToNow(new Date(gb.expires_at), {
                          addSuffix: true,
                          locale: zhCN,
                        })}
                        到期
                      </div>
                    </div>
                    <Button asChild size="sm">
                      <Link to={`/exchanges/group?groupBuyId=${gb.id}`}>参与团购</Link>
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Price History */}
        {priceHistory.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">价格调整记录</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {priceHistory.map((history) => (
                  <div
                    key={history.id}
                    className="flex items-center justify-between text-sm p-3 rounded-lg bg-muted/50"
                  >
                    <div className="space-y-1">
                      <div>
                        <span className="line-through text-muted-foreground">
                          {history.old_price}
                        </span>
                        <span className="mx-2">→</span>
                        <span className="font-medium text-secondary">{history.new_price}</span>
                        <span className="ml-1 text-muted-foreground">技易点</span>
                      </div>
                      {history.reason && (
                        <div className="text-xs text-muted-foreground">原因: {history.reason}</div>
                      )}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {formatDistanceToNow(new Date(history.created_at), {
                        addSuffix: true,
                        locale: zhCN,
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Ratings */}
        {ratings.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">用户评价 ({ratings.length})</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {ratings.map((rating) => (
                  <div key={rating.id} className="space-y-2">
                    <div className="flex items-center space-x-2">
                      {rating.rater && (
                        <>
                          <Avatar className="h-8 w-8">
                            <AvatarImage src={rating.rater.avatar_url || undefined} />
                            <AvatarFallback className="text-xs">
                              {rating.rater.nickname?.[0] || '用'}
                            </AvatarFallback>
                          </Avatar>
                          <span className="text-sm font-medium">
                            {rating.rater.nickname || '未知用户'}
                          </span>
                        </>
                      )}
                      <Badge variant={rating.rating_type === 'positive' ? 'default' : 'destructive'}>
                        {rating.rating_type === 'positive' ? '好评' : '差评'}
                      </Badge>
                      <span className="text-xs text-muted-foreground">
                        {formatDistanceToNow(new Date(rating.created_at), {
                          addSuffix: true,
                          locale: zhCN,
                        })}
                      </span>
                    </div>
                    {rating.comment && (
                      <p className="text-sm text-muted-foreground pl-10">{rating.comment}</p>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* 媒体预览 */}
      {skill && skill.media && skill.media.length > 0 && (
        <MediaPreview
          media={skill.media}
          open={previewOpen}
          onOpenChange={setPreviewOpen}
          initialIndex={previewIndex}
        />
      )}
    </MainLayout>
  );
}
