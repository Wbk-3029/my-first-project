import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { EvidenceUpload } from '@/components/violation/EvidenceUpload';
import { submitAppeal } from '@/db/api';
import { toast } from 'sonner';
import { Scale } from 'lucide-react';

interface EvidenceFile {
  name: string;
  url: string;
  type: string;
  size: number;
}

interface AppealDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  violationRecordId: string;
  violationType: string;
  violationDescription: string;
  creditDeducted: number;
  onSuccess?: () => void;
}

const VIOLATION_TYPE_LABELS: Record<string, string> = {
  no_show: '爽约',
  false_info: '虚假信息',
  malicious_review: '恶意评价',
  spam: '垃圾信息',
  harassment: '骚扰行为',
  other: '其他违规',
};

export function AppealDialog({
  open,
  onOpenChange,
  violationRecordId,
  violationType,
  violationDescription,
  creditDeducted,
  onSuccess,
}: AppealDialogProps) {
  const [reason, setReason] = useState('');
  const [evidenceFiles, setEvidenceFiles] = useState<EvidenceFile[]>([]);
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async () => {
    if (!reason.trim()) {
      toast.error('请填写申诉理由');
      return;
    }

    if (reason.trim().length < 20) {
      toast.error('申诉理由至少20字');
      return;
    }

    try {
      setSubmitting(true);
      
      // 提取文件URL
      const evidenceUrls = evidenceFiles.map(file => file.url);
      
      const result = await submitAppeal({
        violationRecordId,
        reason: reason.trim(),
        evidence: evidenceUrls,
      });

      if (result.success) {
        toast.success(result.message);
        onOpenChange(false);
        setReason('');
        setEvidenceFiles([]);
        onSuccess?.();
      } else {
        toast.error(result.message);
      }
    } catch (error) {
      console.error('提交申诉失败:', error);
      toast.error('提交申诉失败');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Scale className="h-5 w-5 text-primary" />
            提交申诉
          </DialogTitle>
          <DialogDescription>
            对违规处罚不服？请提交申诉，我们会重新审核
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* 违规信息 */}
          <div className="bg-muted p-4 rounded-lg space-y-2 text-sm">
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">违规类型：</span>
              <span className="font-medium">
                {VIOLATION_TYPE_LABELS[violationType]}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">扣除信用分：</span>
              <span className="font-medium text-destructive">
                -{creditDeducted}分
              </span>
            </div>
            <div className="pt-2 border-t">
              <p className="text-muted-foreground mb-1">违规描述：</p>
              <p className="text-foreground">{violationDescription}</p>
            </div>
          </div>

          {/* 申诉理由 */}
          <div className="space-y-2">
            <Label>申诉理由 *</Label>
            <Textarea
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="请详细说明您认为处罚不当的理由，包括事实依据、证据说明等（至少20字）"
              className="min-h-[150px] resize-none"
              maxLength={1000}
            />
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground">
                {reason.length < 20 ? `还需${20 - reason.length}字` : ''}
              </span>
              <span className="text-muted-foreground">
                {reason.length}/1000
              </span>
            </div>
          </div>

          {/* 证据上传 */}
          <div className="space-y-2">
            <Label>上传证据（可选）</Label>
            <EvidenceUpload
              files={evidenceFiles}
              onChange={setEvidenceFiles}
            />
          </div>

          {/* 申诉须知 */}
          <div className="bg-orange-50 dark:bg-orange-950/20 border border-orange-200 dark:border-orange-800 p-3 rounded-lg text-sm">
            <p className="font-medium text-orange-900 dark:text-orange-100 mb-2">
              申诉须知：
            </p>
            <ul className="space-y-1 text-xs text-orange-800 dark:text-orange-200">
              <li>• 每条违规记录只能申诉一次</li>
              <li>• 申诉时限：违规处理后7天内</li>
              <li>• 我们会在3个工作日内处理您的申诉</li>
              <li>• 申诉成功将恢复扣除的信用分</li>
              <li>• 虚假申诉将受到更严厉的处罚</li>
            </ul>
          </div>
        </div>

        <div className="flex gap-3 justify-end">
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            disabled={submitting}
          >
            取消
          </Button>
          <Button onClick={handleSubmit} disabled={submitting}>
            {submitting ? '提交中...' : '提交申诉'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
