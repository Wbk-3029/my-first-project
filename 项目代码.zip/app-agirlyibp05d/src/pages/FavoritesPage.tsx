import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { MainLayout } from '@/components/layouts/MainLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { SkillCard } from '@/components/skill/SkillCard';
import { PostCard } from '@/components/forum/PostCard';
import { useAuth } from '@/contexts/AuthContext';
import { getUserFavorites, getSkillById, getPostById } from '@/db/api';
import type { Favorite, Skill, Post } from '@/types';
import { ArrowLeft } from 'lucide-react';
import { toast } from 'sonner';

export default function FavoritesPage() {
  const { profile } = useAuth();
  const [favorites, setFavorites] = useState<Favorite[]>([]);
  const [skills, setSkills] = useState<Skill[]>([]);
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (profile) {
      loadFavorites();
    }
  }, [profile]);

  const loadFavorites = async () => {
    if (!profile) return;

    try {
      setLoading(true);
      const data = await getUserFavorites(profile.id);
      setFavorites(data);

      // 加载技能和帖子详情
      const skillFavorites = data.filter((f) => f.item_type === 'skill');
      const postFavorites = data.filter((f) => f.item_type === 'post');

      const skillsData = await Promise.all(
        skillFavorites.map((f) => getSkillById(f.item_id))
      );
      const postsData = await Promise.all(
        postFavorites.map((f) => getPostById(f.item_id))
      );

      setSkills(skillsData.filter((s) => s !== null) as Skill[]);
      setPosts(postsData.filter((p) => p !== null) as Post[]);
    } catch (error) {
      toast.error('加载收藏失败');
    } finally {
      setLoading(false);
    }
  };

  if (!profile) {
    return (
      <MainLayout>
        <Card>
          <CardContent className="py-12 text-center text-muted-foreground">
            请先登录
          </CardContent>
        </Card>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div>
          <Button asChild variant="ghost" size="sm" className="gap-2 mb-2">
            <Link to="/profile">
              <ArrowLeft className="h-4 w-4" />
              返回个人中心
            </Link>
          </Button>
          <h1 className="text-3xl font-bold">我的收藏</h1>
          <p className="text-muted-foreground mt-1">查看收藏的技能和帖子</p>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="skills" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="skills">技能 ({skills.length})</TabsTrigger>
            <TabsTrigger value="posts">帖子 ({posts.length})</TabsTrigger>
          </TabsList>

          <TabsContent value="skills" className="mt-6">
            {loading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {Array.from({ length: 4 }).map((_, i) => (
                  <Card key={i}>
                    <CardContent className="p-6">
                      <Skeleton className="h-6 w-3/4 mb-2 bg-muted" />
                      <Skeleton className="h-4 w-full bg-muted" />
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : skills.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {skills.map((skill) => (
                  <SkillCard key={skill.id} skill={skill} />
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="py-12 text-center text-muted-foreground">
                  还没有收藏技能
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="posts" className="mt-6">
            {loading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {Array.from({ length: 4 }).map((_, i) => (
                  <Card key={i}>
                    <CardContent className="p-6">
                      <Skeleton className="h-6 w-3/4 mb-2 bg-muted" />
                      <Skeleton className="h-4 w-full bg-muted" />
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : posts.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {posts.map((post) => (
                  <PostCard key={post.id} post={post} />
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="py-12 text-center text-muted-foreground">
                  还没有收藏帖子
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  );
}
