-- 为ratings表添加多维度评分字段
ALTER TABLE ratings 
ADD COLUMN IF NOT EXISTS skill_rating int CHECK (skill_rating >= 1 AND skill_rating <= 5),
ADD COLUMN IF NOT EXISTS attitude_rating int CHECK (attitude_rating >= 1 AND attitude_rating <= 5),
ADD COLUMN IF NOT EXISTS punctuality_rating int CHECK (punctuality_rating >= 1 AND punctuality_rating <= 5),
ADD COLUMN IF NOT EXISTS average_rating numeric GENERATED ALWAYS AS ((skill_rating + attitude_rating + punctuality_rating) / 3.0) STORED;

-- 添加注释
COMMENT ON COLUMN ratings.skill_rating IS '技能水平评分（1-5星）';
COMMENT ON COLUMN ratings.attitude_rating IS '教学态度评分（1-5星）';
COMMENT ON COLUMN ratings.punctuality_rating IS '准时性评分（1-5星）';
COMMENT ON COLUMN ratings.average_rating IS '平均评分（自动计算）';

-- 创建信用分变化记录表
CREATE TABLE IF NOT EXISTS credit_score_changes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  change_amount numeric NOT NULL,
  reason text NOT NULL,
  related_id uuid,
  old_score int NOT NULL,
  new_score int NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- 创建索引
CREATE INDEX IF NOT EXISTS idx_credit_score_changes_user ON credit_score_changes(user_id);
CREATE INDEX IF NOT EXISTS idx_credit_score_changes_created ON credit_score_changes(created_at DESC);

-- 添加注释
COMMENT ON TABLE credit_score_changes IS '信用分变化记录表';
COMMENT ON COLUMN credit_score_changes.change_amount IS '变化金额（正数为增加，负数为减少）';
COMMENT ON COLUMN credit_score_changes.reason IS '变化原因';
COMMENT ON COLUMN credit_score_changes.related_id IS '关联ID（如评价ID、交换ID）';
COMMENT ON COLUMN credit_score_changes.old_score IS '变化前信用分';
COMMENT ON COLUMN credit_score_changes.new_score IS '变化后信用分';

-- RLS策略
ALTER TABLE credit_score_changes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "用户可以查看自己的信用分变化记录"
  ON credit_score_changes FOR SELECT
  USING (auth.uid() = user_id);

-- 创建RPC函数：提交评价
CREATE OR REPLACE FUNCTION submit_rating(
  p_exchange_id uuid,
  p_rated_id uuid,
  p_skill_rating int,
  p_attitude_rating int,
  p_punctuality_rating int,
  p_comment text DEFAULT NULL
) RETURNS json AS $$
DECLARE
  v_exchange record;
  v_rater_id uuid;
  v_rating_id uuid;
  v_average_rating numeric;
  v_credit_change numeric;
  v_old_credit int;
  v_new_credit int;
  v_other_rating record;
  v_result json;
BEGIN
  v_rater_id := auth.uid();

  -- 检查评分范围
  IF p_skill_rating < 1 OR p_skill_rating > 5 OR
     p_attitude_rating < 1 OR p_attitude_rating > 5 OR
     p_punctuality_rating < 1 OR p_punctuality_rating > 5 THEN
    RAISE EXCEPTION '评分必须在1-5之间';
  END IF;

  -- 获取交换信息
  SELECT * INTO v_exchange
  FROM exchanges
  WHERE id = p_exchange_id
    AND (initiator_id = v_rater_id OR receiver_id = v_rater_id)
    AND status = 'completed';

  IF v_exchange IS NULL THEN
    RAISE EXCEPTION '交换不存在或无权评价';
  END IF;

  -- 检查是否已评价
  IF EXISTS (
    SELECT 1 FROM ratings
    WHERE exchange_id = p_exchange_id AND rater_id = v_rater_id
  ) THEN
    RAISE EXCEPTION '你已经评价过此次交换';
  END IF;

  -- 计算平均评分
  v_average_rating := (p_skill_rating + p_attitude_rating + p_punctuality_rating) / 3.0;

  -- 计算信用分变化（好评+0.5，中评0，差评-1）
  IF v_average_rating >= 4.0 THEN
    v_credit_change := 0.5;
  ELSIF v_average_rating >= 3.0 THEN
    v_credit_change := 0;
  ELSE
    v_credit_change := -1;
  END IF;

  -- 获取当前信用分
  SELECT credit_score INTO v_old_credit
  FROM profiles
  WHERE id = p_rated_id;

  -- 计算新信用分（限制在0-100之间）
  v_new_credit := GREATEST(0, LEAST(100, v_old_credit + v_credit_change));

  -- 更新信用分
  UPDATE profiles
  SET credit_score = v_new_credit,
      updated_at = now()
  WHERE id = p_rated_id;

  -- 记录信用分变化
  INSERT INTO credit_score_changes (
    user_id,
    change_amount,
    reason,
    related_id,
    old_score,
    new_score
  ) VALUES (
    p_rated_id,
    v_credit_change,
    CASE
      WHEN v_average_rating >= 4.0 THEN '获得好评'
      WHEN v_average_rating >= 3.0 THEN '获得中评'
      ELSE '获得差评'
    END,
    p_exchange_id,
    v_old_credit,
    v_new_credit
  );

  -- 创建评价记录
  INSERT INTO ratings (
    exchange_id,
    rater_id,
    rated_id,
    rating_type,
    skill_rating,
    attitude_rating,
    punctuality_rating,
    comment
  ) VALUES (
    p_exchange_id,
    v_rater_id,
    p_rated_id,
    CASE WHEN v_average_rating >= 4.0 THEN 'positive'::rating_type ELSE 'negative'::rating_type END,
    p_skill_rating,
    p_attitude_rating,
    p_punctuality_rating,
    p_comment
  ) RETURNING id INTO v_rating_id;

  -- 检查对方是否已评价
  SELECT * INTO v_other_rating
  FROM ratings
  WHERE exchange_id = p_exchange_id
    AND rater_id = p_rated_id
    AND rated_id = v_rater_id;

  -- 如果双方都已评价，处理积分结算
  IF v_other_rating.id IS NOT NULL THEN
    -- 如果是积分交换，教学方（receiver）获得积分
    IF v_exchange.type = 'point' AND v_exchange.points_amount IS NOT NULL THEN
      -- 计算信用系数（信用分/100）
      DECLARE
        v_receiver_credit numeric;
        v_credit_coefficient numeric;
        v_final_points int;
      BEGIN
        SELECT credit_score INTO v_receiver_credit
        FROM profiles
        WHERE id = v_exchange.receiver_id;

        v_credit_coefficient := v_receiver_credit / 100.0;
        
        -- 计算最终积分（基础积分 × 信用系数）
        v_final_points := ROUND(v_exchange.points_amount * v_credit_coefficient);

        -- 教学方获得积分（已在handle_exchange_request中处理，这里不再重复）
        -- 这里可以添加额外的奖励逻辑
      END;
    END IF;
  END IF;

  SELECT json_build_object(
    'success', true,
    'rating_id', v_rating_id,
    'credit_change', v_credit_change,
    'new_credit', v_new_credit,
    'message', '评价提交成功'
  ) INTO v_result;

  RETURN v_result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 创建RPC函数：检查是否需要评价
CREATE OR REPLACE FUNCTION check_pending_ratings()
RETURNS json AS $$
DECLARE
  v_user_id uuid;
  v_pending_count int;
  v_result json;
BEGIN
  v_user_id := auth.uid();

  -- 统计需要评价的交换数量
  SELECT COUNT(*) INTO v_pending_count
  FROM exchanges e
  WHERE (e.initiator_id = v_user_id OR e.receiver_id = v_user_id)
    AND e.status = 'completed'
    AND NOT EXISTS (
      SELECT 1 FROM ratings r
      WHERE r.exchange_id = e.id AND r.rater_id = v_user_id
    );

  SELECT json_build_object(
    'pending_count', v_pending_count
  ) INTO v_result;

  RETURN v_result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 创建RPC函数：获取待评价的交换列表
CREATE OR REPLACE FUNCTION get_pending_rating_exchanges()
RETURNS TABLE (
  exchange_id uuid,
  other_user_id uuid,
  other_user_nickname text,
  other_user_avatar text,
  skill_name text,
  completed_at timestamptz,
  hours_since_completion numeric
) AS $$
BEGIN
  RETURN QUERY
  SELECT
    e.id AS exchange_id,
    CASE
      WHEN e.initiator_id = auth.uid() THEN e.receiver_id
      ELSE e.initiator_id
    END AS other_user_id,
    CASE
      WHEN e.initiator_id = auth.uid() THEN p_receiver.nickname
      ELSE p_initiator.nickname
    END AS other_user_nickname,
    CASE
      WHEN e.initiator_id = auth.uid() THEN p_receiver.avatar_url
      ELSE p_initiator.avatar_url
    END AS other_user_avatar,
    CASE
      WHEN e.initiator_id = auth.uid() THEN s_receiver.name
      ELSE s_initiator.name
    END AS skill_name,
    e.completed_at,
    EXTRACT(EPOCH FROM (now() - e.completed_at)) / 3600 AS hours_since_completion
  FROM exchanges e
  LEFT JOIN profiles p_initiator ON e.initiator_id = p_initiator.id
  LEFT JOIN profiles p_receiver ON e.receiver_id = p_receiver.id
  LEFT JOIN skills s_initiator ON e.initiator_skill_id = s_initiator.id
  LEFT JOIN skills s_receiver ON e.receiver_skill_id = s_receiver.id
  WHERE (e.initiator_id = auth.uid() OR e.receiver_id = auth.uid())
    AND e.status = 'completed'
    AND NOT EXISTS (
      SELECT 1 FROM ratings r
      WHERE r.exchange_id = e.id AND r.rater_id = auth.uid()
    )
  ORDER BY e.completed_at DESC;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
