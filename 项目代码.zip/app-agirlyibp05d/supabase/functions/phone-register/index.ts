import { createClient } from 'jsr:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface RegisterRequest {
  phone: string;
  password: string;
  code: string;
  sessionId: string;
  nickname?: string;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const { phone, password, code, sessionId, nickname } = await req.json() as RegisterRequest;

    // 验证参数
    if (!phone || !password || !code || !sessionId) {
      return new Response(
        JSON.stringify({ success: false, error: '参数不完整' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
      );
    }

    if (!/^1[3-9]\d{9}$/.test(phone)) {
      return new Response(
        JSON.stringify({ success: false, error: '请输入正确的手机号' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
      );
    }

    if (password.length < 6) {
      return new Response(
        JSON.stringify({ success: false, error: '密码长度至少为6位' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
      );
    }

    // 验证短信验证码
    const apiKey = Deno.env.get('INTEGRATIONS_API_KEY');
    const verifyResponse = await fetch(
      'https://app-agirlyibp05d-api-Xa6JZxjyqK0a-gateway.appmiaoda.com/v1/code/verify_message_code',
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Gateway-Authorization': `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          mobile: phone,
          sessionId,
          code,
        }),
      }
    );

    const verifyResult = await verifyResponse.json();

    if (verifyResult.status !== 0) {
      return new Response(
        JSON.stringify({ success: false, error: verifyResult.msg || '验证码错误' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
      );
    }

    // 检查手机号是否已注册
    const { data: existingProfile } = await supabaseClient
      .from('profiles')
      .select('*')
      .eq('phone', phone)
      .maybeSingle();

    if (existingProfile) {
      return new Response(
        JSON.stringify({ success: false, error: '该手机号已注册' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
      );
    }

    // 创建用户(使用手机号@phone.local作为邮箱)
    const userEmail = `${phone}@phone.local`;
    const { data: authData, error: authError } = await supabaseClient.auth.admin.createUser({
      email: userEmail,
      password,
      email_confirm: true,
      user_metadata: {
        phone,
        nickname: nickname || `用户${phone.slice(-4)}`,
      },
    });

    if (authError || !authData.user) {
      return new Response(
        JSON.stringify({ success: false, error: authError?.message || '注册失败' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
      );
    }

    // 更新profile表
    await supabaseClient
      .from('profiles')
      .update({
        phone,
        nickname: nickname || `用户${phone.slice(-4)}`,
      })
      .eq('id', authData.user.id);

    return new Response(
      JSON.stringify({
        success: true,
        message: '注册成功',
        userId: authData.user.id,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error:', error);
    return new Response(
      JSON.stringify({ success: false, error: error.message || '服务器错误' }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
    );
  }
});
