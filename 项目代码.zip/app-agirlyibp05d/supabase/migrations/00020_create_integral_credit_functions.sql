-- 初始化用户积分账户
CREATE OR REPLACE FUNCTION initialize_user_integral()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO user_integral (user_id)
  VALUES (NEW.id)
  ON CONFLICT (user_id) DO NOTHING;
  
  INSERT INTO user_credit (user_id)
  VALUES (NEW.id)
  ON CONFLICT (user_id) DO NOTHING;
  
  INSERT INTO learning_streaks (user_id)
  VALUES (NEW.id)
  ON CONFLICT (user_id) DO NOTHING;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_auth_user_created_integral
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION initialize_user_integral();

-- 获取信用等级
CREATE OR REPLACE FUNCTION get_credit_level(score DECIMAL)
RETURNS TEXT AS $$
BEGIN
  IF score >= 90 THEN
    RETURN 'master';
  ELSIF score >= 80 THEN
    RETURN 'excellent';
  ELSIF score >= 60 THEN
    RETURN 'trusted';
  ELSE
    RETURN 'newbie';
  END IF;
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- 获取信用系数
CREATE OR REPLACE FUNCTION get_credit_coefficient(p_level TEXT)
RETURNS DECIMAL AS $$
BEGIN
  CASE p_level
    WHEN 'master' THEN RETURN 1.2;
    WHEN 'excellent' THEN RETURN 1.1;
    WHEN 'trusted' THEN RETURN 1.0;
    WHEN 'newbie' THEN RETURN 0.9;
    ELSE RETURN 1.0;
  END CASE;
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- 计算信用分
CREATE OR REPLACE FUNCTION calculate_credit_score(p_user_id UUID)
RETURNS DECIMAL AS $$
DECLARE
  v_credit user_credit%ROWTYPE;
  v_completion_rate DECIMAL;
  v_avg_rating DECIMAL;
  v_timeliness_rate DECIMAL;
  v_activity_score DECIMAL;
  v_new_score DECIMAL;
BEGIN
  SELECT * INTO v_credit FROM user_credit WHERE user_id = p_user_id;
  
  IF NOT FOUND THEN
    RETURN 100;
  END IF;
  
  -- 交换完成率（30%）
  IF v_credit.total_exchanges > 0 THEN
    v_completion_rate := (v_credit.completed_exchanges::DECIMAL / v_credit.total_exchanges) * 30;
  ELSE
    v_completion_rate := 30;
  END IF;
  
  -- 平均评价分（40%）- 5星制转换为百分制
  IF v_credit.rating_count > 0 THEN
    v_avg_rating := (v_credit.total_rating / v_credit.rating_count / 5) * 40;
  ELSE
    v_avg_rating := 40;
  END IF;
  
  -- 履约及时率（20%）
  IF v_credit.completed_exchanges > 0 THEN
    v_timeliness_rate := (v_credit.timely_count::DECIMAL / v_credit.completed_exchanges) * 20;
  ELSE
    v_timeliness_rate := 20;
  END IF;
  
  -- 账户活跃度（10%）
  v_activity_score := LEAST(v_credit.activity_score, 10);
  
  -- 计算总分
  v_new_score := v_completion_rate + v_avg_rating + v_timeliness_rate + v_activity_score;
  
  -- 限制在0-100之间
  v_new_score := GREATEST(0, LEAST(100, v_new_score));
  
  RETURN v_new_score;
END;
$$ LANGUAGE plpgsql;

-- 添加积分
CREATE OR REPLACE FUNCTION add_integral(
  p_user_id UUID,
  p_amount DECIMAL,
  p_reason TEXT,
  p_related_id UUID DEFAULT NULL,
  p_expire_days INT DEFAULT 365
)
RETURNS BOOLEAN AS $$
DECLARE
  v_new_balance DECIMAL;
  v_expire_date DATE;
BEGIN
  -- 计算过期日期
  v_expire_date := CURRENT_DATE + p_expire_days;
  
  -- 更新用户积分账户
  UPDATE user_integral
  SET 
    balance = balance + p_amount,
    total_earned = total_earned + p_amount,
    updated_at = now()
  WHERE user_id = p_user_id
  RETURNING balance INTO v_new_balance;
  
  -- 如果用户不存在，创建账户
  IF NOT FOUND THEN
    INSERT INTO user_integral (user_id, balance, total_earned)
    VALUES (p_user_id, p_amount, p_amount)
    RETURNING balance INTO v_new_balance;
  END IF;
  
  -- 记录交易
  INSERT INTO integral_transactions (user_id, type, amount, balance, reason, related_id, expire_date)
  VALUES (p_user_id, 'income', p_amount, v_new_balance, p_reason, p_related_id, v_expire_date);
  
  RETURN TRUE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 扣除积分
CREATE OR REPLACE FUNCTION deduct_integral(
  p_user_id UUID,
  p_amount DECIMAL,
  p_reason TEXT,
  p_related_id UUID DEFAULT NULL
)
RETURNS BOOLEAN AS $$
DECLARE
  v_current_balance DECIMAL;
  v_new_balance DECIMAL;
BEGIN
  -- 获取当前余额
  SELECT balance INTO v_current_balance
  FROM user_integral
  WHERE user_id = p_user_id;
  
  IF NOT FOUND OR v_current_balance < p_amount THEN
    RAISE EXCEPTION '积分余额不足';
  END IF;
  
  -- 更新用户积分账户
  UPDATE user_integral
  SET 
    balance = balance - p_amount,
    total_spent = total_spent + p_amount,
    updated_at = now()
  WHERE user_id = p_user_id
  RETURNING balance INTO v_new_balance;
  
  -- 记录交易
  INSERT INTO integral_transactions (user_id, type, amount, balance, reason, related_id)
  VALUES (p_user_id, 'expense', p_amount, v_new_balance, p_reason, p_related_id);
  
  RETURN TRUE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 更新信用分
CREATE OR REPLACE FUNCTION update_credit_score(
  p_user_id UUID,
  p_change DECIMAL,
  p_reason TEXT,
  p_related_id UUID DEFAULT NULL
)
RETURNS BOOLEAN AS $$
DECLARE
  v_current_score DECIMAL;
  v_new_score DECIMAL;
  v_new_level TEXT;
BEGIN
  -- 获取当前信用分
  SELECT score INTO v_current_score
  FROM user_credit
  WHERE user_id = p_user_id;
  
  IF NOT FOUND THEN
    v_current_score := 100;
    INSERT INTO user_credit (user_id, score)
    VALUES (p_user_id, 100);
  END IF;
  
  -- 计算新信用分
  v_new_score := GREATEST(0, LEAST(100, v_current_score + p_change));
  v_new_level := get_credit_level(v_new_score);
  
  -- 更新信用分
  UPDATE user_credit
  SET 
    score = v_new_score,
    level = v_new_level,
    updated_at = now()
  WHERE user_id = p_user_id;
  
  -- 记录变化
  INSERT INTO credit_logs (user_id, change_amount, new_score, reason, related_id)
  VALUES (p_user_id, p_change, v_new_score, p_reason, p_related_id);
  
  RETURN TRUE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 获取用户可用积分（考虑黑洞机制）
CREATE OR REPLACE FUNCTION get_available_integral(p_user_id UUID)
RETURNS DECIMAL AS $$
DECLARE
  v_balance DECIMAL;
  v_total_earned DECIMAL;
  v_total_spent DECIMAL;
  v_net_income DECIMAL;
  v_excess DECIMAL;
  v_penalty DECIMAL;
  v_available DECIMAL;
BEGIN
  SELECT balance, total_earned, total_spent
  INTO v_balance, v_total_earned, v_total_spent
  FROM user_integral
  WHERE user_id = p_user_id;
  
  IF NOT FOUND THEN
    RETURN 0;
  END IF;
  
  -- 计算净收入
  v_net_income := v_total_earned - v_total_spent;
  
  -- 如果净支出超过净收入的2倍，应用黑洞机制
  IF v_total_spent > v_total_earned * 2 THEN
    v_excess := v_total_spent - v_total_earned * 2;
    v_penalty := v_excess * 0.2; -- 超出部分按0.8折算，即损失20%
    v_available := GREATEST(0, v_balance - v_penalty);
  ELSE
    v_available := v_balance;
  END IF;
  
  RETURN v_available;
END;
$$ LANGUAGE plpgsql;