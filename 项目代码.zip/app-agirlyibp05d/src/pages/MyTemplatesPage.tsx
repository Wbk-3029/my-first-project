import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { MainLayout } from '@/components/layouts/MainLayout';
import { PageHeader } from '@/components/layouts/PageHeader';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  getExchangeTemplates,
  createExchangeTemplate,
  updateExchangeTemplate,
  deleteExchangeTemplate,
} from '@/db/api';
import type { ExchangeTemplate } from '@/types';
import { FileText, Plus, Edit, Trash2, BookOpen, Sparkles, Heart } from 'lucide-react';
import { toast } from 'sonner';

export default function MyTemplatesPage() {
  const navigate = useNavigate();
  const [templates, setTemplates] = useState<ExchangeTemplate[]>([]);
  const [loading, setLoading] = useState(true);
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState<ExchangeTemplate | null>(null);
  const [submitting, setSubmitting] = useState(false);

  // 表单状态
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [category, setCategory] = useState<string>('custom');

  useEffect(() => {
    loadTemplates();
  }, []);

  const loadTemplates = async () => {
    try {
      setLoading(true);
      const data = await getExchangeTemplates(undefined, false, true);
      setTemplates(data);
    } catch (error) {
      console.error('加载模板失败:', error);
      toast.error('加载模板失败');
    } finally {
      setLoading(false);
    }
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!title.trim()) {
      toast.error('请输入模板标题');
      return;
    }

    if (!content.trim()) {
      toast.error('请输入模板内容');
      return;
    }

    try {
      setSubmitting(true);
      const result = await createExchangeTemplate(title.trim(), content.trim(), category);
      toast.success(result.message);
      setCreateDialogOpen(false);
      resetForm();
      loadTemplates();
    } catch (error: any) {
      toast.error(error.message || '创建模板失败');
    } finally {
      setSubmitting(false);
    }
  };

  const handleEdit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!selectedTemplate) return;

    if (!title.trim()) {
      toast.error('请输入模板标题');
      return;
    }

    if (!content.trim()) {
      toast.error('请输入模板内容');
      return;
    }

    try {
      setSubmitting(true);
      const result = await updateExchangeTemplate(
        selectedTemplate.id,
        title.trim(),
        content.trim(),
        category
      );
      toast.success(result.message);
      setEditDialogOpen(false);
      resetForm();
      loadTemplates();
    } catch (error: any) {
      toast.error(error.message || '更新模板失败');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async () => {
    if (!selectedTemplate) return;

    try {
      setSubmitting(true);
      const result = await deleteExchangeTemplate(selectedTemplate.id);
      toast.success(result.message);
      setDeleteDialogOpen(false);
      setSelectedTemplate(null);
      loadTemplates();
    } catch (error: any) {
      toast.error(error.message || '删除模板失败');
    } finally {
      setSubmitting(false);
    }
  };

  const openEditDialog = (template: ExchangeTemplate) => {
    setSelectedTemplate(template);
    setTitle(template.title);
    setContent(template.content);
    setCategory(template.category);
    setEditDialogOpen(true);
  };

  const openDeleteDialog = (template: ExchangeTemplate) => {
    setSelectedTemplate(template);
    setDeleteDialogOpen(true);
  };

  const resetForm = () => {
    setTitle('');
    setContent('');
    setCategory('custom');
    setSelectedTemplate(null);
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'skill_learning':
        return <BookOpen className="h-4 w-4" />;
      case 'exam_tutoring':
        return <Sparkles className="h-4 w-4" />;
      case 'interest_exchange':
        return <Heart className="h-4 w-4" />;
      default:
        return <FileText className="h-4 w-4" />;
    }
  };

  const getCategoryName = (category: string) => {
    switch (category) {
      case 'skill_learning':
        return '技能学习';
      case 'exam_tutoring':
        return '考试辅导';
      case 'interest_exchange':
        return '兴趣交流';
      case 'custom':
        return '自定义';
      default:
        return '其他';
    }
  };

  return (
    <MainLayout>
      <PageHeader title="我的模板" />

      <div className="space-y-4">
        {/* 操作栏 */}
        <div className="flex items-center justify-between">
          <div className="text-sm text-muted-foreground">
            共 {templates.length} 个模板
          </div>
          <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                创建模板
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>创建交换模板</DialogTitle>
                <DialogDescription>
                  创建自己的交换模板，方便下次快速填充
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleCreate} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="create-title">模板标题</Label>
                  <Input
                    id="create-title"
                    placeholder="例如：PS入门交换英语口语"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="create-category">模板分类</Label>
                  <Select value={category} onValueChange={setCategory}>
                    <SelectTrigger id="create-category">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="skill_learning">技能学习</SelectItem>
                      <SelectItem value="exam_tutoring">考试辅导</SelectItem>
                      <SelectItem value="interest_exchange">兴趣交流</SelectItem>
                      <SelectItem value="custom">自定义</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="create-content">模板内容</Label>
                  <Textarea
                    id="create-content"
                    placeholder={`输入模板内容，可包括：\n- 交换内容（双方提供的技能）\n- 双方义务\n- 时间安排\n- 违约处理\n- 其他约定`}
                    value={content}
                    onChange={(e) => setContent(e.target.value)}
                    className="min-h-[300px] resize-none font-mono text-sm"
                  />
                </div>

                <div className="flex gap-2 pt-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setCreateDialogOpen(false);
                      resetForm();
                    }}
                    className="flex-1"
                  >
                    取消
                  </Button>
                  <Button type="submit" disabled={submitting} className="flex-1">
                    {submitting ? '创建中...' : '创建模板'}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* 模板列表 */}
        {loading ? (
          // 骨架屏
          <div className="space-y-3">
            {Array.from({ length: 3 }).map((_, i) => (
              <Card key={i}>
                <CardContent className="p-4">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <Skeleton className="h-5 w-48 bg-muted" />
                      <Skeleton className="h-5 w-20 bg-muted" />
                    </div>
                    <Skeleton className="h-20 w-full bg-muted" />
                    <div className="flex items-center justify-between">
                      <Skeleton className="h-4 w-32 bg-muted" />
                      <div className="flex gap-2">
                        <Skeleton className="h-9 w-20 bg-muted" />
                        <Skeleton className="h-9 w-20 bg-muted" />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : templates.length === 0 ? (
          // 空状态
          <Card>
            <CardContent className="p-12 text-center">
              <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <p className="text-muted-foreground mb-4">暂无模板</p>
              <Button onClick={() => setCreateDialogOpen(true)} className="gap-2">
                <Plus className="h-4 w-4" />
                创建第一个模板
              </Button>
            </CardContent>
          </Card>
        ) : (
          // 模板列表
          <div className="space-y-3">
            {templates.map((template) => (
              <Card key={template.id}>
                <CardContent className="p-4">
                  <div className="space-y-3">
                    {/* 标题和标签 */}
                    <div className="flex items-start justify-between gap-2">
                      <h3 className="text-base font-semibold flex-1">{template.title}</h3>
                      <Badge variant="outline" className="gap-1 shrink-0">
                        {getCategoryIcon(template.category)}
                        {getCategoryName(template.category)}
                      </Badge>
                    </div>

                    {/* 内容预览 */}
                    <div className="text-sm text-muted-foreground line-clamp-3 bg-muted/50 p-3 rounded-md">
                      {template.content.substring(0, 150)}...
                    </div>

                    {/* 底部信息和操作 */}
                    <div className="flex items-center justify-between">
                      <div className="text-xs text-muted-foreground">
                        已使用 {template.usage_count} 次
                      </div>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          className="gap-1"
                          onClick={() => openEditDialog(template)}
                        >
                          <Edit className="h-3 w-3" />
                          编辑
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="gap-1 text-destructive hover:text-destructive"
                          onClick={() => openDeleteDialog(template)}
                        >
                          <Trash2 className="h-3 w-3" />
                          删除
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* 编辑对话框 */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>编辑模板</DialogTitle>
            <DialogDescription>修改模板内容</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleEdit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="edit-title">模板标题</Label>
              <Input
                id="edit-title"
                placeholder="例如：PS入门交换英语口语"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-category">模板分类</Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger id="edit-category">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="skill_learning">技能学习</SelectItem>
                  <SelectItem value="exam_tutoring">考试辅导</SelectItem>
                  <SelectItem value="interest_exchange">兴趣交流</SelectItem>
                  <SelectItem value="custom">自定义</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-content">模板内容</Label>
              <Textarea
                id="edit-content"
                placeholder="输入模板内容"
                value={content}
                onChange={(e) => setContent(e.target.value)}
                className="min-h-[300px] resize-none font-mono text-sm"
              />
            </div>

            <div className="flex gap-2 pt-2">
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setEditDialogOpen(false);
                  resetForm();
                }}
                className="flex-1"
              >
                取消
              </Button>
              <Button type="submit" disabled={submitting} className="flex-1">
                {submitting ? '保存中...' : '保存修改'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* 删除确认对话框 */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>确认删除</AlertDialogTitle>
            <AlertDialogDescription>
              确定要删除模板"{selectedTemplate?.title}"吗？此操作无法撤销。
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setSelectedTemplate(null)}>
              取消
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              disabled={submitting}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {submitting ? '删除中...' : '确认删除'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </MainLayout>
  );
}
