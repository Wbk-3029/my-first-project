import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { MainLayout } from '@/components/layouts/MainLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { useAuth } from '@/contexts/AuthContext';
import { getUserSkills, updateSkill, updateSkillPrice, createSkill } from '@/db/api';
import type { Skill, SkillType } from '@/types';
import { SKILL_TYPE_LABELS, SKILL_DEFAULT_PRICES } from '@/types';
import { Edit, Trash2, PlusCircle, Coins, TrendingUp, ArrowLeft } from 'lucide-react';
import { toast } from 'sonner';

export default function MySkillsPage() {
  const { profile } = useAuth();
  const navigate = useNavigate();
  const [skills, setSkills] = useState<Skill[]>([]);
  const [loading, setLoading] = useState(true);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [editingSkill, setEditingSkill] = useState<Skill | null>(null);

  const [editForm, setEditForm] = useState({
    name: '',
    type: 'normal' as SkillType,
    description: '',
    price: 0,
    priceReason: '',
  });

  const [createForm, setCreateForm] = useState({
    name: '',
    type: 'normal' as SkillType,
    description: '',
    price: SKILL_DEFAULT_PRICES.normal,
  });

  useEffect(() => {
    if (profile) {
      loadSkills();
    }
  }, [profile]);

  const loadSkills = async () => {
    if (!profile) return;

    try {
      setLoading(true);
      const data = await getUserSkills(profile.id);
      setSkills(data);
    } catch (error) {
      toast.error('加载技能失败');
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (skill: Skill) => {
    setEditingSkill(skill);
    setEditForm({
      name: skill.name,
      type: skill.type,
      description: skill.description || '',
      price: skill.price,
      priceReason: '',
    });
    setEditDialogOpen(true);
  };

  const handleUpdateSkill = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingSkill) return;

    try {
      await updateSkill(editingSkill.id, {
        name: editForm.name,
        description: editForm.description,
      });

      // 如果价格变化,记录价格历史
      if (editForm.price !== editingSkill.price) {
        await updateSkillPrice(editingSkill.id, editForm.price, editForm.priceReason);
      }

      toast.success('更新成功');
      setEditDialogOpen(false);
      loadSkills();
    } catch (error) {
      toast.error('更新失败');
    }
  };

  const handleCreateSkill = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      await createSkill(createForm);
      toast.success('发布成功,获得5技易点奖励!');
      setCreateDialogOpen(false);
      setCreateForm({
        name: '',
        type: 'normal',
        description: '',
        price: SKILL_DEFAULT_PRICES.normal,
      });
      loadSkills();
    } catch (error) {
      toast.error('发布失败');
    }
  };

  const handleDelete = async (skillId: string) => {
    try {
      await updateSkill(skillId, { status: 'inactive' });
      toast.success('下架成功');
      loadSkills();
    } catch (error) {
      toast.error('下架失败');
    }
  };

  const handleTypeChange = (type: SkillType, isCreate: boolean) => {
    const defaultPrice = SKILL_DEFAULT_PRICES[type];
    if (isCreate) {
      setCreateForm({ ...createForm, type, price: defaultPrice });
    } else {
      setEditForm({ ...editForm, type, price: defaultPrice });
    }
  };

  if (!profile) {
    return (
      <MainLayout>
        <Card>
          <CardContent className="py-12 text-center text-muted-foreground">
            请先登录
          </CardContent>
        </Card>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <Button asChild variant="ghost" size="sm" className="gap-2 mb-2">
              <Link to="/profile">
                <ArrowLeft className="h-4 w-4" />
                返回个人中心
              </Link>
            </Button>
            <h1 className="text-3xl font-bold">我的技能</h1>
            <p className="text-muted-foreground mt-1">管理你发布的所有技能</p>
          </div>

          <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <PlusCircle className="h-4 w-4" />
                发布新技能
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>发布新技能</DialogTitle>
                <DialogDescription>分享你掌握的技能,发布后获得5技易点奖励</DialogDescription>
              </DialogHeader>
              <form onSubmit={handleCreateSkill} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="create-name">技能名称</Label>
                  <Input
                    id="create-name"
                    placeholder="例如: Python编程入门"
                    value={createForm.name}
                    onChange={(e) => setCreateForm({ ...createForm, name: e.target.value })}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="create-type">技能类型</Label>
                  <Select
                    value={createForm.type}
                    onValueChange={(v) => handleTypeChange(v as SkillType, true)}
                  >
                    <SelectTrigger id="create-type">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(SKILL_TYPE_LABELS).map(([key, label]) => (
                        <SelectItem key={key} value={key}>
                          {label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="create-price">技易点价格</Label>
                  <Input
                    id="create-price"
                    type="number"
                    min="0"
                    value={createForm.price}
                    onChange={(e) =>
                      setCreateForm({ ...createForm, price: Number.parseInt(e.target.value) })
                    }
                    required
                  />
                  <p className="text-xs text-muted-foreground">
                    默认价格: {SKILL_DEFAULT_PRICES[createForm.type]} 技易点
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="create-description">技能描述</Label>
                  <Textarea
                    id="create-description"
                    placeholder="详细描述你的技能内容、教学方式等..."
                    value={createForm.description}
                    onChange={(e) => setCreateForm({ ...createForm, description: e.target.value })}
                    rows={6}
                    required
                  />
                </div>

                <div className="flex justify-end gap-2">
                  <Button type="button" variant="outline" onClick={() => setCreateDialogOpen(false)}>
                    取消
                  </Button>
                  <Button type="submit">发布</Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Skills List */}
        {loading ? (
          <div className="space-y-4">
            {Array.from({ length: 3 }).map((_, i) => (
              <Card key={i}>
                <CardContent className="p-6">
                  <Skeleton className="h-6 w-3/4 mb-2 bg-muted" />
                  <Skeleton className="h-4 w-full bg-muted" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : skills.length > 0 ? (
          <div className="space-y-4">
            {skills.map((skill) => (
              <Card key={skill.id}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <CardTitle>{skill.name}</CardTitle>
                        <Badge variant="secondary">{SKILL_TYPE_LABELS[skill.type]}</Badge>
                        {skill.status === 'inactive' && (
                          <Badge variant="outline">已下架</Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground">{skill.description}</p>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleEdit(skill)}
                        disabled={skill.status === 'inactive'}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button
                            variant="outline"
                            size="sm"
                            disabled={skill.status === 'inactive'}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>确认下架</AlertDialogTitle>
                            <AlertDialogDescription>
                              确定要下架这个技能吗?下架后将不再展示在技能广场。
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>取消</AlertDialogCancel>
                            <AlertDialogAction onClick={() => handleDelete(skill.id)}>
                              确认下架
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center space-x-6 text-sm text-muted-foreground">
                    <div className="flex items-center space-x-1">
                      <Coins className="h-4 w-4 text-secondary" />
                      <span>{skill.price} 技易点</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <TrendingUp className="h-4 w-4" />
                      <span>{skill.exchange_count} 次交换</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="py-12 text-center text-muted-foreground">
              还没有发布技能,快来发布第一个吧!
            </CardContent>
          </Card>
        )}

        {/* Edit Dialog */}
        <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>编辑技能</DialogTitle>
              <DialogDescription>更新技能信息</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleUpdateSkill} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="edit-name">技能名称</Label>
                <Input
                  id="edit-name"
                  value={editForm.name}
                  onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-description">技能描述</Label>
                <Textarea
                  id="edit-description"
                  value={editForm.description}
                  onChange={(e) => setEditForm({ ...editForm, description: e.target.value })}
                  rows={6}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-price">技易点价格</Label>
                <Input
                  id="edit-price"
                  type="number"
                  min="0"
                  value={editForm.price}
                  onChange={(e) =>
                    setEditForm({ ...editForm, price: Number.parseInt(e.target.value) })
                  }
                  required
                />
                {editingSkill && editForm.price !== editingSkill.price && (
                  <div className="space-y-2">
                    <Label htmlFor="price-reason">调整原因</Label>
                    <Input
                      id="price-reason"
                      placeholder="说明价格调整的原因..."
                      value={editForm.priceReason}
                      onChange={(e) => setEditForm({ ...editForm, priceReason: e.target.value })}
                      required
                    />
                  </div>
                )}
              </div>

              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setEditDialogOpen(false)}>
                  取消
                </Button>
                <Button type="submit">保存</Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>
    </MainLayout>
  );
}
