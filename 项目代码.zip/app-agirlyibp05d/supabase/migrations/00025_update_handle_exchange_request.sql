-- 更新handle_exchange_request函数，添加start_time字段
CREATE OR REPLACE FUNCTION handle_exchange_request(
  p_request_id uuid,
  p_action text
) RETURNS json AS $$
DECLARE
  v_request record;
  v_exchange_id uuid;
  v_result json;
BEGIN
  IF p_action NOT IN ('accept', 'reject') THEN
    RAISE EXCEPTION '无效的操作';
  END IF;

  SELECT * INTO v_request
  FROM exchange_requests
  WHERE id = p_request_id
    AND to_user_id = auth.uid()
    AND status = 'pending';

  IF v_request IS NULL THEN
    RAISE EXCEPTION '申请不存在或无权操作';
  END IF;

  IF p_action = 'accept' THEN
    UPDATE exchange_requests
    SET status = 'accepted', updated_at = now()
    WHERE id = p_request_id;

    IF v_request.mode = 'integral' AND v_request.points_amount IS NOT NULL THEN
      UPDATE integral_accounts
      SET balance = balance - v_request.points_amount,
          total_spent = total_spent + v_request.points_amount,
          updated_at = now()
      WHERE user_id = v_request.from_user_id;

      UPDATE integral_accounts
      SET balance = balance + v_request.points_amount,
          total_earned = total_earned + v_request.points_amount,
          updated_at = now()
      WHERE user_id = v_request.to_user_id;

      INSERT INTO integral_transactions (user_id, amount, type, reason, related_id)
      VALUES
        (v_request.from_user_id, -v_request.points_amount, 'expense', '积分交换支付', p_request_id),
        (v_request.to_user_id, v_request.points_amount, 'income', '积分交换收入', p_request_id);
    END IF;

    -- 创建交换记录，添加start_time字段
    INSERT INTO exchanges (
      type,
      initiator_id,
      receiver_id,
      initiator_skill_id,
      receiver_skill_id,
      points_amount,
      status,
      note,
      start_time
    ) VALUES (
      CASE v_request.mode
        WHEN 'direct' THEN 'direct'::exchange_type
        WHEN 'integral' THEN 'point'::exchange_type
        WHEN 'group' THEN 'group'::exchange_type
      END,
      v_request.from_user_id,
      v_request.to_user_id,
      NULL,
      v_request.skill_id,
      v_request.points_amount,
      'in_progress'::exchange_status,
      v_request.message,
      v_request.start_time
    ) RETURNING id INTO v_exchange_id;

    SELECT json_build_object(
      'success', true,
      'exchange_id', v_exchange_id,
      'message', '已同意交换申请'
    ) INTO v_result;
  ELSE
    UPDATE exchange_requests
    SET status = 'rejected', updated_at = now()
    WHERE id = p_request_id;

    SELECT json_build_object(
      'success', true,
      'message', '已拒绝交换申请'
    ) INTO v_result;
  END IF;

  RETURN v_result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
