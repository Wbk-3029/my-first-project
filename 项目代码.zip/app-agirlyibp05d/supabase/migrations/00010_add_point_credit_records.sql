-- 创建技易点记录表
create table if not exists point_records (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  amount integer not null,
  type text not null,
  description text not null,
  created_at timestamptz default now()
);

-- 创建信用分记录表
create table if not exists credit_records (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  change integer not null,
  type text not null,
  description text not null,
  created_at timestamptz default now()
);

-- 添加索引
create index if not exists point_records_user_id_idx on point_records(user_id);
create index if not exists point_records_created_at_idx on point_records(created_at desc);
create index if not exists credit_records_user_id_idx on credit_records(user_id);
create index if not exists credit_records_created_at_idx on credit_records(created_at desc);

-- RLS策略
alter table point_records enable row level security;
alter table credit_records enable row level security;

-- 用户只能查看自己的记录
create policy "Users can view own point records"
  on point_records for select
  using (auth.uid() = user_id);

create policy "Users can view own credit records"
  on credit_records for select
  using (auth.uid() = user_id);

-- 系统可以插入记录(通过service role)
create policy "Service role can insert point records"
  on point_records for insert
  with check (true);

create policy "Service role can insert credit records"
  on credit_records for insert
  with check (true);